import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// In-memory persistent stores for the session
interface Appointment {
  id: string;
  name: string;
  email: string;
  phone: string;
  category: string;
  visitType: string;
  date: string;
  timeSlot: string;
  stayRequired: boolean;
  stayNights?: number;
  guestsCount: number;
  specialRequests?: string;
  status: "Confirmed" | "Pending" | "Completed";
  createdAt: string;
  passCode: string;
}

let appointments: Appointment[] = [
  {
    id: "APT-2026-8812",
    name: "Dr. Rajeshwar Sharma",
    email: "rajeshwar.s@example.com",
    phone: "+91 98765 43210",
    category: "Commercial Investor / Doctor / Educator",
    visitType: "Hospital Facility & Villa Tour",
    date: "2026-09-02",
    timeSlot: "10:00 AM - 12:00 PM (Prime Buggy Tour)",
    stayRequired: true,
    stayNights: 2,
    guestsCount: 3,
    specialRequests: "Interested in Hospital residential quarter and 3-acre park access for children",
    status: "Confirmed",
    createdAt: "2026-08-25T10:30:00.000Z",
    passCode: "VKG-PASS-8812"
  },
  {
    id: "APT-2026-7341",
    name: "Ananya Deshmukh",
    email: "ananya.d@example.com",
    phone: "+91 91234 56780",
    category: "Prospective Resident / Relocating Family",
    visitType: "School & 2BHK Garden Apartment Inspection",
    date: "2026-09-05",
    timeSlot: "02:00 PM - 04:00 PM (Afternoon Session)",
    stayRequired: false,
    guestsCount: 2,
    specialRequests: "Needs wheelchair assistance for elderly parent during 3-acre eco-park tour",
    status: "Confirmed",
    createdAt: "2026-08-25T14:15:00.000Z",
    passCode: "VKG-PASS-7341"
  },
  {
    id: "APT-2026-9042",
    name: "Er. Vikramaditya Rathore",
    email: "vikram.rathore@techcorp.in",
    phone: "+91 98450 11223",
    category: "Prospective Resident / Relocating Family",
    visitType: "Model Villament Experience Stay",
    date: "2026-09-08",
    timeSlot: "10:00 AM - 12:00 PM (Prime Buggy Tour)",
    stayRequired: true,
    stayNights: 3,
    guestsCount: 4,
    specialRequests: "Evaluating 3BHK Eco-Villa with 3.5 kW rooftop solar net-metering",
    status: "Confirmed",
    createdAt: "2026-08-26T08:00:00.000Z",
    passCode: "VKG-PASS-9042"
  },
  {
    id: "APT-2026-6129",
    name: "Capt. Harish Mehra (Retd.)",
    email: "harish.mehra@veterans.org",
    phone: "+91 94190 33445",
    category: "Prospective Resident / Relocating Family",
    visitType: "Central 3-Acre Eco-Park & Open Gym Walk",
    date: "2026-09-10",
    timeSlot: "04:30 PM - 06:30 PM (Sunset Park Walk)",
    stayRequired: true,
    stayNights: 1,
    guestsCount: 2,
    specialRequests: "Wants to inspect the Senior Serenity Pavilion and morning reflexology track",
    status: "Confirmed",
    createdAt: "2026-08-26T09:20:00.000Z",
    passCode: "VKG-PASS-6129"
  },
  {
    id: "APT-2026-4518",
    name: "Rameshwar Patel",
    email: "ramesh.patel.gram@gmail.com",
    phone: "+91 99200 88776",
    category: "Original Native Village Landowner",
    visitType: "Rehabilitation Allotment & Native Housing Consultation",
    date: "2026-09-12",
    timeSlot: "09:00 AM - 11:00 AM (Morning Batch)",
    stayRequired: false,
    guestsCount: 3,
    specialRequests: "Checking Gram Panchayat resolution No. 44/2025 plot allotment",
    status: "Confirmed",
    createdAt: "2026-08-26T10:05:00.000Z",
    passCode: "VKG-PASS-4518"
  },
  {
    id: "APT-2026-3390",
    name: "Dr. Suniti Banerjee",
    email: "s.banerjee@aiims.edu",
    phone: "+91 97330 22119",
    category: "Govt. & Urban Planning Official",
    visitType: "100-Bed Trauma Hospital & Helipad Site Audit",
    date: "2026-09-15",
    timeSlot: "10:00 AM - 12:00 PM (Prime Buggy Tour)",
    stayRequired: true,
    stayNights: 2,
    guestsCount: 2,
    specialRequests: "Checking medical gas pipeline clearance and rooftop emergency helipad access",
    status: "Confirmed",
    createdAt: "2026-08-26T11:40:00.000Z",
    passCode: "VKG-PASS-3390"
  }
];

let liveWorkFeed = [
  {
    id: "LOG-1094",
    sector: "3-Acre Central Eco-Park",
    title: "Children's Sensory Playset & Soft-Turf Installation",
    description: "Installed German-certified safety rubber turfing and sustainable oak-wood play structures in Zone B. Splash fountain testing passed with recycled STP water.",
    author: "Eng. Vikram Verma (Landscape Chief)",
    timestamp: "10 minutes ago",
    status: "Active Work",
    completionPercentage: 88,
    badgeColor: "emerald"
  },
  {
    id: "LOG-1093",
    sector: "Multi-Speciality Hospital",
    title: "Trauma Ward Medical Gas Pipeline Grid Testing",
    description: "Pressure testing for 100-bed centralized oxygen and nitrous pipeline system completed with 100% safety clearance.",
    author: "Dr. Sandeep Kulkarni (Biomedical Lead)",
    timestamp: "1 hour ago",
    status: "Quality Certified",
    completionPercentage: 72,
    badgeColor: "blue"
  },
  {
    id: "LOG-1092",
    sector: "Road & EV Mobility Grid",
    title: "6-Lane Bypass Bituminous Layer 3 Asphalt Pouring",
    description: "Completed 4.2 km stretch connecting Sector 4 to State Highway with smart induction loops for dynamic traffic monitoring.",
    author: "Praveen Rao (Infrastructure Supervisor)",
    timestamp: "3 hours ago",
    status: "Milestone Completed",
    completionPercentage: 94,
    badgeColor: "amber"
  },
  {
    id: "LOG-1091",
    sector: "Integrated Smart Academy",
    title: "STEM Robotics Lab & Digital Smartboard Delivery",
    description: "Received 40 high-spec learning terminals and robotics kits for the secondary school science pavilion.",
    author: "Meenakshi Sundaram (Education Director)",
    timestamp: "5 hours ago",
    status: "In Progress",
    completionPercentage: 91,
    badgeColor: "purple"
  }
];

// Lazy initialization of Gemini client
let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!geminiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key) {
      geminiClient = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build'
          }
        }
      });
    }
  }
  return geminiClient;
}

// API Routes
app.get("/api/health", (_req, res) => {
  res.json({ status: "healthy", project: "Vikasgram Mini Township Portal", time: new Date().toISOString() });
});

// Appointment endpoints
app.get("/api/appointments", (_req, res) => {
  res.json({ appointments });
});

app.post("/api/appointments", (req, res) => {
  const body = req.body;
  if (!body.name || !body.phone || !body.date) {
    res.status(400).json({ error: "Missing required booking details (name, phone, date)" });
    return;
  }

  const randomNum = Math.floor(1000 + Math.random() * 9000);
  const newAppointment: Appointment = {
    id: `APT-2026-${randomNum}`,
    name: body.name,
    email: body.email || "guest@vikasgram.org",
    phone: body.phone,
    category: body.category || "Prospective Township Resident",
    visitType: body.visitType || "General Township & Masterplan Tour",
    date: body.date,
    timeSlot: body.timeSlot || "10:00 AM - 12:00 PM",
    stayRequired: Boolean(body.stayRequired),
    stayNights: body.stayNights ? Number(body.stayNights) : (body.stayRequired ? 1 : 0),
    guestsCount: Number(body.guestsCount) || 1,
    specialRequests: body.specialRequests || "None",
    status: "Confirmed",
    createdAt: new Date().toISOString(),
    passCode: `VKG-PASS-${randomNum}`
  };

  appointments.unshift(newAppointment);
  res.status(201).json({ success: true, appointment: newAppointment });
});

// Live Updates endpoint
app.get("/api/live-updates", (_req, res) => {
  res.json({ updates: liveWorkFeed });
});

app.post("/api/live-updates", (req, res) => {
  const { sector, title, description, author } = req.body;
  if (!sector || !title || !description) {
    res.status(400).json({ error: "Missing required fields for work log" });
    return;
  }
  const newLog = {
    id: `LOG-${Math.floor(1000 + Math.random() * 9000)}`,
    sector,
    title,
    description,
    author: author || "Site Planning Engineer",
    timestamp: "Just now",
    status: "Active Work",
    completionPercentage: Math.floor(65 + Math.random() * 30),
    badgeColor: "indigo"
  };
  liveWorkFeed.unshift(newLog);
  res.status(201).json({ success: true, log: newLog });
});

// Gemini Assistant Endpoint
app.post("/api/township-assistant", async (req, res) => {
  try {
    const { question, chatHistory } = req.body;
    if (!question) {
      res.status(400).json({ error: "Question parameter is required." });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      // Return rich simulated domain response if API key is not yet configured
      res.json({
        reply: `Greetings from the Vikasgram Township Masterplan Office! Regarding your inquiry: Vikasgram is transforming into an eco-smart 180-acre mini-township scheduled for full phase-1 delivery by Q4 2026. Key highlights include our 3-Acre Central Eco-Park (with dedicated children adventure zones and elders acupressure pavilion), a 100-bed Multi-Specialty Hospital with rooftop helipad, an Integrated CBSE/IB Smart School, 6-lane bypass connectivity, and 100% underground solar-backed utilities. You can also book a guided EV buggy visit or guest stay through the booking section on this portal!`,
        sources: ["Vikasgram Masterplan 2028 Gazetted Blueprint", "Town & Country Planning Clearance #TCP-2024-998"]
      });
      return;
    }

    const systemInstruction = `You are "GramVikas AI", the official virtual planner and resident guide for Vikasgram Smart Mini-Township.
You represent the village-to-township transformation project.
Key Township Facts:
- Location & Size: Vikasgram, 180 Acres sustainable township development (converted from traditional village with 100% native landholder rehabilitation and smart villaments).
- 3-Acre Central Eco-Park: Features a Children's adventure & sensory playground with soft-turf and splash fountain, an Elders Serene Pavilion with acupressure reflexology path and yoga deck, a 1.2km synthetic jogging track, an open-air calisthenics gym, and 1,200+ indigenous trees.
- Road Infrastructure: 6-lane outer bypass connecting to State Highway, 4-lane internal EV corridors, underground utility ducts (zero overhead wiring), smart solar streetlights with SOS call buttons.
- Housing: Phase 1 (Native Villament Clusters with solar roofs & rainwater harvesting) and Phase 2 (Modern 2BHK, 3BHK Eco-Villas and smart apartments for new residents).
- Integrated Smart School: Pre-K to Grade 12 CBSE/IB curriculum, robotics STEM labs, Olympic-size pool, sports pavilion, opening for admissions in upcoming academic cycle.
- Multi-Speciality Hospital: 100-bed capacity, 24x7 trauma & emergency center, telemedicine hub, rooftop helipad, dedicated EV ambulance fleet.
- Public Utilities: 2 MLD Sewage Treatment Plant (100% recycled greywater for landscaping), 3.5 MW Solar Microgrid, automated waste segregation, zero-flood storm drainage.
- Visit & Stay: New people can book guided EV buggy tours, 1-3 day test stays in model guest villas, or consult with planning officers.

Always answer politely, professionally, and concisely with structured bullet points when helpful. Include practical guidance on how to use the portal features like the 3D map, documents repository, and appointment booking.`;

    const modelResponse = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: question,
      config: {
        systemInstruction,
        temperature: 0.6,
      }
    });

    res.json({
      reply: modelResponse.text || "I am currently updating the township records. Please feel free to explore the interactive 3D map and infrastructure sections!",
      sources: ["Vikasgram Gazetted Masterplan 2024-2028", "State Urban Infrastructure Mission"]
    });
  } catch (error: any) {
    console.error("Township assistant error:", error);
    res.status(500).json({
      error: "Unable to process AI request at this moment.",
      reply: "Thank you for inquiring about Vikasgram Mini-Township. Our team is actively constructing the infrastructure including the 3-acre park, 100-bed hospital, school, and roads. Please check our Live Updates or book a visit in the appointment tab."
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Vikasgram Township Server running on http://localhost:${PORT}`);
  });
}

startServer();
