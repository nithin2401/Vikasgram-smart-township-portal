export interface SectorInfo {
  id: string;
  name: string;
  shortTitle: string;
  category: "roads" | "housing" | "park" | "school" | "hospital" | "gym" | "utilities";
  iconName: string;
  completionPercentage: number;
  status: "In Progress" | "Near Completion" | "Phase 1 Complete" | "Advanced Stage";
  targetDate: string;
  budgetAllocated: string;
  leadAgency: string;
  description: string;
  keyHighlights: string[];
  specs: { label: string; value: string }[];
  timeline: {
    phase: string;
    milestone: string;
    date: string;
    completed: boolean;
    notes: string;
  }[];
  gallery: {
    title: string;
    caption: string;
    tag: string;
    imageUrl: string;
  }[];
  liveMetrics?: { label: string; value: string; trend?: string }[];
}

export interface DocumentItem {
  id: string;
  title: string;
  category: "Masterplan" | "Clearances" | "Land & Revenue" | "Panchayat Resolutions" | "Tenders";
  referenceNo: string;
  issueDate: string;
  authorizingBody: string;
  fileSize: string;
  summary: string;
  status: "Verified & Gazetted" | "Approved" | "Active Tender";
  downloadUrl?: string;
  highlights: string[];
}

export interface LiveWorkLog {
  id: string;
  sector: string;
  title: string;
  description: string;
  author: string;
  timestamp: string;
  status: string;
  completionPercentage: number;
  badgeColor: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  phoneNumber?: string;
  role?: string;
  photoURL?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface AppointmentRecord {
  id: string;
  userId?: string;
  name: string;
  email: string;
  phone: string;
  category: string;
  visitType: string;
  date: string;
  timeSlot: string;
  stayRequired: boolean;
  stayNights?: number;
  guestsCount: number;
  specialRequests?: string;
  status: "Confirmed" | "Pending" | "Completed" | "Cancelled";
  createdAt: string;
  passCode: string;
}

export interface HousingUnitOption {
  id: string;
  title: string;
  type: "1BHK Native Villament" | "2BHK Garden Flat" | "3BHK Eco-Villa" | "4BHK Smart Townhouse";
  carpetArea: string;
  superArea: string;
  allotmentStatus: "Open for Booking" | "Native Villager Quota" | "Fast Filling";
  estimatedPrice: string;
  features: string[];
  floorPlanDetails: string;
  solarCapacity: string;
}
