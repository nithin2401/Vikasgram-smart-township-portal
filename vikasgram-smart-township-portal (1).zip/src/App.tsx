import React, { useState, useEffect } from "react";
import { 
  Building2, 
  Trees, 
  Hospital, 
  GraduationCap, 
  Route, 
  Home, 
  Dumbbell, 
  Zap, 
  Calendar, 
  FileText, 
  Activity, 
  Sparkles, 
  ArrowRight, 
  Compass, 
  ShieldCheck, 
  PhoneCall, 
  ChevronRight,
  SplitSquareHorizontal,
  Layers,
  MapPin,
  Eye,
  CheckCircle2,
  User as UserIcon,
  LogIn,
  LogOut,
  Menu,
  X
} from "lucide-react";
import { Township3DExplorer } from "./components/Township3DExplorer";
import { DedicatedSectorsSection } from "./components/DedicatedSectorsSection";
import { RenderingsAndComparison } from "./components/RenderingsAndComparison";
import { DocumentsBlueprintHub } from "./components/DocumentsBlueprintHub";
import { LiveWorkStream } from "./components/LiveWorkStream";
import { AppointmentBookingSystem } from "./components/AppointmentBookingSystem";
import { TownshipAIAssistant } from "./components/TownshipAIAssistant";
import { AuthModal } from "./components/AuthModal";
import { useAuth } from "./context/AuthContext";
import { DEDICATED_SECTORS } from "./data/townshipData";

export default function App() {
  const { user, userProfile, openAuthModal, logoutUser } = useAuth();
  const [activeSection, setActiveSection] = useState<string>("3d-map");
  const [selectedSectorId, setSelectedSectorId] = useState<string>("park-3acre");
  const [bookingInitialPurpose, setBookingInitialPurpose] = useState<string>("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Smooth scroll helper that correctly positions the viewport below sticky header
  const scrollToSection = (sectionKey: string) => {
    setActiveSection(sectionKey);
    setMobileMenuOpen(false);
    const targetId = sectionKey === "appointments" ? "booking-section" : `${sectionKey}-section`;
    const el = document.getElementById(targetId);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const handleOpenBooking = (purpose?: string) => {
    if (purpose) setBookingInitialPurpose(purpose);
    scrollToSection("appointments");
  };

  const handleSelectSector = (sectorId: string) => {
    setSelectedSectorId(sectorId);
    scrollToSection("sectors");
  };

  // IntersectionObserver to auto-update active navbar indicator when scrolling
  useEffect(() => {
    const sections = [
      { id: "3d-map-section", key: "3d-map" },
      { id: "sectors-section", key: "sectors" },
      { id: "renderings-section", key: "renderings" },
      { id: "documents-section", key: "documents" },
      { id: "live-feed-section", key: "live-feed" },
      { id: "booking-section", key: "appointments" }
    ];

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const match = sections.find((s) => s.id === entry.target.id);
            if (match) {
              setActiveSection(match.key);
            }
          }
        });
      },
      { rootMargin: "-20% 0px -55% 0px", threshold: 0.15 }
    );

    sections.forEach((sec) => {
      const el = document.getElementById(sec.id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen bg-[#050608] text-slate-200 flex flex-col font-sans antialiased selection:bg-cyan-500 selection:text-slate-950 relative overflow-hidden">
      {/* Ambient background glows for immersive depth */}
      <div className="fixed top-0 left-1/4 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none -z-10"></div>
      <div className="fixed top-1/3 right-10 w-[500px] h-[500px] bg-emerald-500/10 rounded-full blur-[130px] pointer-events-none -z-10"></div>
      <div className="fixed bottom-10 left-1/3 w-[650px] h-[650px] bg-cyan-600/8 rounded-full blur-[160px] pointer-events-none -z-10"></div>

      {/* Top Notification Bar */}
      <div className="bg-[#030406]/90 backdrop-blur-md text-slate-300 text-xs py-2 px-4 border-b border-white/5 relative z-50">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
            </span>
            <span className="font-bold text-cyan-400">Gazetted Masterplan 2024-2028:</span>
            <span className="text-slate-300">
              Vikasgram Village Transformation to Eco-Smart Mini Township • Phase 1 Handover: Dec 2025
            </span>
          </div>
          <div className="flex items-center gap-4 text-slate-400 text-[11px]">
            <a href="tel:18002008899" className="hover:text-cyan-400 flex items-center gap-1 transition">
              <PhoneCall className="w-3 h-3 text-rose-400" />
              <span>Trauma Hotline: 1800-200-8899</span>
            </a>
            <span className="hidden md:inline text-white/20">|</span>
            <span className="text-emerald-400 font-mono hidden md:inline">DTCP-2024-VKG-088</span>
          </div>
        </div>
      </div>

      {/* Main Sticky Navigation Header */}
      <header className="sticky top-0 z-40 bg-[#070b12]/90 backdrop-blur-xl border-b border-white/10 shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          {/* Logo & Identity */}
          <div 
            onClick={() => scrollToSection("3d-map")}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 via-cyan-500 to-emerald-400 text-slate-950 flex items-center justify-center font-black text-xl shadow-lg shadow-cyan-500/20 group-hover:scale-105 transition-transform">
              <Building2 className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black text-white tracking-tight">
                  VIKASGRAM
                </span>
                <span className="px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 font-extrabold text-[10px] uppercase tracking-wider">
                  Mini Township
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium hidden sm:block">
                Village Transformation & Smart Urban Infrastructure Portal
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 bg-[#0b0f19]/90 p-1.5 rounded-2xl border border-white/10 shadow-inner">
            <button
              onClick={() => scrollToSection("3d-map")}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeSection === "3d-map"
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400/30"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              }`}
            >
              🌐 3D Map
            </button>
            <button
              onClick={() => scrollToSection("sectors")}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeSection === "sectors"
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400/30"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              }`}
            >
              🏗️ Dedicated Sectors
            </button>
            <button
              onClick={() => scrollToSection("renderings")}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeSection === "renderings"
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400/30"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              }`}
            >
              🎨 3D Renders & Evolution
            </button>
            <button
              onClick={() => scrollToSection("documents")}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeSection === "documents"
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400/30"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              }`}
            >
              📑 Blueprints & Gazettes
            </button>
            <button
              onClick={() => scrollToSection("live-feed")}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeSection === "live-feed"
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400/30"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              }`}
            >
              🔴 Live Stream
            </button>
            <button
              onClick={() => scrollToSection("appointments")}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeSection === "appointments"
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400/30"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              }`}
            >
              👥 Bookings Column & Stays
            </button>
          </nav>

          {/* Action CTA & User Auth & Mobile Menu Toggle */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {user ? (
              <div className="flex items-center gap-2 bg-[#0b0f19] border border-white/10 p-1 rounded-2xl">
                <div className="flex items-center gap-2 pl-2 pr-1">
                  <div className="w-7 h-7 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 flex items-center justify-center font-bold text-xs">
                    {userProfile?.displayName?.charAt(0) || user.displayName?.charAt(0) || "U"}
                  </div>
                  <div className="hidden xl:block text-left text-xs leading-tight">
                    <div className="font-bold text-white max-w-[120px] truncate">
                      {userProfile?.displayName || user.displayName || "User"}
                    </div>
                    <div className="text-[10px] text-cyan-400 font-mono truncate max-w-[120px]">
                      {userProfile?.role?.split(" ")[0] || "Citizen"}
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => logoutUser()}
                  title="Sign Out"
                  className="p-1.5 rounded-xl bg-white/5 hover:bg-rose-950/60 text-slate-400 hover:text-rose-300 transition border border-transparent hover:border-rose-500/30"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => openAuthModal("signin")}
                className="px-3.5 py-2 rounded-xl text-xs font-bold text-slate-300 hover:text-white bg-[#0b0f19] hover:bg-slate-800 transition border border-white/10 flex items-center gap-1.5"
              >
                <LogIn className="w-3.5 h-3.5 text-cyan-400" />
                <span>Sign In</span>
              </button>
            )}

            <button
              onClick={() => handleOpenBooking("General Township Visit")}
              className="hidden sm:flex px-4 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-cyan-500/20 items-center gap-1.5 transition hover:scale-105 border border-cyan-400/30"
            >
              <span>Book Stay</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            {/* Mobile Hamburger Toggle Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl bg-[#0b0f19] text-slate-300 hover:text-white border border-white/10 transition"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#070b12] border-b border-white/10 px-4 py-3 space-y-1.5 animate-in slide-in-from-top-2">
            <button
              onClick={() => scrollToSection("3d-map")}
              className={`w-full text-left px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center justify-between ${
                activeSection === "3d-map" ? "bg-blue-600 text-white" : "text-slate-300 hover:bg-white/5"
              }`}
            >
              <span className="flex items-center gap-2">🌐 3D Masterplan Map</span>
              <ChevronRight className="w-3.5 h-3.5 opacity-60" />
            </button>
            <button
              onClick={() => scrollToSection("sectors")}
              className={`w-full text-left px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center justify-between ${
                activeSection === "sectors" ? "bg-blue-600 text-white" : "text-slate-300 hover:bg-white/5"
              }`}
            >
              <span className="flex items-center gap-2">🏗️ Dedicated Sectors (Park, Hospital, School)</span>
              <ChevronRight className="w-3.5 h-3.5 opacity-60" />
            </button>
            <button
              onClick={() => scrollToSection("renderings")}
              className={`w-full text-left px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center justify-between ${
                activeSection === "renderings" ? "bg-blue-600 text-white" : "text-slate-300 hover:bg-white/5"
              }`}
            >
              <span className="flex items-center gap-2">🎨 3D Renders & Village Evolution</span>
              <ChevronRight className="w-3.5 h-3.5 opacity-60" />
            </button>
            <button
              onClick={() => scrollToSection("documents")}
              className={`w-full text-left px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center justify-between ${
                activeSection === "documents" ? "bg-blue-600 text-white" : "text-slate-300 hover:bg-white/5"
              }`}
            >
              <span className="flex items-center gap-2">📑 Masterplan Blueprints & Legal Gazettes</span>
              <ChevronRight className="w-3.5 h-3.5 opacity-60" />
            </button>
            <button
              onClick={() => scrollToSection("live-feed")}
              className={`w-full text-left px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center justify-between ${
                activeSection === "live-feed" ? "bg-blue-600 text-white" : "text-slate-300 hover:bg-white/5"
              }`}
            >
              <span className="flex items-center gap-2">🔴 Live Onsite Stream & Telemetry</span>
              <ChevronRight className="w-3.5 h-3.5 opacity-60" />
            </button>
            <button
              onClick={() => scrollToSection("appointments")}
              className={`w-full text-left px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center justify-between ${
                activeSection === "appointments" ? "bg-blue-600 text-white" : "text-slate-300 hover:bg-white/5"
              }`}
            >
              <span className="flex items-center gap-2">👥 Bookings Column, Stays & Passcode</span>
              <ChevronRight className="w-3.5 h-3.5 opacity-60" />
            </button>
          </div>
        )}

        {/* Mobile Horizontal Sub-Navigation Scroll Bar */}
        <div className="lg:hidden flex items-center justify-between gap-2 overflow-x-auto px-4 py-2 border-t border-white/10 bg-[#070b12] scrollbar-none">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => scrollToSection("3d-map")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap ${
                activeSection === "3d-map" ? "bg-blue-600 text-white" : "bg-slate-900 text-slate-300 border border-white/10"
              }`}
            >
              🌐 3D Map
            </button>
            <button
              onClick={() => scrollToSection("sectors")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap ${
                activeSection === "sectors" ? "bg-blue-600 text-white" : "bg-slate-900 text-slate-300 border border-white/10"
              }`}
            >
              🏗️ Sectors
            </button>
            <button
              onClick={() => scrollToSection("renderings")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap ${
                activeSection === "renderings" ? "bg-blue-600 text-white" : "bg-slate-900 text-slate-300 border border-white/10"
              }`}
            >
              🎨 3D Renders
            </button>
            <button
              onClick={() => scrollToSection("documents")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap ${
                activeSection === "documents" ? "bg-blue-600 text-white" : "bg-slate-900 text-slate-300 border border-white/10"
              }`}
            >
              📑 Docs
            </button>
            <button
              onClick={() => scrollToSection("live-feed")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap ${
                activeSection === "live-feed" ? "bg-blue-600 text-white" : "bg-slate-900 text-slate-300 border border-white/10"
              }`}
            >
              🔴 Live Stream
            </button>
            <button
              onClick={() => scrollToSection("appointments")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap ${
                activeSection === "appointments" ? "bg-blue-600 text-white" : "bg-slate-900 text-slate-300 border border-white/10"
              }`}
            >
              👥 Bookings
            </button>
          </div>
        </div>
      </header>

      {/* Main Container Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-16">
        {/* Hero Highlights Dashboard */}
        <div className="glass-panel-elevated rounded-3xl p-6 md:p-10 border border-white/10 text-white shadow-2xl relative overflow-hidden">
          <div className="absolute -right-20 -bottom-20 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute -left-20 -top-20 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="relative z-10 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/80 text-cyan-300 text-xs font-bold uppercase tracking-wider border border-cyan-500/30">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>Transforming Rural Heritage into Next-Gen Sustainable Living</span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-end">
              <div className="lg:col-span-8 space-y-3">
                <h1 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
                  Welcome to <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-emerald-400">Vikasgram Smart Mini-Township</span>
                </h1>
                <p className="text-slate-300 text-sm md:text-base leading-relaxed max-w-3xl">
                  An integrated 180-acre development upgrading our traditional village into a self-sustaining urban sanctuary. Featuring a <strong>3-Acre Central Eco-Park</strong> with dedicated children and elder serenity zones, a <strong>100-Bed Trauma Hospital with Helipad</strong>, <strong>6-Lane Bypass Expressway</strong>, <strong>1,480 Solar Housing Units</strong>, and <strong>100% Underground Public Utilities</strong>.
                </p>
              </div>

              <div className="lg:col-span-4 flex flex-col sm:flex-row lg:flex-col gap-3">
                <button
                  onClick={() => scrollToSection("3d-map")}
                  className="px-6 py-3.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold rounded-2xl text-xs transition shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 border border-cyan-400/30 hover:scale-[1.02]"
                >
                  <Compass className="w-4 h-4" />
                  <span>Launch Interactive 3D Township Map</span>
                </button>
                <button
                  onClick={() => handleOpenBooking("Model Villament Stay Reservation")}
                  className="px-6 py-3.5 bg-slate-900/90 hover:bg-slate-800 text-slate-200 font-bold rounded-2xl text-xs transition border border-white/15 flex items-center justify-center gap-2 hover:border-cyan-400/40"
                >
                  <Calendar className="w-4 h-4 text-cyan-400" />
                  <span>Book Township Stay (1-3 Nights)</span>
                </button>
              </div>
            </div>

            {/* Quick Sector Shortcut Cards Bar */}
            <div className="pt-6 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5">
              {DEDICATED_SECTORS.map((sec) => (
                <button
                  key={sec.id}
                  onClick={() => handleSelectSector(sec.id)}
                  className="p-3 bg-[#0c121e]/80 hover:bg-blue-950/60 border border-white/10 hover:border-cyan-500/50 rounded-2xl text-left transition group backdrop-blur-sm"
                >
                  <div className="text-[10px] text-cyan-400 font-bold uppercase truncate">{sec.shortTitle}</div>
                  <div className="text-xs font-bold text-slate-100 mt-1 group-hover:text-cyan-300 transition truncate">
                    {sec.name}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between">
                    <span>{sec.completionPercentage}% Built</span>
                    <span className="text-cyan-400 group-hover:translate-x-1 transition-transform">→</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* SECTION 1: 3D INTERACTIVE MASTERPLAN EXPLORER */}
        <div id="3d-map-section" className="space-y-6 scroll-mt-28">
          <div className="flex items-center justify-between">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/80 text-cyan-300 text-xs font-bold uppercase tracking-wider mb-1 border border-cyan-500/30">
                <Compass className="w-3.5 h-3.5 text-cyan-400" />
                <span>Real-Time WebGL Masterplan Visualization</span>
              </div>
              <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
                Interactive 3D Township Map & Urban Infrastructure
              </h2>
            </div>

            <div className="hidden sm:flex items-center gap-2 text-xs text-slate-400">
              <span>Click any sector pin in 3D space or use the preset buttons to inspect.</span>
            </div>
          </div>

          <Township3DExplorer
            onSelectSector={handleSelectSector}
          />
        </div>

        {/* SECTION 2: DEDICATED SECTORS DEEP DIVE (Park, Hospital, School, Roads, Housing, Gym, Utilities) */}
        <div id="sectors-section" className="space-y-6 scroll-mt-28">
          <DedicatedSectorsSection
            activeSectorId={selectedSectorId}
            onSelectSector={setSelectedSectorId}
            onOpenBooking={handleOpenBooking}
          />
        </div>

        {/* SECTION 3: 3D RENDERINGS & VILLAGE EVOLUTION SLIDER */}
        <div id="renderings-section" className="space-y-6 scroll-mt-28">
          <RenderingsAndComparison onSelectSector={handleSelectSector} />
        </div>

        {/* SECTION 4: MASTERPLAN BLUEPRINTS & LEGAL GAZETTES */}
        <div id="documents-section" className="space-y-6 scroll-mt-28">
          <DocumentsBlueprintHub />
        </div>

        {/* SECTION 5: LIVE ONSITE WORK STREAM & TELEMETRY */}
        <div id="live-feed-section" className="space-y-6 scroll-mt-28">
          <LiveWorkStream />
        </div>

        {/* SECTION 6: APPOINTMENT BOOKING & STAY PASS */}
        <div id="booking-section" className="space-y-6 scroll-mt-28">
          <AppointmentBookingSystem initialPurpose={bookingInitialPurpose} />
        </div>
      </main>

      {/* Floating AI Township Assistant */}
      <TownshipAIAssistant />

      {/* Official Footer */}
      <footer className="bg-[#030509] text-white border-t border-white/10 mt-20 pt-16 pb-12 relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-px bg-gradient-to-r from-transparent via-cyan-500/40 to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Column 1: Authority & Overview */}
            <div className="space-y-4 md:col-span-1">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-500 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-cyan-500/20">
                  <Building2 className="w-5 h-5 text-slate-950" />
                </div>
                <span className="font-black text-lg tracking-tight text-white">
                  VIKASGRAM
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Vikasgram Smart Mini-Township Development Authority in partnership with Gram Panchayat & Directorate of Town Planning.
              </p>
              <div className="text-[11px] text-cyan-400 font-mono bg-cyan-950/50 px-2.5 py-1 rounded-lg border border-cyan-500/20 inline-block">
                Gazette Reg: DTCP/2024/VKG/088
              </div>
            </div>

            {/* Column 2: Key Sectors Quick Links */}
            <div className="space-y-3 text-xs">
              <div className="font-bold text-white uppercase tracking-wider text-slate-300">Dedicated Infrastructure</div>
              <ul className="space-y-2 text-slate-400">
                <li>
                  <button onClick={() => handleSelectSector("park-3acre")} className="hover:text-cyan-400 transition flex items-center gap-1.5">
                    <span>🌳</span> <span>3-Acre Central Eco-Park</span>
                  </button>
                </li>
                <li>
                  <button onClick={() => handleSelectSector("hospital-sector")} className="hover:text-cyan-400 transition flex items-center gap-1.5">
                    <span>🏥</span> <span>100-Bed Hospital & Helipad</span>
                  </button>
                </li>
                <li>
                  <button onClick={() => handleSelectSector("school-sector")} className="hover:text-cyan-400 transition flex items-center gap-1.5">
                    <span>🏫</span> <span>Integrated Smart Academy</span>
                  </button>
                </li>
                <li>
                  <button onClick={() => handleSelectSector("roads-sector")} className="hover:text-cyan-400 transition flex items-center gap-1.5">
                    <span>🛣️</span> <span>6-Lane Bypass Expressway</span>
                  </button>
                </li>
                <li>
                  <button onClick={() => handleSelectSector("housing-sector")} className="hover:text-cyan-400 transition flex items-center gap-1.5">
                    <span>🏡</span> <span>Native Villaments & Smart Villas</span>
                  </button>
                </li>
              </ul>
            </div>

            {/* Column 3: Transparency & Portals */}
            <div className="space-y-3 text-xs">
              <div className="font-bold text-white uppercase tracking-wider text-slate-300">Statutory & Public Services</div>
              <ul className="space-y-2 text-slate-400">
                <li>
                  <button onClick={() => scrollToSection("documents")} className="hover:text-cyan-400 transition">
                    MoEF&CC Environmental Clearances
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection("documents")} className="hover:text-cyan-400 transition">
                    Gram Sabha Unanimous Resolutions
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection("documents")} className="hover:text-cyan-400 transition">
                    Native Landowner Title Ledger
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection("live-feed")} className="hover:text-cyan-400 transition">
                    Site Live CCTV Stream
                  </button>
                </li>
                <li>
                  <button onClick={() => handleOpenBooking("Guest Stay")} className="hover:text-cyan-400 transition">
                    Model Guest House Reservation
                  </button>
                </li>
              </ul>
            </div>

            {/* Column 4: Contact & Helpdesk */}
            <div className="space-y-3 text-xs">
              <div className="font-bold text-white uppercase tracking-wider text-slate-300">Township Administration Office</div>
              <div className="space-y-2 text-slate-400">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <span>Vikasgram Welcome Center, Gate 1, State Expressway Connector</span>
                </div>
                <div className="flex items-center gap-2">
                  <PhoneCall className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Toll-Free Helpdesk: 1800-200-8899</span>
                </div>
                <div className="pt-2">
                  <button
                    onClick={() => handleOpenBooking("Official Inspection")}
                    className="w-full py-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold rounded-xl text-xs transition border border-cyan-400/30 shadow-lg shadow-cyan-500/20"
                  >
                    Schedule Office Appointment
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
            <div>
              © 2024-2028 Vikasgram Smart Mini-Township Development Project. All Rights Reserved.
            </div>
            <div className="flex items-center gap-4 text-slate-400">
              <span className="text-emerald-400 font-medium">ISO 14001:2015 Green Certified</span>
              <span>•</span>
              <span className="text-cyan-400 font-medium">GRIHA 5-Star Township Rating</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Firebase Sign In / Sign Up Modal */}
      <AuthModal />
    </div>
  );
}
