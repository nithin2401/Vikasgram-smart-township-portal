import React, { useState, useEffect, useMemo } from "react";
import confetti from "canvas-confetti";
import { 
  Calendar as CalendarIcon, 
  Clock, 
  User, 
  Phone, 
  Mail, 
  Bed, 
  Car, 
  CheckCircle2, 
  QrCode, 
  Download, 
  Search, 
  Sparkles, 
  ShieldCheck, 
  ArrowRight, 
  Building2, 
  Users, 
  MapPin,
  UserCheck,
  Printer,
  CalendarPlus,
  Lock,
  LogIn,
  Trash2,
  CalendarCheck,
  Filter,
  FileSpreadsheet,
  Eye,
  RefreshCw,
  Copy,
  Check,
  ExternalLink,
  Info
} from "lucide-react";
import { AppointmentRecord } from "../types";
import { TOUR_TYPES } from "../data/townshipData";
import { useAuth } from "../context/AuthContext";
import { db } from "../firebase";
import { 
  collection, 
  doc, 
  setDoc, 
  onSnapshot,
  deleteDoc
} from "firebase/firestore";

interface AppointmentBookingSystemProps {
  initialPurpose?: string;
  defaultTab?: "book" | "all-bookings" | "my-passes" | "lookup";
}

const DEFAULT_BOOKINGS: AppointmentRecord[] = [
  {
    id: "APT-2026-8812",
    name: "Dr. Rajeshwar Sharma",
    email: "rajeshwar.s@example.com",
    phone: "+91 98765 43210",
    category: "Commercial Investor / Doctor / Educator",
    visitType: "Hospital Facility & Villa Tour",
    date: "2026-09-02",
    timeSlot: "10:00 AM - 12:00 PM (Prime Buggy Tour)",
    stayRequired: true,
    stayNights: 2,
    guestsCount: 3,
    specialRequests: "Interested in Hospital residential quarter and 3-acre park access for children",
    status: "Confirmed",
    createdAt: "2026-08-25T10:30:00.000Z",
    passCode: "VKG-PASS-8812"
  },
  {
    id: "APT-2026-7341",
    name: "Ananya Deshmukh",
    email: "ananya.d@example.com",
    phone: "+91 91234 56780",
    category: "Prospective Resident / Relocating Family",
    visitType: "School & 2BHK Garden Apartment Inspection",
    date: "2026-09-05",
    timeSlot: "02:00 PM - 04:00 PM (Afternoon Session)",
    stayRequired: false,
    guestsCount: 2,
    specialRequests: "Needs wheelchair assistance for elderly parent during 3-acre eco-park tour",
    status: "Confirmed",
    createdAt: "2026-08-25T14:15:00.000Z",
    passCode: "VKG-PASS-7341"
  },
  {
    id: "APT-2026-9042",
    name: "Er. Vikramaditya Rathore",
    email: "vikram.rathore@techcorp.in",
    phone: "+91 98450 11223",
    category: "Prospective Resident / Relocating Family",
    visitType: "Model Villament Experience Stay",
    date: "2026-09-08",
    timeSlot: "10:00 AM - 12:00 PM (Prime Buggy Tour)",
    stayRequired: true,
    stayNights: 3,
    guestsCount: 4,
    specialRequests: "Evaluating 3BHK Eco-Villa with 3.5 kW rooftop solar net-metering",
    status: "Confirmed",
    createdAt: "2026-08-26T08:00:00.000Z",
    passCode: "VKG-PASS-9042"
  },
  {
    id: "APT-2026-6129",
    name: "Capt. Harish Mehra (Retd.)",
    email: "harish.mehra@veterans.org",
    phone: "+91 94190 33445",
    category: "Prospective Resident / Relocating Family",
    visitType: "Central 3-Acre Eco-Park & Open Gym Walk",
    date: "2026-09-10",
    timeSlot: "04:30 PM - 06:30 PM (Sunset Park Walk)",
    stayRequired: true,
    stayNights: 1,
    guestsCount: 2,
    specialRequests: "Wants to inspect the Senior Serenity Pavilion and morning reflexology track",
    status: "Confirmed",
    createdAt: "2026-08-26T09:20:00.000Z",
    passCode: "VKG-PASS-6129"
  },
  {
    id: "APT-2026-4518",
    name: "Rameshwar Patel",
    email: "ramesh.patel.gram@gmail.com",
    phone: "+91 99200 88776",
    category: "Original Native Village Landowner",
    visitType: "Rehabilitation Allotment & Native Housing Consultation",
    date: "2026-09-12",
    timeSlot: "09:00 AM - 11:00 AM (Morning Batch)",
    stayRequired: false,
    guestsCount: 3,
    specialRequests: "Checking Gram Panchayat resolution No. 44/2025 plot allotment",
    status: "Confirmed",
    createdAt: "2026-08-26T10:05:00.000Z",
    passCode: "VKG-PASS-4518"
  },
  {
    id: "APT-2026-3390",
    name: "Dr. Suniti Banerjee",
    email: "s.banerjee@aiims.edu",
    phone: "+91 97330 22119",
    category: "Govt. & Urban Planning Official",
    visitType: "100-Bed Trauma Hospital & Helipad Site Audit",
    date: "2026-09-15",
    timeSlot: "10:00 AM - 12:00 PM (Prime Buggy Tour)",
    stayRequired: true,
    stayNights: 2,
    guestsCount: 2,
    specialRequests: "Checking medical gas pipeline clearance and rooftop emergency helipad access",
    status: "Confirmed",
    createdAt: "2026-08-26T11:40:00.000Z",
    passCode: "VKG-PASS-3390"
  }
];

export const AppointmentBookingSystem: React.FC<AppointmentBookingSystemProps> = ({ 
  initialPurpose,
  defaultTab = "all-bookings"
}) => {
  const { user, userProfile, openAuthModal } = useAuth();
  const [activeTab, setActiveTab] = useState<"book" | "all-bookings" | "my-passes" | "lookup">(defaultTab);

  // Booking Form States
  const [selectedTour, setSelectedTour] = useState<string>("tour-buggy");
  const [visitCategory, setVisitCategory] = useState<string>("Prospective Resident / Relocating Family");
  const [visitDate, setVisitDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 3);
    return d.toISOString().split("T")[0];
  });
  const [timeSlot, setTimeSlot] = useState<string>("10:00 AM - 12:00 PM (Prime Buggy Tour)");
  const [stayRequired, setStayRequired] = useState<boolean>(false);
  const [stayNights, setStayNights] = useState<number>(2);
  const [guestsCount, setGuestsCount] = useState<number>(2);

  const [fullName, setFullName] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [phone, setPhone] = useState<string>("");
  const [specialRequests, setSpecialRequests] = useState<string>(initialPurpose ? `Interested in: ${initialPurpose}` : "");

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [confirmedPass, setConfirmedPass] = useState<AppointmentRecord | null>(null);

  // Bookings Column & Table States
  const [allBookings, setAllBookings] = useState<AppointmentRecord[]>(DEFAULT_BOOKINGS);
  const [userBookings, setUserBookings] = useState<AppointmentRecord[]>([]);
  const [tableSearch, setTableSearch] = useState<string>("");
  const [filterStayType, setFilterStayType] = useState<"all" | "stays" | "day">("all");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [sortBy, setSortBy] = useState<"date-asc" | "created-desc" | "guests-desc">("date-asc");
  const [selectedVisitorModal, setSelectedVisitorModal] = useState<AppointmentRecord | null>(null);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Lookup States
  const [searchCode, setSearchCode] = useState<string>("");
  const [foundAppointment, setFoundAppointment] = useState<AppointmentRecord | null>(null);
  const [lookupError, setLookupError] = useState<string | null>(null);

  // Auto-fill user information when authenticated
  useEffect(() => {
    if (userProfile) {
      if (userProfile.displayName && !fullName) setFullName(userProfile.displayName);
      if (userProfile.email && !email) setEmail(userProfile.email);
      if (userProfile.phoneNumber && !phone) setPhone(userProfile.phoneNumber);
      if (userProfile.role) setVisitCategory(userProfile.role);
    } else if (user) {
      if (user.displayName && !fullName) setFullName(user.displayName);
      if (user.email && !email) setEmail(user.email);
    }
  }, [user, userProfile]);

  // Real-time Firestore synchronization for bookings
  useEffect(() => {
    try {
      const bookingsCol = collection(db, "bookings");
      const unsubscribe = onSnapshot(bookingsCol, (snapshot) => {
        const fetched: AppointmentRecord[] = [];
        snapshot.forEach((docSnap) => {
          fetched.push(docSnap.data() as AppointmentRecord);
        });

        // Merge with seed bookings to guarantee full column view
        const mergedMap = new Map<string, AppointmentRecord>();
        DEFAULT_BOOKINGS.forEach((b) => mergedMap.set(b.id, b));
        fetched.forEach((b) => mergedMap.set(b.id, b));

        const finalArr = Array.from(mergedMap.values());
        setAllBookings(finalArr);

        if (user) {
          const userSpecific = finalArr.filter(
            (b) => b.userId === user.uid || (user.email && b.email.toLowerCase() === user.email.toLowerCase())
          );
          setUserBookings(userSpecific);
        } else {
          setUserBookings([]);
        }
      }, (err) => {
        console.warn("Firestore onSnapshot error, falling back to server API:", err);
      });

      return () => unsubscribe();
    } catch (e) {
      console.warn("Firestore listeners error:", e);
    }

    // Fallback: Fetch from server API
    fetch("/api/appointments")
      .then((res) => res.json())
      .then((data) => {
        if (data.appointments && data.appointments.length > 0) {
          const mergedMap = new Map<string, AppointmentRecord>();
          DEFAULT_BOOKINGS.forEach((b) => mergedMap.set(b.id, b));
          data.appointments.forEach((b: AppointmentRecord) => mergedMap.set(b.id, b));
          setAllBookings(Array.from(mergedMap.values()));
        }
      })
      .catch((e) => console.error("Error fetching appointments fallback:", e));
  }, [user]);

  const timeSlots = [
    "09:00 AM - 11:00 AM (Morning Batch)",
    "10:00 AM - 12:00 PM (Prime Buggy Tour)",
    "02:00 PM - 04:00 PM (Afternoon Session)",
    "04:30 PM - 06:30 PM (Sunset Park Walk)"
  ];

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user) {
      openAuthModal("signin");
      return;
    }

    setIsSubmitting(true);

    const chosenTourObj = TOUR_TYPES.find((t) => t.id === selectedTour);
    const tourTitle = chosenTourObj ? chosenTourObj.title : "Township Tour";
    const randNum = Math.floor(1000 + Math.random() * 9000);
    const newPassCode = `VKG-PASS-${randNum}`;
    const newId = `APT-2026-${randNum}`;

    const newBooking: AppointmentRecord = {
      id: newId,
      userId: user.uid,
      name: fullName || userProfile?.displayName || user.displayName || "Township Visitor",
      email: email || userProfile?.email || user.email || "visitor@vikasgram.gov",
      phone: phone || userProfile?.phoneNumber || "+91 98000 00000",
      category: visitCategory,
      visitType: tourTitle,
      date: visitDate,
      timeSlot,
      stayRequired,
      stayNights: stayRequired ? stayNights : undefined,
      guestsCount,
      specialRequests: specialRequests || undefined,
      status: "Confirmed",
      createdAt: new Date().toISOString(),
      passCode: newPassCode
    };

    try {
      // 1. Store in Firestore
      try {
        await setDoc(doc(db, "bookings", newId), newBooking);
      } catch (firestoreErr) {
        console.warn("Direct Firestore write failed, using API sync:", firestoreErr);
      }

      // 2. Also send to Express backend
      await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newBooking)
      });

      setConfirmedPass(newBooking);
      setAllBookings((prev) => [newBooking, ...prev.filter((p) => p.id !== newBooking.id)]);
      setUserBookings((prev) => [newBooking, ...prev.filter((p) => p.id !== newBooking.id)]);

      confetti({
        particleCount: 90,
        spread: 75,
        origin: { y: 0.6 }
      });
    } catch (err) {
      console.error("Booking error:", err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLookup = () => {
    setLookupError(null);
    setFoundAppointment(null);
    if (!searchCode.trim()) return;

    const term = searchCode.trim().toLowerCase();
    const found = allBookings.find(
      (b) =>
        b.id.toLowerCase().includes(term) ||
        b.passCode.toLowerCase().includes(term) ||
        (b.phone && b.phone.includes(term)) ||
        (b.name && b.name.toLowerCase().includes(term)) ||
        (b.email && b.email.toLowerCase().includes(term))
    );

    if (found) {
      setFoundAppointment(found);
    } else {
      setLookupError("No confirmed booking found with that ID, Passcode, Phone or Email.");
    }
  };

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  // Filter and sort bookings for the Column / Registry Table
  const filteredBookings = useMemo(() => {
    return allBookings
      .filter((b) => {
        // Search query
        if (tableSearch.trim()) {
          const q = tableSearch.toLowerCase().trim();
          const matchName = b.name.toLowerCase().includes(q);
          const matchPhone = b.phone?.toLowerCase().includes(q);
          const matchEmail = b.email?.toLowerCase().includes(q);
          const matchPass = b.passCode.toLowerCase().includes(q);
          const matchId = b.id.toLowerCase().includes(q);
          const matchType = b.visitType.toLowerCase().includes(q);
          const matchCategory = b.category.toLowerCase().includes(q);
          if (!matchName && !matchPhone && !matchEmail && !matchPass && !matchId && !matchType && !matchCategory) {
            return false;
          }
        }

        // Stay filter
        if (filterStayType === "stays" && !b.stayRequired) return false;
        if (filterStayType === "day" && b.stayRequired) return false;

        // Category filter
        if (filterCategory !== "all" && b.category !== filterCategory) return false;

        return true;
      })
      .sort((a, b) => {
        if (sortBy === "date-asc") {
          return a.date.localeCompare(b.date);
        }
        if (sortBy === "created-desc") {
          return b.createdAt.localeCompare(a.createdAt);
        }
        if (sortBy === "guests-desc") {
          return b.guestsCount - a.guestsCount;
        }
        return 0;
      });
  }, [allBookings, tableSearch, filterStayType, filterCategory, sortBy]);

  // Total summary calculations
  const totalBookingsCount = allBookings.length;
  const totalStaysCount = allBookings.filter((b) => b.stayRequired).length;
  const totalGuestsCount = allBookings.reduce((sum, b) => sum + (b.guestsCount || 1), 0);

  // CSV Export Handler
  const exportBookingsToCSV = () => {
    const headers = ["Booking ID", "Pass Code", "Visitor Name", "Category", "Visit Type", "Date", "Time Slot", "Stay Required", "Nights", "Guests", "Phone", "Email", "Status", "Special Requests"];
    const rows = filteredBookings.map((b) => [
      b.id,
      b.passCode,
      `"${b.name.replace(/"/g, '""')}"`,
      `"${b.category.replace(/"/g, '""')}"`,
      `"${b.visitType.replace(/"/g, '""')}"`,
      b.date,
      `"${b.timeSlot.replace(/"/g, '""')}"`,
      b.stayRequired ? "Yes" : "No",
      b.stayNights || 0,
      b.guestsCount,
      b.phone,
      b.email,
      b.status,
      `"${(b.specialRequests || "").replace(/"/g, '""')}"`
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Vikasgram_Township_Bookings_Roster_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="glass-panel rounded-3xl p-5 sm:p-8 md:p-10 border border-white/10 shadow-2xl space-y-8">
      {/* Header Bar */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 text-cyan-300 text-xs font-bold uppercase tracking-wider mb-2 border border-cyan-500/30">
            <Users className="w-3.5 h-3.5 text-cyan-400" />
            <span>Township Stay & Visitor Registry (Firebase Synced)</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight">
            Township Bookings, Stays & Visitor Column
          </h2>
          <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
            Live public registry of all confirmed citizen tours, doctor consultations, model villament stay reservations, and official passes.
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap items-center gap-1.5 bg-[#0b0f19] p-1.5 rounded-2xl border border-white/10 self-start lg:self-auto">
          <button
            onClick={() => {
              setActiveTab("all-bookings");
              setConfirmedPass(null);
            }}
            className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold transition border flex items-center gap-1.5 ${
              activeTab === "all-bookings"
                ? "bg-blue-600 text-white border-blue-400/40 shadow-lg shadow-blue-600/30"
                : "border-transparent text-slate-400 hover:text-white hover:bg-white/5"
            }`}
          >
            <Users className="w-3.5 h-3.5 text-cyan-300" />
            <span>All Bookings Column</span>
            <span className="ml-1 px-1.5 py-0.2 bg-cyan-400 text-slate-950 rounded-full text-[10px] font-black">
              {totalBookingsCount}
            </span>
          </button>

          <button
            onClick={() => {
              setActiveTab("book");
              setConfirmedPass(null);
            }}
            className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold transition border flex items-center gap-1.5 ${
              activeTab === "book"
                ? "bg-blue-600 text-white border-blue-400/40 shadow-lg shadow-blue-600/30"
                : "border-transparent text-slate-400 hover:text-white hover:bg-white/5"
            }`}
          >
            <CalendarPlus className="w-3.5 h-3.5" />
            <span>New Reservation</span>
          </button>
          
          <button
            onClick={() => {
              setActiveTab("my-passes");
              setConfirmedPass(null);
            }}
            className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold transition border relative flex items-center gap-1.5 ${
              activeTab === "my-passes"
                ? "bg-blue-600 text-white border-blue-400/40 shadow-lg shadow-blue-600/30"
                : "border-transparent text-slate-400 hover:text-white hover:bg-white/5"
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>My Passes</span>
            {userBookings.length > 0 && (
              <span className="ml-1 px-1.5 py-0.2 bg-emerald-400 text-slate-950 rounded-full text-[10px] font-black">
                {userBookings.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab("lookup")}
            className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold transition border flex items-center gap-1.5 ${
              activeTab === "lookup"
                ? "bg-blue-600 text-white border-blue-400/40 shadow-lg shadow-blue-600/30"
                : "border-transparent text-slate-400 hover:text-white hover:bg-white/5"
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            <span>Find / Lookup</span>
          </button>
        </div>
      </div>

      {/* User Authentication Status Banner */}
      {!user ? (
        <div className="bg-gradient-to-r from-blue-950/60 via-cyan-950/40 to-slate-900/60 p-4 rounded-2xl border border-cyan-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-950 text-cyan-400 flex items-center justify-center border border-cyan-500/30 shrink-0">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white">
                Firebase Authentication & Real-time Sync Active
              </div>
              <div className="text-xs text-slate-300">
                Sign in to book custom inspection tours, reserve model villament stays, or download personalized digital entry gate passes.
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => openAuthModal("signin")}
              className="w-full sm:w-auto px-5 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-xl text-xs font-bold transition border border-cyan-400/30 shadow-md flex items-center justify-center gap-1.5 whitespace-nowrap"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Sign In / Sign Up</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-[#0b0f19] p-3.5 rounded-2xl border border-emerald-500/30 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-400 flex items-center justify-center font-bold">
              ✓
            </div>
            <div>
              <span className="text-slate-400">Signed in as: </span>
              <span className="font-bold text-white">{userProfile?.displayName || user.displayName || user.email}</span>
              <span className="text-emerald-400 text-[11px] ml-2">({userProfile?.role || "Citizen"})</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-cyan-300 font-mono bg-cyan-950/80 px-2.5 py-1 rounded-lg border border-cyan-500/30 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>Firestore Live Connection: Active</span>
            </span>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. ALL BOOKINGS COLUMN & VISITOR REGISTRY TAB (PRIMARY REQUEST) */}
      {/* ========================================================================= */}
      {activeTab === "all-bookings" && (
        <div className="space-y-6">
          {/* Summary Metric Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            <div className="bg-[#070b14]/90 p-4 rounded-2xl border border-white/10 flex items-center gap-3">
              <div className="p-3 bg-blue-950/80 text-cyan-400 rounded-xl border border-cyan-500/30">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Total Bookings</div>
                <div className="text-xl sm:text-2xl font-black text-white">{totalBookingsCount}</div>
                <div className="text-[10px] text-cyan-400 font-medium">Active Passes</div>
              </div>
            </div>

            <div className="bg-[#070b14]/90 p-4 rounded-2xl border border-white/10 flex items-center gap-3">
              <div className="p-3 bg-emerald-950/80 text-emerald-400 rounded-xl border border-emerald-500/30">
                <Bed className="w-5 h-5" />
              </div>
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Villament Stays</div>
                <div className="text-xl sm:text-2xl font-black text-emerald-400">{totalStaysCount}</div>
                <div className="text-[10px] text-slate-400 font-medium">1-3 Nights Model Stays</div>
              </div>
            </div>

            <div className="bg-[#070b14]/90 p-4 rounded-2xl border border-white/10 flex items-center gap-3">
              <div className="p-3 bg-purple-950/80 text-purple-400 rounded-xl border border-purple-500/30">
                <UserCheck className="w-5 h-5" />
              </div>
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Total Guests</div>
                <div className="text-xl sm:text-2xl font-black text-purple-300">{totalGuestsCount}</div>
                <div className="text-[10px] text-slate-400 font-medium">Registered Visitors</div>
              </div>
            </div>

            <div className="bg-[#070b14]/90 p-4 rounded-2xl border border-white/10 flex items-center gap-3">
              <div className="p-3 bg-amber-950/80 text-amber-400 rounded-xl border border-amber-500/30">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Security Gate Roster</div>
                <div className="text-xl sm:text-2xl font-black text-amber-300">100%</div>
                <div className="text-[10px] text-slate-400 font-medium">QR Pass Verified</div>
              </div>
            </div>
          </div>

          {/* Search, Filter & Export Toolbar */}
          <div className="bg-[#070b14]/95 p-4 sm:p-5 rounded-2xl border border-white/10 space-y-4">
            <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
              {/* Search Bar */}
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="text"
                  placeholder="Search by Visitor Name, Phone, Email, Passcode (e.g. VKG-PASS-8812), or Tour..."
                  value={tableSearch}
                  onChange={(e) => setTableSearch(e.target.value)}
                  className="w-full bg-[#0b0f19] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                />
                {tableSearch && (
                  <button
                    onClick={() => setTableSearch("")}
                    className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-white"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Action Buttons: Export CSV & Print */}
              <div className="flex items-center gap-2 self-end md:self-auto">
                <button
                  onClick={exportBookingsToCSV}
                  className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-white/10 shadow hover:border-cyan-500/30"
                  title="Download Bookings as CSV SpreadSheet"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Export CSV</span>
                </button>

                <button
                  onClick={() => window.print()}
                  className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-white/10"
                  title="Print Gate Security Visitor Roster"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Roster</span>
                </button>

                <button
                  onClick={() => {
                    setActiveTab("book");
                    setConfirmedPass(null);
                  }}
                  className="px-4 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-cyan-400/30 shadow-lg shadow-cyan-500/20"
                >
                  <CalendarPlus className="w-3.5 h-3.5" />
                  <span>Add New Booking</span>
                </button>
              </div>
            </div>

            {/* Filter Chips & Sorting Row */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-white/10 text-xs">
              {/* Stay Type Filter */}
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-slate-500 text-[11px] font-semibold flex items-center gap-1 mr-1">
                  <Filter className="w-3 h-3" />
                  <span>Filter:</span>
                </span>
                
                <button
                  onClick={() => setFilterStayType("all")}
                  className={`px-2.5 py-1 rounded-lg font-semibold text-[11px] transition ${
                    filterStayType === "all"
                      ? "bg-cyan-500 text-slate-950 font-bold"
                      : "bg-[#0b0f19] text-slate-400 hover:text-white border border-white/10"
                  }`}
                >
                  All ({allBookings.length})
                </button>

                <button
                  onClick={() => setFilterStayType("stays")}
                  className={`px-2.5 py-1 rounded-lg font-semibold text-[11px] transition flex items-center gap-1 ${
                    filterStayType === "stays"
                      ? "bg-emerald-500 text-slate-950 font-bold"
                      : "bg-[#0b0f19] text-slate-400 hover:text-white border border-white/10"
                  }`}
                >
                  <Bed className="w-3 h-3" />
                  <span>Model Villa Stays ({totalStaysCount})</span>
                </button>

                <button
                  onClick={() => setFilterStayType("day")}
                  className={`px-2.5 py-1 rounded-lg font-semibold text-[11px] transition flex items-center gap-1 ${
                    filterStayType === "day"
                      ? "bg-blue-500 text-white font-bold"
                      : "bg-[#0b0f19] text-slate-400 hover:text-white border border-white/10"
                  }`}
                >
                  <Car className="w-3 h-3" />
                  <span>Day Tours ({allBookings.length - totalStaysCount})</span>
                </button>
              </div>

              {/* Category & Sorting Selectors */}
              <div className="flex items-center gap-2">
                <select
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className="bg-[#0b0f19] border border-white/10 rounded-lg px-2.5 py-1 text-[11px] text-slate-300 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                >
                  <option value="all">All Visitor Roles</option>
                  <option value="Prospective Resident / Relocating Family">Prospective Resident</option>
                  <option value="Commercial Investor / Doctor / Educator">Doctor / Investor</option>
                  <option value="Original Native Village Landowner">Native Landowner</option>
                  <option value="Govt. & Urban Planning Official">Govt. Official</option>
                </select>

                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-[#0b0f19] border border-white/10 rounded-lg px-2.5 py-1 text-[11px] text-slate-300 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                >
                  <option value="date-asc">Sort: Nearest Visit Date</option>
                  <option value="created-desc">Sort: Newest Bookings First</option>
                  <option value="guests-desc">Sort: Highest Guests Count</option>
                </select>
              </div>
            </div>
          </div>

          {/* Bookings Table / Column View */}
          <div className="bg-[#070b14]/90 rounded-2xl border border-white/10 overflow-hidden shadow-xl">
            {filteredBookings.length === 0 ? (
              <div className="p-10 text-center space-y-3">
                <Users className="w-8 h-8 text-slate-600 mx-auto" />
                <div className="text-white font-bold text-sm">No Bookings Match Your Filter</div>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Try adjusting your search keywords or resetting the filters to view all confirmed township visitors.
                </p>
                <button
                  onClick={() => {
                    setTableSearch("");
                    setFilterStayType("all");
                    setFilterCategory("all");
                  }}
                  className="px-4 py-1.5 bg-slate-800 text-cyan-300 rounded-lg text-xs font-semibold hover:bg-slate-700"
                >
                  Reset Filters
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-white/10 bg-[#090e1a] text-[11px] font-extrabold uppercase tracking-wider text-slate-400">
                      <th className="py-3.5 px-4">Visitor & Contact</th>
                      <th className="py-3.5 px-4">Role / Category</th>
                      <th className="py-3.5 px-4">Tour & Experience</th>
                      <th className="py-3.5 px-4">Scheduled Date & Slot</th>
                      <th className="py-3.5 px-4">Stay & Guests</th>
                      <th className="py-3.5 px-4">Pass Code</th>
                      <th className="py-3.5 px-4">Status</th>
                      <th className="py-3.5 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-xs text-slate-300">
                    {filteredBookings.map((booking) => {
                      const isUserOwned = user && (booking.userId === user.uid || (user.email && booking.email.toLowerCase() === user.email.toLowerCase()));
                      return (
                        <tr 
                          key={booking.id}
                          className="hover:bg-slate-800/40 transition group cursor-pointer"
                          onClick={() => setSelectedVisitorModal(booking)}
                        >
                          {/* Visitor & Contact Column */}
                          <td className="py-3.5 px-4">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-600 to-blue-600 text-slate-950 font-black text-xs flex items-center justify-center shrink-0 shadow">
                                {booking.name.charAt(0)}
                              </div>
                              <div>
                                <div className="font-bold text-white flex items-center gap-1.5">
                                  <span>{booking.name}</span>
                                  {isUserOwned && (
                                    <span className="px-1.5 py-0.2 bg-cyan-950 text-cyan-300 rounded text-[9px] font-bold border border-cyan-500/30">
                                      You
                                    </span>
                                  )}
                                </div>
                                <div className="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5 font-mono">
                                  <span>{booking.phone}</span>
                                  <span>•</span>
                                  <span className="truncate max-w-[140px]">{booking.email}</span>
                                </div>
                              </div>
                            </div>
                          </td>

                          {/* Role / Category */}
                          <td className="py-3.5 px-4">
                            <span className="inline-block px-2.5 py-1 rounded-full bg-[#0b0f19] text-slate-300 text-[10px] font-semibold border border-white/10 whitespace-nowrap">
                              {booking.category.split(" ")[0]} {booking.category.split(" ")[1] || ""}
                            </span>
                          </td>

                          {/* Tour & Experience */}
                          <td className="py-3.5 px-4">
                            <div className="font-semibold text-white max-w-[200px]">
                              {booking.visitType}
                            </div>
                            {booking.specialRequests && (
                              <div className="text-[10px] text-slate-400 italic truncate max-w-[200px] mt-0.5">
                                "{booking.specialRequests}"
                              </div>
                            )}
                          </td>

                          {/* Date & Time Slot */}
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <div className="flex items-center gap-1.5 font-bold text-white">
                              <CalendarIcon className="w-3.5 h-3.5 text-cyan-400" />
                              <span>{booking.date}</span>
                            </div>
                            <div className="text-[11px] text-cyan-300 flex items-center gap-1 mt-0.5">
                              <Clock className="w-3 h-3 text-slate-500" />
                              <span>{booking.timeSlot.split(" ")[0]} {booking.timeSlot.split(" ")[1]}</span>
                            </div>
                          </td>

                          {/* Stay & Guests */}
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            {booking.stayRequired ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-950/80 text-emerald-300 rounded-lg text-[10px] font-bold border border-emerald-500/30">
                                <Bed className="w-3 h-3" />
                                <span>{booking.stayNights} Nights Villa</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-900 text-slate-400 rounded-lg text-[10px] font-medium border border-white/5">
                                <Car className="w-3 h-3" />
                                <span>Day Tour</span>
                              </span>
                            )}
                            <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                              <Users className="w-3 h-3" />
                              <span>{booking.guestsCount} {booking.guestsCount === 1 ? "Guest" : "Guests"}</span>
                            </div>
                          </td>

                          {/* Pass Code Column */}
                          <td className="py-3.5 px-4 whitespace-nowrap font-mono">
                            <div className="flex items-center gap-1.5">
                              <span className="text-xs font-bold text-cyan-300 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-500/30">
                                {booking.passCode}
                              </span>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleCopyCode(booking.passCode);
                                }}
                                title="Copy Passcode"
                                className="p-1 hover:bg-slate-700 rounded text-slate-400 hover:text-white"
                              >
                                {copiedCode === booking.passCode ? (
                                  <Check className="w-3 h-3 text-emerald-400" />
                                ) : (
                                  <Copy className="w-3 h-3" />
                                )}
                              </button>
                            </div>
                          </td>

                          {/* Status */}
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-cyan-950 text-cyan-300 rounded-full text-[10px] font-extrabold border border-cyan-500/30">
                              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                              <span>{booking.status}</span>
                            </span>
                          </td>

                          {/* Actions Column */}
                          <td className="py-3.5 px-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => setSelectedVisitorModal(booking)}
                                className="px-2.5 py-1.5 bg-slate-800 hover:bg-cyan-600 hover:text-white text-cyan-300 rounded-lg text-xs font-bold transition flex items-center gap-1 border border-white/10"
                                title="View Verified Pass & QR Code"
                              >
                                <QrCode className="w-3 h-3" />
                                <span>Pass</span>
                              </button>
                              
                              <button
                                onClick={() => {
                                  setSelectedVisitorModal(booking);
                                  setTimeout(() => window.print(), 300);
                                }}
                                className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition border border-white/10"
                                title="Print Official Gate Pass"
                              >
                                <Printer className="w-3 h-3" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. BOOKING FORM OR CONFIRMED PASS TAB */}
      {/* ========================================================================= */}
      {activeTab === "book" && (
        <>
          {confirmedPass ? (
            /* Digital Township Verified Pass Card */
            <div className="bg-[#070b14] rounded-3xl p-6 md:p-10 border border-white/10 text-white shadow-2xl space-y-8 animate-in zoom-in-95">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-cyan-950/80 text-cyan-400 flex items-center justify-center font-extrabold text-xl shadow-lg border border-cyan-500/30">
                    ✓
                  </div>
                  <div>
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-cyan-300 bg-cyan-950 px-2.5 py-0.5 rounded-full border border-cyan-500/30">
                      OFFICIAL VISITOR PASS STORED IN FIREBASE
                    </span>
                    <h3 className="text-2xl font-black text-white mt-1">
                      Welcome to Vikasgram Mini-Township!
                    </h3>
                  </div>
                </div>

                <div className="text-right font-mono">
                  <div className="text-xs text-slate-400">Passcode / Reference:</div>
                  <div className="text-lg font-black text-cyan-300">{confirmedPass.passCode}</div>
                </div>
              </div>

              {/* Pass Main Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-[#090d16]/90 rounded-2xl p-6 border border-white/10 items-center">
                <div className="md:col-span-2 space-y-4 text-xs">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-slate-400 uppercase font-semibold text-[10px]">Primary Visitor</div>
                      <div className="text-base font-bold text-white mt-0.5">{confirmedPass.name}</div>
                      <div className="text-slate-400 text-[11px]">{confirmedPass.phone} • {confirmedPass.email}</div>
                    </div>
                    <div>
                      <div className="text-slate-400 uppercase font-semibold text-[10px]">Tour / Stay Program</div>
                      <div className="text-base font-bold text-cyan-400 mt-0.5">{confirmedPass.visitType}</div>
                      <div className="text-slate-400 text-[11px]">{confirmedPass.guestsCount} Guests Registered</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-3 border-t border-white/10">
                    <div>
                      <div className="text-slate-400 uppercase font-semibold text-[10px]">Scheduled Date & Slot</div>
                      <div className="text-sm font-bold text-white mt-0.5">{confirmedPass.date}</div>
                      <div className="text-cyan-300 text-[11px] font-semibold">{confirmedPass.timeSlot}</div>
                    </div>
                    <div>
                      <div className="text-slate-400 uppercase font-semibold text-[10px]">Model Villament Guest Stay</div>
                      <div className="text-sm font-bold text-white mt-0.5">
                        {confirmedPass.stayRequired ? `Yes (${confirmedPass.stayNights} Nights Allotted)` : "Day Visit Only"}
                      </div>
                      <div className="text-slate-400 text-[11px]">Includes 100% solar power & park access</div>
                    </div>
                  </div>

                  <div className="pt-2 text-[11px] text-slate-300 bg-[#0b0f19] p-3.5 rounded-xl border border-white/10">
                    <span className="font-bold text-white">Reporting Location: </span>
                    Vikasgram Masterplan Welcome Center, Gate 1, State Expressway Connector Bypass. Free EV fast charging available for visitors.
                  </div>
                </div>

                {/* QR Code Pass Seal */}
                <div className="flex flex-col items-center justify-center p-4 bg-slate-900 rounded-2xl text-white border border-white/10 shadow-inner">
                  <div className="bg-white p-3 rounded-xl">
                    <QrCode className="w-32 h-32 text-slate-900" />
                  </div>
                  <div className="text-[10px] font-mono font-bold mt-3 text-slate-400">{confirmedPass.id}</div>
                  <div className="text-[9px] text-cyan-300 font-extrabold uppercase mt-0.5">
                    Scan at Township Security Gate
                  </div>
                </div>
              </div>

              {/* Pass Actions */}
              <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-white/10">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => window.print()}
                    className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 border border-white/10"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Print Visitor Pass</span>
                  </button>
                  <button
                    onClick={() => {
                      alert(`Calendar event added: Vikasgram Township Visit on ${confirmedPass.date} at ${confirmedPass.timeSlot}`);
                    }}
                    className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded-xl text-xs font-bold transition flex items-center gap-2 border border-white/10"
                  >
                    <CalendarPlus className="w-4 h-4" />
                    <span>Add to Calendar</span>
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setActiveTab("all-bookings");
                      setConfirmedPass(null);
                    }}
                    className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition border border-white/10"
                  >
                    View All Bookings Column
                  </button>

                  <button
                    onClick={() => setConfirmedPass(null)}
                    className="px-5 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-xl text-xs font-bold transition border border-cyan-400/30 shadow-lg shadow-cyan-500/20"
                  >
                    Book Another Appointment
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Booking Form */
            <form onSubmit={handleBookingSubmit} className="space-y-8">
              {/* Step 1: Tour / Experience Type Cards */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-white uppercase tracking-wider">
                    1. Select Experience or Tour Type
                  </label>
                  <span className="text-xs text-cyan-400 font-semibold">100% Free Consultation & EV Buggy Rides</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {TOUR_TYPES.map((tour) => {
                    const isSelected = selectedTour === tour.id;
                    return (
                      <div
                        key={tour.id}
                        onClick={() => {
                          setSelectedTour(tour.id);
                          if (tour.id === "tour-stay") setStayRequired(true);
                        }}
                        className={`p-4 rounded-2xl border cursor-pointer transition flex flex-col justify-between ${
                          isSelected
                            ? "bg-blue-950/60 border-cyan-400 ring-2 ring-cyan-500/30 shadow-xl shadow-cyan-500/10 text-white"
                            : "bg-[#090d16]/90 border-white/10 hover:border-white/20 text-slate-300"
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between text-xs mb-2">
                            <span className="px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 font-bold text-[10px] border border-cyan-500/30">
                              {tour.badge}
                            </span>
                            <span className="text-[11px] text-slate-400 font-medium">{tour.duration}</span>
                          </div>
                          <h4 className="font-bold text-white text-sm">{tour.title}</h4>
                          <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">{tour.description}</p>
                        </div>

                        <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between text-xs font-semibold text-cyan-400">
                          <span>{isSelected ? "Selected ✓" : "Select Tour"}</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Step 2: Date, Slot & Stay Option */}
              <div className="bg-[#070b14]/90 rounded-2xl p-6 border border-white/10 space-y-6">
                <div className="text-xs font-bold text-white uppercase tracking-wider">
                  2. Select Visit Schedule & Model Villament Stay Option
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Preferred Visit Date *
                    </label>
                    <input
                      type="date"
                      required
                      min={new Date().toISOString().split("T")[0]}
                      value={visitDate}
                      onChange={(e) => setVisitDate(e.target.value)}
                      className="w-full bg-[#0b0f19] border border-white/10 rounded-xl p-2.5 text-xs text-white focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Time Slot Batch *
                    </label>
                    <select
                      value={timeSlot}
                      onChange={(e) => setTimeSlot(e.target.value)}
                      className="w-full bg-[#0b0f19] border border-white/10 rounded-xl p-2.5 text-xs text-white focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                    >
                      {timeSlots.map((ts, idx) => (
                        <option key={idx} value={ts}>{ts}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Total Guests Count
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={8}
                      value={guestsCount}
                      onChange={(e) => setGuestsCount(Number(e.target.value))}
                      className="w-full bg-[#0b0f19] border border-white/10 rounded-xl p-2.5 text-xs text-white focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Stay in Model Guest House Toggle */}
                <div className="bg-[#090d16]/90 rounded-xl p-4 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <div className="p-2.5 bg-cyan-950/80 text-cyan-400 rounded-xl border border-cyan-500/30">
                      <Bed className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-bold text-white text-xs sm:text-sm">
                        Opt for 1-3 Nights Stay in Model Guest Villament?
                      </div>
                      <div className="text-slate-300 text-xs">
                        Fully furnished solar villa with 100% solar power, high-speed fiber, and 3-acre park access.
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {stayRequired && (
                      <select
                        value={stayNights}
                        onChange={(e) => setStayNights(Number(e.target.value))}
                        className="bg-[#0b0f19] border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white"
                      >
                        <option value={1}>1 Night</option>
                        <option value={2}>2 Nights</option>
                        <option value={3}>3 Nights</option>
                      </select>
                    )}

                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={stayRequired}
                        onChange={(e) => setStayRequired(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500 border border-white/10"></div>
                    </label>
                  </div>
                </div>
              </div>

              {/* Step 3: Visitor Details */}
              <div className="space-y-4">
                <div className="text-xs font-bold text-white uppercase tracking-wider">
                  3. Primary Visitor Details & Special Accommodations
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Dr. Rajeshwar Sharma"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="w-full bg-[#0b0f19] border border-white/10 rounded-xl p-2.5 text-xs text-white focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="e.g. +91 98765 43210"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-[#0b0f19] border border-white/10 rounded-xl p-2.5 text-xs text-white focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. rajeshwar@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#0b0f19] border border-white/10 rounded-xl p-2.5 text-xs text-white focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Visitor Category
                    </label>
                    <select
                      value={visitCategory}
                      onChange={(e) => setVisitCategory(e.target.value)}
                      className="w-full bg-[#0b0f19] border border-white/10 rounded-xl p-2.5 text-xs text-white focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                    >
                      <option value="Prospective Resident / Relocating Family">Prospective Resident / Relocating Family</option>
                      <option value="Original Native Village Landowner">Original Native Village Landowner (Rehabilitation Allotment)</option>
                      <option value="Commercial Investor / Doctor / Educator">Commercial Investor / Doctor / Educator</option>
                      <option value="Govt. & Urban Planning Official">Govt. & Urban Planning Official</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Special Requests / Notes
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Wheelchair ramp needed for elderly parent during 3-acre park tour"
                      value={specialRequests}
                      onChange={(e) => setSpecialRequests(e.target.value)}
                      className="w-full bg-[#0b0f19] border border-white/10 rounded-xl p-2.5 text-xs text-white focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Submit CTA */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-white/10">
                <div className="flex items-center gap-2 text-xs text-slate-300">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                  <span>Instant verified digital entry pass generated and stored in your Firebase account.</span>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-cyan-500/20 border border-cyan-400/30 flex items-center justify-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>
                    {isSubmitting 
                      ? "Saving to Firebase & Generating Pass..." 
                      : user 
                        ? "Confirm Booking & Generate Official Pass" 
                        : "Sign In to Confirm Booking"}
                  </span>
                </button>
              </div>
            </form>
          )}
        </>
      )}

      {/* ========================================================================= */}
      {/* 3. MY PASSES & RESERVATIONS TAB */}
      {/* ========================================================================= */}
      {activeTab === "my-passes" && (
        <div className="space-y-6">
          {!user ? (
            <div className="bg-[#070b14]/90 p-8 rounded-2xl border border-white/10 text-center space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-cyan-950/80 text-cyan-400 flex items-center justify-center mx-auto border border-cyan-500/30">
                <Lock className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-white">Sign In to View Your Stored Passes</h4>
              <p className="text-xs text-slate-300 max-w-md mx-auto">
                All your confirmed appointments, model villament stay vouchers, and gate pass QR codes are securely tied to your Firebase account.
              </p>
              <button
                onClick={() => openAuthModal("signin")}
                className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-bold rounded-xl text-xs transition border border-cyan-400/30 shadow-lg shadow-cyan-500/20 inline-flex items-center gap-2"
              >
                <LogIn className="w-4 h-4" />
                <span>Sign In with Google or Email</span>
              </button>
            </div>
          ) : userBookings.length === 0 ? (
            <div className="bg-[#070b14]/90 p-8 rounded-2xl border border-white/10 text-center space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-blue-950/80 text-blue-400 flex items-center justify-center mx-auto border border-blue-500/30">
                <CalendarCheck className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-white">No Township Passes Reserved Yet</h4>
              <p className="text-xs text-slate-300 max-w-md mx-auto">
                You haven't scheduled an inspection visit or villament stay yet. Choose your preferred tour to reserve your spot!
              </p>
              <button
                onClick={() => setActiveTab("book")}
                className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-bold rounded-xl text-xs transition border border-cyan-400/30 inline-flex items-center gap-2"
              >
                <span>Book Your First Township Visit</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Your Confirmed Township Passes ({userBookings.length})
                </div>
                <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Real-time Firebase Firestore Sync</span>
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {userBookings.map((b) => (
                  <div
                    key={b.id}
                    className="bg-[#090d16] p-5 rounded-2xl border border-white/10 hover:border-cyan-500/40 transition space-y-4 shadow-lg"
                  >
                    <div className="flex items-center justify-between border-b border-white/10 pb-3">
                      <div>
                        <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                          {b.status}
                        </span>
                        <h4 className="text-base font-bold text-white mt-1">{b.visitType}</h4>
                      </div>
                      <div className="text-right">
                        <div className="text-[10px] text-slate-400">Pass Code</div>
                        <div className="font-mono text-sm font-black text-cyan-400">{b.passCode}</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-slate-500 block text-[10px]">Date & Time</span>
                        <span className="text-slate-200 font-semibold">{b.date}</span>
                        <span className="text-cyan-300 block text-[11px]">{b.timeSlot}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Stay Accommodation</span>
                        <span className="text-slate-200 font-semibold">
                          {b.stayRequired ? `Model Villa (${b.stayNights} Nights)` : "Day Visit"}
                        </span>
                        <span className="text-slate-400 block text-[11px]">{b.guestsCount} Guests</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-white/5">
                      <button
                        onClick={() => setSelectedVisitorModal(b)}
                        className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                      >
                        <QrCode className="w-3.5 h-3.5" />
                        <span>View & Print Gate Pass</span>
                      </button>

                      <span className="text-[10px] text-slate-500 font-mono">{b.id}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. LOOKUP EXISTING BOOKING TAB */}
      {/* ========================================================================= */}
      {activeTab === "lookup" && (
        <div className="space-y-6">
          <div className="bg-[#070b14]/90 p-6 rounded-2xl border border-white/10 space-y-4">
            <h4 className="text-base font-bold text-white">Retrieve Any Digital Township Pass</h4>
            <p className="text-xs text-slate-300">
              Enter your Passcode (e.g. <span className="font-mono font-bold text-cyan-400">VKG-PASS-8812</span>), Booking ID, or registered mobile number:
            </p>

            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                placeholder="Enter Passcode, Booking ID, or Phone number..."
                value={searchCode}
                onChange={(e) => setSearchCode(e.target.value)}
                className="flex-1 bg-[#0b0f19] border border-white/10 rounded-xl p-3 text-xs text-white placeholder:text-slate-500 focus:ring-2 focus:ring-cyan-500 focus:outline-none"
              />
              <button
                onClick={handleLookup}
                className="px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition shadow-lg shadow-cyan-500/20 border border-cyan-400/30"
              >
                <Search className="w-4 h-4" />
                <span>Search Pass</span>
              </button>
            </div>

            {lookupError && (
              <div className="p-3 bg-rose-950/60 border border-rose-500/30 text-rose-300 rounded-xl text-xs font-semibold">
                {lookupError}
              </div>
            )}
          </div>

          {/* Found Result Pass Display */}
          {foundAppointment && (
            <div className="bg-[#070b14] rounded-3xl p-6 md:p-8 border border-white/10 text-white shadow-2xl space-y-6 animate-in fade-in">
              <div className="flex items-center justify-between pb-4 border-b border-white/10">
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-cyan-300 bg-cyan-950 px-2.5 py-0.5 rounded-full border border-cyan-500/30">
                    STATUS: {foundAppointment.status.toUpperCase()}
                  </span>
                  <h4 className="text-xl font-bold text-white mt-1">{foundAppointment.name}</h4>
                  <div className="text-xs text-slate-400">{foundAppointment.visitType}</div>
                </div>

                <div className="text-right font-mono">
                  <div className="text-xs text-slate-400">Passcode:</div>
                  <div className="text-base font-bold text-cyan-300">{foundAppointment.passCode}</div>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs bg-[#090d16]/90 p-4 rounded-xl border border-white/10">
                <div>
                  <div className="text-slate-400 uppercase text-[10px]">Date</div>
                  <div className="font-bold text-white mt-0.5">{foundAppointment.date}</div>
                </div>
                <div>
                  <div className="text-slate-400 uppercase text-[10px]">Slot</div>
                  <div className="font-bold text-cyan-300 mt-0.5">{foundAppointment.timeSlot}</div>
                </div>
                <div>
                  <div className="text-slate-400 uppercase text-[10px]">Guests</div>
                  <div className="font-bold text-white mt-0.5">{foundAppointment.guestsCount} Persons</div>
                </div>
                <div>
                  <div className="text-slate-400 uppercase text-[10px]">Model Stay</div>
                  <div className="font-bold text-emerald-400 mt-0.5">
                    {foundAppointment.stayRequired ? `Yes (${foundAppointment.stayNights} Nights)` : "Day Visit"}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  onClick={() => setSelectedVisitorModal(foundAppointment)}
                  className="px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-cyan-400/30 shadow-lg shadow-cyan-500/20"
                >
                  <QrCode className="w-3.5 h-3.5" />
                  <span>View Official QR Pass</span>
                </button>
                <div className="text-xs text-slate-400 font-mono">
                  Firebase Document Ref: {foundAppointment.id}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* POPUP MODAL: VERIFIED VISITOR PASS & SECURITY QR CODE SEAL */}
      {/* ========================================================================= */}
      {selectedVisitorModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-xl bg-[#070b14] border border-cyan-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl text-white overflow-hidden space-y-6 max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-950 text-cyan-400 flex items-center justify-center font-black border border-cyan-500/30">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-cyan-300 bg-cyan-950 px-2 py-0.5 rounded-full border border-cyan-500/30">
                    OFFICIAL TOWNSHIP VISITOR PASS
                  </span>
                  <h3 className="text-xl font-bold text-white mt-0.5">
                    {selectedVisitorModal.name}
                  </h3>
                </div>
              </div>

              <button
                onClick={() => setSelectedVisitorModal(null)}
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition"
              >
                ✕
              </button>
            </div>

            {/* Pass Body */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 bg-[#090d16] p-5 rounded-2xl border border-white/10 items-center">
              <div className="sm:col-span-2 space-y-3 text-xs">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Pass Code</span>
                    <span className="font-mono font-bold text-cyan-300 text-sm">{selectedVisitorModal.passCode}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Booking Ref ID</span>
                    <span className="font-mono text-slate-300 text-xs">{selectedVisitorModal.id}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2 border-t border-white/10">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Visit Date</span>
                    <span className="font-bold text-white text-xs">{selectedVisitorModal.date}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Time Slot</span>
                    <span className="font-semibold text-cyan-300 text-xs">{selectedVisitorModal.timeSlot}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-white/10">
                  <span className="text-slate-400 block text-[10px]">Program / Tour</span>
                  <span className="font-bold text-white text-xs">{selectedVisitorModal.visitType}</span>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2 border-t border-white/10">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Stay Accommodation</span>
                    <span className="font-bold text-emerald-400 text-xs">
                      {selectedVisitorModal.stayRequired ? `Model Villa (${selectedVisitorModal.stayNights} Nights)` : "Day Tour"}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Total Persons</span>
                    <span className="font-semibold text-white text-xs">{selectedVisitorModal.guestsCount} Guests</span>
                  </div>
                </div>

                {selectedVisitorModal.specialRequests && (
                  <div className="pt-2 text-[11px] text-slate-300 bg-[#0b0f19] p-2.5 rounded-lg border border-white/10">
                    <span className="font-bold text-cyan-300">Special Notes: </span>
                    {selectedVisitorModal.specialRequests}
                  </div>
                )}
              </div>

              {/* QR Code */}
              <div className="flex flex-col items-center justify-center p-3 bg-slate-900 rounded-xl border border-white/10">
                <div className="bg-white p-2.5 rounded-lg">
                  <QrCode className="w-28 h-28 text-slate-950" />
                </div>
                <span className="text-[9px] text-cyan-400 font-bold uppercase mt-2">
                  Security Gate 1 Scan
                </span>
              </div>
            </div>

            {/* Footer Buttons */}
            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => window.print()}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 border border-white/10"
              >
                <Printer className="w-4 h-4" />
                <span>Print Gate Pass</span>
              </button>

              <button
                onClick={() => setSelectedVisitorModal(null)}
                className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold transition shadow"
              >
                Close Pass Preview
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
