import React, { useState } from "react";
import { 
  Sparkles, 
  Layers, 
  Eye, 
  Download, 
  CheckCircle2, 
  ArrowRight, 
  Maximize2, 
  Building2, 
  Trees, 
  Hospital, 
  GraduationCap, 
  Route, 
  Zap,
  SplitSquareHorizontal
} from "lucide-react";
import { DEDICATED_SECTORS } from "../data/townshipData";

interface RenderingsAndComparisonProps {
  onSelectSector: (sectorId: string) => void;
}

export const RenderingsAndComparison: React.FC<RenderingsAndComparisonProps> = ({ onSelectSector }) => {
  const [sliderPosition, setSliderPosition] = useState<number>(50);
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [activeImageModal, setActiveImageModal] = useState<{
    title: string;
    caption: string;
    tag: string;
    imageUrl: string;
    sectorId?: string;
  } | null>(null);

  // Collect all architectural renderings from all sectors
  const allRenderings = DEDICATED_SECTORS.flatMap((sector) =>
    sector.gallery.map((item) => ({
      ...item,
      sectorId: sector.id,
      sectorName: sector.name,
      category: sector.category
    }))
  );

  const filteredRenderings = activeCategory === "all"
    ? allRenderings
    : allRenderings.filter((r) => r.category === activeCategory);

  return (
    <div className="space-y-12">
      {/* Transformation Comparison Slider Card */}
      <div className="glass-panel rounded-3xl p-6 md:p-8 border border-white/10 shadow-2xl overflow-hidden relative">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 text-cyan-300 text-xs font-semibold uppercase tracking-wider mb-2 border border-cyan-500/30">
              <SplitSquareHorizontal className="w-3.5 h-3.5 text-cyan-400" />
              <span>Village Evolution Interactive Matrix</span>
            </div>
            <h3 className="text-2xl md:text-3xl font-black text-white tracking-tight">
              Traditional Village (2023) vs Smart Mini-Township (2028)
            </h3>
            <p className="text-slate-300 text-sm mt-1 max-w-2xl">
              Drag the interactive comparison divider below to witness how the rural settlement is upgraded with underground solar utilities, 6-lane connectivity, 3-acre park, and 100-bed healthcare.
            </p>
          </div>

          <div className="flex items-center gap-3 text-xs font-medium">
            <div className="flex items-center gap-1.5 text-amber-300 bg-amber-950/80 px-3 py-1.5 rounded-xl border border-amber-500/30">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
              <span>Past: Unpaved Village (2023)</span>
            </div>
            <div className="flex items-center gap-1.5 text-cyan-300 bg-cyan-950/80 px-3 py-1.5 rounded-xl border border-cyan-500/30">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
              <span>Future: Eco-Township (2028)</span>
            </div>
          </div>
        </div>

        {/* Interactive Comparison Container */}
        <div className="relative w-full h-[380px] md:h-[480px] rounded-2xl overflow-hidden select-none border border-white/10 shadow-2xl group">
          {/* AFTER Image (Full Township) */}
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: `url('https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1600&q=80')`
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-[#050608]/90 via-transparent to-transparent"></div>
            <div className="absolute bottom-6 right-6 text-right text-white">
              <div className="text-xs font-bold uppercase tracking-wider text-cyan-300 bg-cyan-950/90 px-2.5 py-1 rounded-lg inline-block backdrop-blur-md border border-cyan-500/30">
                2028 Mini-Township Masterplan
              </div>
              <div className="text-lg md:text-xl font-bold mt-1">100% Underground Solar & 3-Acre Bio-Park</div>
              <div className="text-xs text-slate-300">1,480 Modern units, 6-lane bypass, 100-bed hospital</div>
            </div>
          </div>

          {/* BEFORE Image (Clipped) */}
          <div
            className="absolute inset-0 bg-cover bg-center overflow-hidden border-r-2 border-cyan-400 shadow-2xl"
            style={{
              clipPath: `polygon(0 0, ${sliderPosition}% 0, ${sliderPosition}% 100%, 0 100%)`,
              backgroundImage: `url('https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1600&q=80')`
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-[#050608]/90 via-transparent to-transparent"></div>
            <div className="absolute bottom-6 left-6 text-left text-white">
              <div className="text-xs font-bold uppercase tracking-wider text-amber-300 bg-amber-950/90 px-2.5 py-1 rounded-lg inline-block backdrop-blur-md border border-amber-500/30">
                2023 Original Village
              </div>
              <div className="text-lg md:text-xl font-bold mt-1">Unpaved Paths & Overhead Cables</div>
              <div className="text-xs text-slate-300">No drainage, intermittent power, 18km to nearest hospital</div>
            </div>
          </div>

          {/* Slider Drag Handle */}
          <div
            className="absolute top-0 bottom-0 w-1 bg-cyan-400 cursor-ew-resize flex items-center justify-center pointer-events-none"
            style={{ left: `${sliderPosition}%` }}
          >
            <div className="w-10 h-10 rounded-full bg-[#050608] shadow-2xl border-2 border-cyan-400 flex items-center justify-center text-cyan-300 font-bold text-xs">
              ↔
            </div>
          </div>

          {/* Range input overlay for smooth touch/drag */}
          <input
            type="range"
            min="0"
            max="100"
            value={sliderPosition}
            onChange={(e) => setSliderPosition(Number(e.target.value))}
            className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize"
          />
        </div>

        {/* Feature comparison table row */}
        <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-[#0b0f19] rounded-xl p-3 border border-white/10">
            <div className="text-[10px] text-slate-400 uppercase font-semibold">Road Infrastructure</div>
            <div className="text-xs font-bold text-white mt-0.5">Dirt Paths ➔ 6-Lane Bypass + EV Grid</div>
          </div>
          <div className="bg-[#0b0f19] rounded-xl p-3 border border-white/10">
            <div className="text-[10px] text-slate-400 uppercase font-semibold">Green Spaces</div>
            <div className="text-xs font-bold text-white mt-0.5">Vacant plots ➔ 3-Acre Central Park</div>
          </div>
          <div className="bg-[#0b0f19] rounded-xl p-3 border border-white/10">
            <div className="text-[10px] text-slate-400 uppercase font-semibold">Healthcare Access</div>
            <div className="text-xs font-bold text-white mt-0.5">1 Sub-center ➔ 100-Bed Trauma Hospital</div>
          </div>
          <div className="bg-[#0b0f19] rounded-xl p-3 border border-white/10">
            <div className="text-[10px] text-slate-400 uppercase font-semibold">Power & Waste</div>
            <div className="text-xs font-bold text-white mt-0.5">Open dumping ➔ 3.5MW Solar + 2MLD STP</div>
          </div>
        </div>
      </div>

      {/* Architectural Renderings Gallery */}
      <div className="glass-panel rounded-3xl p-6 md:p-8 border border-white/10 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/80 text-cyan-300 text-xs font-semibold uppercase tracking-wider mb-2 border border-cyan-500/30">
              <Eye className="w-3.5 h-3.5 text-cyan-400" />
              <span>Architectural Renders & Visual Blueprints</span>
            </div>
            <h3 className="text-2xl md:text-3xl font-black text-white tracking-tight">
              High-Definition 3D Sector Renderings
            </h3>
            <p className="text-slate-300 text-sm mt-1">
              Explore the detailed architectural visualizations designed by our master planning architects.
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5 bg-[#070b14] p-1.5 rounded-2xl border border-white/10">
            <button
              onClick={() => setActiveCategory("all")}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                activeCategory === "all"
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400/40"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              }`}
            >
              All Sectors ({allRenderings.length})
            </button>
            <button
              onClick={() => setActiveCategory("park")}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                activeCategory === "park"
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400/40"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              }`}
            >
              🌳 3-Acre Park
            </button>
            <button
              onClick={() => setActiveCategory("hospital")}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                activeCategory === "hospital"
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400/40"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              }`}
            >
              🏥 100-Bed Hospital
            </button>
            <button
              onClick={() => setActiveCategory("school")}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                activeCategory === "school"
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400/40"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              }`}
            >
              🏫 Smart School
            </button>
            <button
              onClick={() => setActiveCategory("housing")}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                activeCategory === "housing"
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400/40"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              }`}
            >
              🏡 Smart Housing
            </button>
            <button
              onClick={() => setActiveCategory("roads")}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                activeCategory === "roads"
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400/40"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              }`}
            >
              🛣️ 6-Lane Roads
            </button>
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredRenderings.map((item, index) => (
            <div
              key={index}
              onClick={() => setActiveImageModal(item)}
              className="group bg-[#090d16]/90 rounded-2xl overflow-hidden border border-white/10 hover:border-cyan-500/50 hover:shadow-2xl hover:shadow-cyan-500/10 transition-all duration-300 cursor-pointer flex flex-col"
            >
              <div className="relative h-56 w-full overflow-hidden bg-slate-900">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#070b14] via-transparent to-transparent opacity-80 group-hover:opacity-90 transition-opacity"></div>
                <div className="absolute top-3 left-3 bg-[#050608]/85 backdrop-blur-md text-cyan-300 text-[11px] font-bold px-2.5 py-1 rounded-lg border border-cyan-500/30">
                  {item.tag}
                </div>
                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <div className="text-xs text-slate-400">{item.sectorName}</div>
                  <h4 className="text-base font-bold leading-tight group-hover:text-cyan-300 transition-colors">
                    {item.title}
                  </h4>
                </div>
                <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity border border-white/20">
                  <Maximize2 className="w-4 h-4" />
                </div>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between bg-[#0c121e]">
                <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                  {item.caption}
                </p>
                <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between text-xs">
                  <span className="text-cyan-400 font-semibold flex items-center gap-1 group-hover:underline">
                    View Sector Milestones <ArrowRight className="w-3 h-3" />
                  </span>
                  <span className="text-slate-500 text-[10px]">Architectural 3D Model</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Full Screen Image Modal */}
      {activeImageModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#070b14] rounded-3xl max-w-4xl w-full overflow-hidden border border-white/10 shadow-2xl text-white">
            <div className="relative h-[400px] md:h-[500px] w-full bg-slate-950">
              <img
                src={activeImageModal.imageUrl}
                alt={activeImageModal.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <button
                onClick={() => setActiveImageModal(null)}
                className="absolute top-4 right-4 w-10 h-10 rounded-full bg-slate-900/80 hover:bg-slate-800 text-white flex items-center justify-center text-sm font-bold border border-white/20"
              >
                ✕
              </button>
              <div className="absolute top-4 left-4 bg-cyan-400 text-slate-950 text-xs font-bold px-3 py-1 rounded-full">
                {activeImageModal.tag}
              </div>
            </div>

            <div className="p-6 bg-[#070b14] flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <h3 className="text-xl font-bold text-white">{activeImageModal.title}</h3>
                <p className="text-sm text-slate-300 mt-1 max-w-xl">{activeImageModal.caption}</p>
              </div>

              <div className="flex items-center gap-2 w-full md:w-auto">
                {activeImageModal.sectorId && (
                  <button
                    onClick={() => {
                      const id = activeImageModal.sectorId!;
                      setActiveImageModal(null);
                      onSelectSector(id);
                    }}
                    className="flex-1 md:flex-none px-4 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 border border-cyan-400/30 shadow-lg shadow-cyan-500/20"
                  >
                    <span>View Dedicated Sector Report</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
                <button
                  onClick={() => setActiveImageModal(null)}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition border border-white/10"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
