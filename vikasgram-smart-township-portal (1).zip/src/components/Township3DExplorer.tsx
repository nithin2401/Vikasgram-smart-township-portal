import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { 
  Maximize2, 
  RotateCcw, 
  Sun, 
  Moon, 
  Sunset, 
  Layers, 
  Eye, 
  Navigation, 
  Info, 
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Calendar,
  Compass
} from "lucide-react";
import { SectorInfo } from "../types";
import { DEDICATED_SECTORS } from "../data/townshipData";

interface Township3DExplorerProps {
  onSelectSector: (sectorId: string) => void;
}

export const Township3DExplorer: React.FC<Township3DExplorerProps> = ({ onSelectSector }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const [activePreset, setActivePreset] = useState<string>("overview");
  const [timeOfDay, setTimeOfDay] = useState<"day" | "sunset" | "night">("day");
  const [activeLayers, setActiveLayers] = useState({
    roads: true,
    park: true,
    hospital: true,
    school: true,
    housing: true,
    utilities: true,
  });
  const [selectedPin, setSelectedPin] = useState<SectorInfo | null>(null);
  const [isRotating, setIsRotating] = useState<boolean>(true);
  const [viewMode, setViewMode] = useState<"future" | "comparison">("future");
  const [comparisonSplit, setComparisonSplit] = useState<number>(50);

  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const objectsGroupRef = useRef<THREE.Group | null>(null);
  const carGroupRef = useRef<THREE.Group | null>(null);
  const lightsRef = useRef<{
    ambient: THREE.AmbientLight;
    directional: THREE.DirectionalLight;
    pointLights: THREE.PointLight[];
  } | null>(null);

  // Camera targets for smooth animation
  const cameraTargetRef = useRef<{
    pos: THREE.Vector3;
    lookAt: THREE.Vector3;
  }>({
    pos: new THREE.Vector3(70, 60, 80),
    lookAt: new THREE.Vector3(0, 0, 0)
  });

  const currentLookAtRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 0, 0));

  // Initialize Three.js Scene
  useEffect(() => {
    if (!containerRef.current || !canvasRef.current) return;

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight || 550;

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0xf0fdf4); // Soft lush light green-white
    scene.fog = new THREE.FogExp2(0xe2f1e8, 0.0035);

    // Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.5, 1000);
    camera.position.set(70, 60, 80);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      antialias: true,
      powerPreference: "high-performance"
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xfffaed, 1.4);
    dirLight.position.set(60, 90, 40);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 10;
    dirLight.shadow.camera.far = 250;
    dirLight.shadow.camera.left = -90;
    dirLight.shadow.camera.right = 90;
    dirLight.shadow.camera.top = 90;
    dirLight.shadow.camera.bottom = -90;
    scene.add(dirLight);

    const pointLights: THREE.PointLight[] = [];
    lightsRef.current = { ambient: ambientLight, directional: dirLight, pointLights };

    // Master Township Group
    const townGroup = new THREE.Group();
    objectsGroupRef.current = townGroup;
    scene.add(townGroup);

    // 1. Terrain Ground (180 Acre representation)
    const groundGeo = new THREE.PlaneGeometry(160, 160, 32, 32);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x86efac, // Fresh vibrant green
      roughness: 0.85,
      metalness: 0.05
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    townGroup.add(ground);

    // Natural Village Eco-Stream / Lake
    const lakeGeo = new THREE.CircleGeometry(16, 32);
    const lakeMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      roughness: 0.1,
      metalness: 0.3,
      transparent: true,
      opacity: 0.85
    });
    const lake = new THREE.Mesh(lakeGeo, lakeMat);
    lake.rotation.x = -Math.PI / 2;
    lake.position.set(-18, 0.1, 10);
    townGroup.add(lake);

    // 2. Road Network Grid (6-Lane Bypass + Arterial)
    const roadGroup = new THREE.Group();
    roadGroup.name = "roads";

    // 6-Lane Outer Bypass Expressway (Curved / Wide)
    const bypassGeo = new THREE.PlaneGeometry(150, 14);
    const bypassMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.7 });
    const bypass = new THREE.Mesh(bypassGeo, bypassMat);
    bypass.rotation.x = -Math.PI / 2;
    bypass.position.set(0, 0.05, -55);
    bypass.receiveShadow = true;
    roadGroup.add(bypass);

    // Bypass yellow dividing line & lane stripes
    const yellowStripeGeo = new THREE.PlaneGeometry(150, 0.5);
    const yellowStripeMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
    const yellowStripe = new THREE.Mesh(yellowStripeGeo, yellowStripeMat);
    yellowStripe.rotation.x = -Math.PI / 2;
    yellowStripe.position.set(0, 0.08, -55);
    roadGroup.add(yellowStripe);

    // 4-Lane Central Arterial Boulevard (Z-axis crossing)
    const arterialGeo = new THREE.PlaneGeometry(10, 120);
    const arterialMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.7 });
    const arterial = new THREE.Mesh(arterialGeo, arterialMat);
    arterial.rotation.x = -Math.PI / 2;
    arterial.position.set(0, 0.06, 5);
    arterial.receiveShadow = true;
    roadGroup.add(arterial);

    // East-West Connecting Boulevard
    const ewRoadGeo = new THREE.PlaneGeometry(120, 8);
    const ewRoad = new THREE.Mesh(ewRoadGeo, arterialMat);
    ewRoad.rotation.x = -Math.PI / 2;
    ewRoad.position.set(0, 0.06, 0);
    ewRoad.receiveShadow = true;
    roadGroup.add(ewRoad);

    // Smart Solar Street Poles
    for (let i = -50; i <= 50; i += 20) {
      // Along bypass
      const poleGeo = new THREE.CylinderGeometry(0.15, 0.2, 5, 8);
      const poleMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8 });
      const pole = new THREE.Mesh(poleGeo, poleMat);
      pole.position.set(i, 2.5, -47);
      pole.castShadow = true;
      roadGroup.add(pole);

      // Light head
      const lampHeadGeo = new THREE.BoxGeometry(0.8, 0.2, 1.2);
      const lampHeadMat = new THREE.MeshStandardMaterial({ color: 0x0284c7 });
      const lampHead = new THREE.Mesh(lampHeadGeo, lampHeadMat);
      lampHead.position.set(i, 5, -48);
      roadGroup.add(lampHead);

      // Pointlight for night mode
      const pLight = new THREE.PointLight(0xfef08a, 0, 15);
      pLight.position.set(i, 4.8, -48);
      roadGroup.add(pLight);
      pointLights.push(pLight);
    }
    townGroup.add(roadGroup);

    // Moving EV Cars Group
    const carsGroup = new THREE.Group();
    carGroupRef.current = carsGroup;
    const carColors = [0x38bdf8, 0x10b981, 0xf43f5e, 0xf59e0b, 0xffffff];
    for (let i = 0; i < 8; i++) {
      const car = new THREE.Group();
      const carBodyGeo = new THREE.BoxGeometry(3.5, 1.2, 1.8);
      const carBodyMat = new THREE.MeshStandardMaterial({
        color: carColors[i % carColors.length],
        metalness: 0.6,
        roughness: 0.3
      });
      const carBody = new THREE.Mesh(carBodyGeo, carBodyMat);
      carBody.position.y = 0.8;
      carBody.castShadow = true;
      car.add(carBody);

      // Roof
      const roofGeo = new THREE.BoxGeometry(2, 0.8, 1.5);
      const roofMat = new THREE.MeshStandardMaterial({ color: 0x1e293b });
      const roof = new THREE.Mesh(roofGeo, roofMat);
      roof.position.set(-0.2, 1.7, 0);
      car.add(roof);

      car.position.set((i * 20) - 70, 0.1, -55 + (i % 2 === 0 ? 3 : -3));
      car.userData = { speed: (i % 2 === 0 ? 0.35 : -0.4), xBound: 75 };
      carsGroup.add(car);
    }
    townGroup.add(carsGroup);

    // 3. 3-ACRE CENTRAL ECO-PARK (Sector: park-3acre)
    const parkGroup = new THREE.Group();
    parkGroup.name = "park";

    // Park base turf (Elevation slightly raised)
    const parkLawnGeo = new THREE.BoxGeometry(42, 0.4, 34);
    const parkLawnMat = new THREE.MeshStandardMaterial({ color: 0x4ade80, roughness: 0.7 });
    const parkLawn = new THREE.Mesh(parkLawnGeo, parkLawnMat);
    parkLawn.position.set(-24, 0.2, 22);
    parkLawn.receiveShadow = true;
    parkGroup.add(parkLawn);

    // 1.2km Synthetic Jogging Loop (Brown track)
    const trackCurveGeo = new THREE.RingGeometry(14, 16.5, 32);
    const trackMat = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.9 });
    const track = new THREE.Mesh(trackCurveGeo, trackMat);
    track.rotation.x = -Math.PI / 2;
    track.position.set(-24, 0.45, 22);
    parkGroup.add(track);

    // Children's Playground Area (Zone A - Colorful structures)
    const playAreaBase = new THREE.Mesh(
      new THREE.BoxGeometry(10, 0.2, 10),
      new THREE.MeshStandardMaterial({ color: 0xfbbf24 })
    );
    playAreaBase.position.set(-33, 0.5, 16);
    parkGroup.add(playAreaBase);

    // Playground Slide & Climbing Tower
    const tower = new THREE.Mesh(
      new THREE.CylinderGeometry(1.2, 1.4, 4, 8),
      new THREE.MeshStandardMaterial({ color: 0xef4444 })
    );
    tower.position.set(-33, 2.5, 16);
    tower.castShadow = true;
    parkGroup.add(tower);

    const slide = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 0.2, 4),
      new THREE.MeshStandardMaterial({ color: 0x3b82f6 })
    );
    slide.position.set(-33, 1.6, 19);
    slide.rotation.x = Math.PI / 6;
    parkGroup.add(slide);

    // Elders Serene Pavilion (Zone B - White Octagon Gazebo)
    const gazeboBase = new THREE.Mesh(
      new THREE.CylinderGeometry(3.5, 3.8, 0.5, 8),
      new THREE.MeshStandardMaterial({ color: 0xe2e8f0 })
    );
    gazeboBase.position.set(-16, 0.6, 16);
    parkGroup.add(gazeboBase);

    const gazeboRoof = new THREE.Mesh(
      new THREE.ConeGeometry(4.5, 2.5, 8),
      new THREE.MeshStandardMaterial({ color: 0x059669 })
    );
    gazeboRoof.position.set(-16, 3.8, 16);
    gazeboRoof.castShadow = true;
    parkGroup.add(gazeboRoof);

    // Open Air Gym Station (Zone C)
    const gymStation = new THREE.Mesh(
      new THREE.BoxGeometry(8, 0.2, 8),
      new THREE.MeshStandardMaterial({ color: 0x64748b })
    );
    gymStation.position.set(-24, 0.5, 30);
    parkGroup.add(gymStation);

    // Procedural Trees inside the 3-acre park
    for (let i = 0; i < 28; i++) {
      const tree = new THREE.Group();
      const trunk = new THREE.Mesh(
        new THREE.CylinderGeometry(0.25, 0.35, 3, 6),
        new THREE.MeshStandardMaterial({ color: 0x78350f })
      );
      trunk.position.y = 1.5;
      trunk.castShadow = true;
      tree.add(trunk);

      const canopy = new THREE.Mesh(
        new THREE.SphereGeometry(1.6 + Math.random() * 0.8, 8, 8),
        new THREE.MeshStandardMaterial({
          color: [0x15803d, 0x16a34a, 0x22c55e, 0x14532d][i % 4],
          roughness: 0.9
        })
      );
      canopy.position.y = 3.8;
      canopy.castShadow = true;
      tree.add(canopy);

      const randX = -40 + Math.random() * 32;
      const randZ = 8 + Math.random() * 28;
      tree.position.set(randX, 0.4, randZ);
      parkGroup.add(tree);
    }
    townGroup.add(parkGroup);

    // 4. 100-BED MULTI-SPECIALTY HOSPITAL (Sector: hospital-sector)
    const hospitalGroup = new THREE.Group();
    hospitalGroup.name = "hospital";

    // Main G+4 Hospital Building
    const hospMain = new THREE.Mesh(
      new THREE.BoxGeometry(22, 12, 16),
      new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.3, metalness: 0.1 })
    );
    hospMain.position.set(30, 6, 24);
    hospMain.castShadow = true;
    hospMain.receiveShadow = true;
    hospitalGroup.add(hospMain);

    // Glass Atrium Facade
    const glassAtrium = new THREE.Mesh(
      new THREE.BoxGeometry(10, 10, 1),
      new THREE.MeshStandardMaterial({ color: 0x0284c7, transparent: true, opacity: 0.6, metalness: 0.9 })
    );
    glassAtrium.position.set(30, 5, 15.6);
    hospitalGroup.add(glassAtrium);

    // Red Cross Symbol on Facade
    const crossV = new THREE.Mesh(new THREE.BoxGeometry(1, 3.5, 0.2), new THREE.MeshBasicMaterial({ color: 0xdc2626 }));
    crossV.position.set(30, 9, 15.8);
    hospitalGroup.add(crossV);
    const crossH = new THREE.Mesh(new THREE.BoxGeometry(3.5, 1, 0.2), new THREE.MeshBasicMaterial({ color: 0xdc2626 }));
    crossH.position.set(30, 9, 15.8);
    hospitalGroup.add(crossH);

    // Rooftop Helipad
    const helipad = new THREE.Mesh(
      new THREE.CylinderGeometry(5.5, 5.5, 0.4, 16),
      new THREE.MeshStandardMaterial({ color: 0x334155 })
    );
    helipad.position.set(30, 12.2, 24);
    hospitalGroup.add(helipad);

    // 'H' Letter on Helipad
    const hBar1 = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.1, 4), new THREE.MeshBasicMaterial({ color: 0xfacc15 }));
    hBar1.position.set(28.5, 12.5, 24);
    hospitalGroup.add(hBar1);
    const hBar2 = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.1, 4), new THREE.MeshBasicMaterial({ color: 0xfacc15 }));
    hBar2.position.set(31.5, 12.5, 24);
    hospitalGroup.add(hBar2);
    const hCross = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.1, 0.6), new THREE.MeshBasicMaterial({ color: 0xfacc15 }));
    hCross.position.set(30, 12.5, 24);
    hospitalGroup.add(hCross);

    // Ambulance Docking Bay
    const ambBay = new THREE.Mesh(
      new THREE.BoxGeometry(12, 3, 6),
      new THREE.MeshStandardMaterial({ color: 0xe2e8f0 })
    );
    ambBay.position.set(30, 1.5, 12);
    hospitalGroup.add(ambBay);

    townGroup.add(hospitalGroup);

    // 5. INTEGRATED SMART ACADEMY / SCHOOL (Sector: school-sector)
    const schoolGroup = new THREE.Group();
    schoolGroup.name = "school";

    // Main Academic Quadrangle Building (U-Shaped or Wide block)
    const schoolMain = new THREE.Mesh(
      new THREE.BoxGeometry(26, 7, 14),
      new THREE.MeshStandardMaterial({ color: 0xfef08a, roughness: 0.5 }) // Modern school brick-yellow
    );
    schoolMain.position.set(32, 3.5, -20);
    schoolMain.castShadow = true;
    schoolGroup.add(schoolMain);

    // Clock Tower / Science Pavilion
    const towerSchool = new THREE.Mesh(
      new THREE.BoxGeometry(5, 12, 5),
      new THREE.MeshStandardMaterial({ color: 0xb45309 })
    );
    towerSchool.position.set(22, 6, -15);
    towerSchool.castShadow = true;
    schoolGroup.add(towerSchool);

    // Sports Field & 400m Track
    const field = new THREE.Mesh(
      new THREE.BoxGeometry(22, 0.2, 16),
      new THREE.MeshStandardMaterial({ color: 0x15803d })
    );
    field.position.set(32, 0.15, -36);
    field.receiveShadow = true;
    schoolGroup.add(field);

    const schoolTrack = new THREE.Mesh(
      new THREE.RingGeometry(8, 10.5, 24),
      new THREE.MeshStandardMaterial({ color: 0xc2410c })
    );
    schoolTrack.rotation.x = -Math.PI / 2;
    schoolTrack.position.set(32, 0.28, -36);
    schoolGroup.add(schoolTrack);

    townGroup.add(schoolGroup);

    // 6. RESIDENTIAL SECTOR: VILLAMENTS & SMART ECO-VILLAS (Sector: housing-sector)
    const housingGroup = new THREE.Group();
    housingGroup.name = "housing";

    // Cluster A: Native Villaments (Terraced 3-floor modern village homes with solar)
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 4; c++) {
        const villa = new THREE.Group();
        const villaBody = new THREE.Mesh(
          new THREE.BoxGeometry(5.5, 4.5, 5.5),
          new THREE.MeshStandardMaterial({
            color: [0xffedd5, 0xfef3c7, 0xf1f5f9][(r + c) % 3],
            roughness: 0.6
          })
        );
        villaBody.position.y = 2.25;
        villaBody.castShadow = true;
        villa.add(villaBody);

        // Rooftop Solar Panel
        const solarPanel = new THREE.Mesh(
          new THREE.BoxGeometry(3.5, 0.2, 2.5),
          new THREE.MeshStandardMaterial({ color: 0x1e3a8a, metalness: 0.9, roughness: 0.1 })
        );
        solarPanel.position.set(0, 4.6, 0);
        solarPanel.rotation.x = 0.2;
        villa.add(solarPanel);

        villa.position.set(-52 + c * 7.5, 0.1, -15 - r * 8);
        housingGroup.add(villa);
      }
    }

    // Cluster B: Modern Eco-Villas (Sector 2)
    for (let r = 0; r < 2; r++) {
      for (let c = 0; c < 3; c++) {
        const modernVilla = new THREE.Group();
        const bld = new THREE.Mesh(
          new THREE.BoxGeometry(7, 6, 7),
          new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0.1, roughness: 0.2 })
        );
        bld.position.y = 3;
        bld.castShadow = true;
        modernVilla.add(bld);

        // Dark wood accent box
        const accent = new THREE.Mesh(
          new THREE.BoxGeometry(3.5, 2.5, 7.2),
          new THREE.MeshStandardMaterial({ color: 0x78350f })
        );
        accent.position.set(1.5, 4, 0);
        modernVilla.add(accent);

        modernVilla.position.set(-18 + c * 10, 0.1, -22 - r * 11);
        housingGroup.add(modernVilla);
      }
    }
    townGroup.add(housingGroup);

    // 7. SPORTS COMPLEX & INDOOR GYM (Sector: gym-sports)
    const gymGroup = new THREE.Group();
    gymGroup.name = "gym";
    const gymBld = new THREE.Mesh(
      new THREE.BoxGeometry(16, 7, 12),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.3 })
    );
    gymBld.position.set(-28, 3.5, 48);
    gymBld.castShadow = true;
    gymGroup.add(gymBld);

    // Glass wall for gym
    const gymGlass = new THREE.Mesh(
      new THREE.BoxGeometry(16.2, 5, 4),
      new THREE.MeshStandardMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.7 })
    );
    gymGlass.position.set(-28, 3, 48);
    gymGroup.add(gymGlass);

    // Swimming Pool outside gym
    const pool = new THREE.Mesh(
      new THREE.BoxGeometry(10, 0.3, 6),
      new THREE.MeshStandardMaterial({ color: 0x06b6d4, roughness: 0.05, metalness: 0.5 })
    );
    pool.position.set(-12, 0.2, 48);
    gymGroup.add(pool);

    townGroup.add(gymGroup);

    // 8. 3.5 MW SOLAR FARM & ZERO-WASTE STP (Sector: utilities-sector)
    const utilGroup = new THREE.Group();
    utilGroup.name = "utilities";

    // Solar Farm Rows
    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 5; c++) {
        const solarRow = new THREE.Mesh(
          new THREE.BoxGeometry(3.5, 0.2, 2.2),
          new THREE.MeshStandardMaterial({
            color: 0x1d4ed8,
            metalness: 0.95,
            roughness: 0.1
          })
        );
        solarRow.position.set(16 + c * 4.5, 1.2, 44 + r * 3.5);
        solarRow.rotation.x = -0.35;
        solarRow.castShadow = true;
        utilGroup.add(solarRow);
      }
    }

    // STP Bioreactor Tanks (Cylinders)
    for (let t = 0; t < 2; t++) {
      const stpTank = new THREE.Mesh(
        new THREE.CylinderGeometry(3.5, 3.5, 4.5, 16),
        new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.5 })
      );
      stpTank.position.set(44 + t * 9, 2.25, 48);
      stpTank.castShadow = true;
      utilGroup.add(stpTank);
    }
    townGroup.add(utilGroup);

    // Mouse Interaction / Raycasting for Pins & Controls
    let isDragging = false;
    let previousMousePosition = { x: 0, y: 0 };
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      setIsRotating(false);
      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging || !cameraRef.current) return;
      const deltaX = e.clientX - previousMousePosition.x;
      const deltaY = e.clientY - previousMousePosition.y;

      const rotSpeed = 0.005;
      const cam = cameraRef.current;
      
      // Orbit around center
      const radius = Math.sqrt(cam.position.x * cam.position.x + cam.position.z * cam.position.z);
      let angle = Math.atan2(cam.position.z, cam.position.x) - deltaX * rotSpeed;
      cam.position.x = radius * Math.cos(angle);
      cam.position.z = radius * Math.sin(angle);
      cam.position.y = Math.max(15, Math.min(110, cam.position.y + deltaY * 0.2));
      cam.lookAt(currentLookAtRef.current);

      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      if (!cameraRef.current) return;
      const zoomFactor = e.deltaY * 0.05;
      const cam = cameraRef.current;
      const dir = new THREE.Vector3().subVectors(cam.position, currentLookAtRef.current).normalize();
      const dist = cam.position.distanceTo(currentLookAtRef.current);
      if ((dist > 25 && zoomFactor < 0) || (dist < 180 && zoomFactor > 0)) {
        cam.position.addScaledVector(dir, zoomFactor);
      }
    };

    const domElement = canvasRef.current;
    domElement.addEventListener("mousedown", onMouseDown);
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
    domElement.addEventListener("wheel", onWheel, { passive: false });

    // Handle Window Resize
    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const newWidth = containerRef.current.clientWidth;
      const newHeight = containerRef.current.clientHeight || 550;
      cameraRef.current.aspect = newWidth / newHeight;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(newWidth, newHeight);
    };
    window.addEventListener("resize", handleResize);

    // Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const delta = clock.getDelta();

      // Smooth camera interpolation towards target
      if (cameraRef.current) {
        cameraRef.current.position.lerp(cameraTargetRef.current.pos, 0.04);
        currentLookAtRef.current.lerp(cameraTargetRef.current.lookAt, 0.04);
        cameraRef.current.lookAt(currentLookAtRef.current);
      }

      // Auto slow turntable rotation when idle
      if (isRotating && townGroup && !isDragging) {
        townGroup.rotation.y += delta * 0.04;
      }

      // Move EV Cars along road
      if (carsGroup) {
        carsGroup.children.forEach((car) => {
          const speed = car.userData.speed || 0.3;
          car.position.x += speed;
          if (car.position.x > 75) car.position.x = -75;
          if (car.position.x < -75) car.position.x = 75;
        });
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      domElement.removeEventListener("mousedown", onMouseDown);
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
      domElement.removeEventListener("wheel", onWheel);
      window.removeEventListener("resize", handleResize);
      renderer.dispose();
    };
  }, [isRotating]);

  // Handle Layer Visibility
  useEffect(() => {
    if (!objectsGroupRef.current) return;
    objectsGroupRef.current.traverse((child) => {
      if (child.name === "roads") child.visible = activeLayers.roads;
      if (child.name === "park") child.visible = activeLayers.park;
      if (child.name === "hospital") child.visible = activeLayers.hospital;
      if (child.name === "school") child.visible = activeLayers.school;
      if (child.name === "housing") child.visible = activeLayers.housing;
      if (child.name === "utilities") child.visible = activeLayers.utilities;
    });
  }, [activeLayers]);

  // Handle Time of Day Lighting
  useEffect(() => {
    if (!sceneRef.current || !lightsRef.current) return;
    const { ambient, directional, pointLights } = lightsRef.current;

    if (timeOfDay === "day") {
      sceneRef.current.background = new THREE.Color(0xf0fdf4);
      sceneRef.current.fog = new THREE.FogExp2(0xe2f1e8, 0.0035);
      ambient.color.setHex(0xffffff);
      ambient.intensity = 0.95;
      directional.color.setHex(0xfffaed);
      directional.intensity = 1.4;
      pointLights.forEach((pl) => (pl.intensity = 0));
    } else if (timeOfDay === "sunset") {
      sceneRef.current.background = new THREE.Color(0xffedd5);
      sceneRef.current.fog = new THREE.FogExp2(0xfed7aa, 0.004);
      ambient.color.setHex(0xfb923c);
      ambient.intensity = 0.8;
      directional.color.setHex(0xf97316);
      directional.intensity = 1.8;
      pointLights.forEach((pl) => (pl.intensity = 0.4));
    } else if (timeOfDay === "night") {
      sceneRef.current.background = new THREE.Color(0x090d16);
      sceneRef.current.fog = new THREE.FogExp2(0x0f172a, 0.005);
      ambient.color.setHex(0x1e293b);
      ambient.intensity = 0.35;
      directional.color.setHex(0x38bdf8);
      directional.intensity = 0.4;
      pointLights.forEach((pl) => (pl.intensity = 2.2));
    }
  }, [timeOfDay]);

  // Camera Presets
  const setCameraPreset = (presetKey: string) => {
    setActivePreset(presetKey);
    setIsRotating(false);

    switch (presetKey) {
      case "overview":
        cameraTargetRef.current = {
          pos: new THREE.Vector3(70, 60, 80),
          lookAt: new THREE.Vector3(0, 0, 0)
        };
        setSelectedPin(null);
        break;
      case "park-3acre":
        cameraTargetRef.current = {
          pos: new THREE.Vector3(-24, 25, 52),
          lookAt: new THREE.Vector3(-24, 0, 22)
        };
        const park = DEDICATED_SECTORS.find((s) => s.id === "park-3acre");
        if (park) setSelectedPin(park);
        break;
      case "hospital-sector":
        cameraTargetRef.current = {
          pos: new THREE.Vector3(30, 24, 50),
          lookAt: new THREE.Vector3(30, 5, 20)
        };
        const hosp = DEDICATED_SECTORS.find((s) => s.id === "hospital-sector");
        if (hosp) setSelectedPin(hosp);
        break;
      case "school-sector":
        cameraTargetRef.current = {
          pos: new THREE.Vector3(32, 22, 6),
          lookAt: new THREE.Vector3(32, 4, -20)
        };
        const school = DEDICATED_SECTORS.find((s) => s.id === "school-sector");
        if (school) setSelectedPin(school);
        break;
      case "roads-sector":
        cameraTargetRef.current = {
          pos: new THREE.Vector3(0, 30, -18),
          lookAt: new THREE.Vector3(0, 0, -55)
        };
        const roads = DEDICATED_SECTORS.find((s) => s.id === "roads-sector");
        if (roads) setSelectedPin(roads);
        break;
      case "housing-sector":
        cameraTargetRef.current = {
          pos: new THREE.Vector3(-45, 24, 10),
          lookAt: new THREE.Vector3(-45, 3, -20)
        };
        const housing = DEDICATED_SECTORS.find((s) => s.id === "housing-sector");
        if (housing) setSelectedPin(housing);
        break;
      case "utilities-sector":
        cameraTargetRef.current = {
          pos: new THREE.Vector3(30, 22, 75),
          lookAt: new THREE.Vector3(30, 2, 46)
        };
        const util = DEDICATED_SECTORS.find((s) => s.id === "utilities-sector");
        if (util) setSelectedPin(util);
        break;
      default:
        break;
    }
  };

  return (
    <div className="relative w-full rounded-3xl overflow-hidden border border-white/10 glass-panel shadow-2xl">
      {/* 3D Canvas Viewport */}
      <div ref={containerRef} className="relative w-full h-[540px] md:h-[620px] cursor-grab active:cursor-grabbing">
        <canvas ref={canvasRef} className="w-full h-full block" />

        {/* Floating Top Header Controls Bar */}
        <div className="absolute top-4 left-4 right-4 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
          {/* Left badge & status */}
          <div className="pointer-events-auto bg-[#070b14]/85 backdrop-blur-xl px-4 py-2 rounded-2xl border border-white/10 text-white flex items-center gap-3 shadow-2xl">
            <div className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
            </div>
            <div>
              <div className="text-xs font-bold text-cyan-400 tracking-wider uppercase">
                Interactive 3D Masterplan 2028
              </div>
              <div className="text-sm font-extrabold text-white flex items-center gap-1.5">
                Vikasgram Mini Township <span className="text-xs font-normal text-slate-400">(180 Acres)</span>
              </div>
            </div>
          </div>

          {/* Right quick simulation toggles */}
          <div className="pointer-events-auto flex items-center gap-2 bg-[#070b14]/85 backdrop-blur-xl p-1.5 rounded-2xl border border-white/10 shadow-2xl">
            {/* Time of Day */}
            <div className="flex bg-slate-900/90 rounded-xl p-0.5 border border-white/5">
              <button
                onClick={() => setTimeOfDay("day")}
                title="Day Sunlight Mode"
                className={`p-1.5 rounded-lg text-xs font-medium transition ${
                  timeOfDay === "day" ? "bg-amber-400 text-slate-950 font-bold shadow-md shadow-amber-400/30" : "text-slate-400 hover:text-white"
                }`}
              >
                <Sun className="w-4 h-4" />
              </button>
              <button
                onClick={() => setTimeOfDay("sunset")}
                title="Golden Hour Sunset Mode"
                className={`p-1.5 rounded-lg text-xs font-medium transition ${
                  timeOfDay === "sunset" ? "bg-orange-500 text-white font-bold shadow-md shadow-orange-500/30" : "text-slate-400 hover:text-white"
                }`}
              >
                <Sunset className="w-4 h-4" />
              </button>
              <button
                onClick={() => setTimeOfDay("night")}
                title="Night Illumination & Streetlights"
                className={`p-1.5 rounded-lg text-xs font-medium transition ${
                  timeOfDay === "night" ? "bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30" : "text-slate-400 hover:text-white"
                }`}
              >
                <Moon className="w-4 h-4" />
              </button>
            </div>

            {/* Turntable Rotation toggle */}
            <button
              onClick={() => setIsRotating(!isRotating)}
              title={isRotating ? "Pause auto-rotation" : "Enable 360° orbit rotation"}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition ${
                isRotating ? "bg-blue-600 text-white border border-blue-400/30 shadow-lg shadow-blue-600/20" : "bg-slate-900 text-slate-300 hover:text-white border border-white/5"
              }`}
            >
              <RotateCcw className={`w-3.5 h-3.5 ${isRotating ? "animate-spin" : ""}`} />
              <span className="hidden sm:inline">{isRotating ? "Auto Orbit ON" : "Orbit Paused"}</span>
            </button>

            {/* Reset View */}
            <button
              onClick={() => setCameraPreset("overview")}
              title="Reset to Masterplan View"
              className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white transition border border-white/5"
            >
              <Compass className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Floating Quick Camera Presets (Bottom Left) */}
        <div className="absolute bottom-4 left-4 right-4 md:right-auto flex flex-wrap items-center gap-1.5 pointer-events-auto bg-[#070b14]/90 backdrop-blur-xl p-2 rounded-2xl border border-white/10 shadow-2xl max-w-2xl">
          <div className="text-[11px] font-bold text-slate-400 px-2 uppercase tracking-wider hidden sm:block">
            Focus Sector:
          </div>
          <button
            onClick={() => setCameraPreset("overview")}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-medium transition ${
              activePreset === "overview" ? "bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-bold shadow-md shadow-blue-600/25 border border-cyan-400/30" : "text-slate-300 hover:bg-white/5"
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setCameraPreset("park-3acre")}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-medium transition ${
              activePreset === "park-3acre" ? "bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-bold shadow-md shadow-blue-600/25 border border-cyan-400/30" : "text-slate-300 hover:bg-white/5"
            }`}
          >
            🌳 3-Acre Central Park
          </button>
          <button
            onClick={() => setCameraPreset("hospital-sector")}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-medium transition ${
              activePreset === "hospital-sector" ? "bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-bold shadow-md shadow-blue-600/25 border border-cyan-400/30" : "text-slate-300 hover:bg-white/5"
            }`}
          >
            🏥 100-Bed Hospital
          </button>
          <button
            onClick={() => setCameraPreset("school-sector")}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-medium transition ${
              activePreset === "school-sector" ? "bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-bold shadow-md shadow-blue-600/25 border border-cyan-400/30" : "text-slate-300 hover:bg-white/5"
            }`}
          >
            🏫 Smart School
          </button>
          <button
            onClick={() => setCameraPreset("roads-sector")}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-medium transition ${
              activePreset === "roads-sector" ? "bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-bold shadow-md shadow-blue-600/25 border border-cyan-400/30" : "text-slate-300 hover:bg-white/5"
            }`}
          >
            🛣️ 6-Lane Bypass
          </button>
          <button
            onClick={() => setCameraPreset("housing-sector")}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-medium transition ${
              activePreset === "housing-sector" ? "bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-bold shadow-md shadow-blue-600/25 border border-cyan-400/30" : "text-slate-300 hover:bg-white/5"
            }`}
          >
            🏡 Smart Housing
          </button>
          <button
            onClick={() => setCameraPreset("utilities-sector")}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-medium transition ${
              activePreset === "utilities-sector" ? "bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-bold shadow-md shadow-blue-600/25 border border-cyan-400/30" : "text-slate-300 hover:bg-white/5"
            }`}
          >
            ⚡ Solar & STP
          </button>
        </div>

        {/* Selected Pin / Floating Sector Telemetry Card */}
        {selectedPin && (
          <div className="absolute bottom-20 md:bottom-6 right-4 w-[92%] sm:w-84 bg-[#070b14]/95 backdrop-blur-2xl border border-cyan-500/30 rounded-2xl p-4 text-white shadow-2xl pointer-events-auto transition animate-in fade-in slide-in-from-bottom-4">
            <div className="flex items-start justify-between gap-2 mb-2">
              <div>
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-cyan-300 bg-cyan-950/80 px-2.5 py-0.5 rounded-full border border-cyan-500/30">
                  <CheckCircle2 className="w-3 h-3 text-cyan-400" /> {selectedPin.status} ({selectedPin.completionPercentage}%)
                </span>
                <h4 className="text-base font-bold text-white mt-1 leading-snug">{selectedPin.name}</h4>
              </div>
              <button
                onClick={() => setSelectedPin(null)}
                className="text-slate-400 hover:text-white text-xs px-2 py-0.5 rounded-lg bg-slate-800 border border-white/10"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-300 line-clamp-2 mb-3 leading-relaxed">
              {selectedPin.description}
            </p>

            <div className="grid grid-cols-2 gap-2 text-xs bg-slate-900/80 rounded-xl p-2.5 mb-3 border border-white/10">
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Target Handover</div>
                <div className="font-bold text-cyan-300">{selectedPin.targetDate}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Sanctioned Budget</div>
                <div className="font-bold text-white">{selectedPin.budgetAllocated}</div>
              </div>
            </div>

            <button
              onClick={() => onSelectSector(selectedPin.id)}
              className="w-full py-2 px-3 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition shadow-lg shadow-cyan-500/25 border border-cyan-400/30"
            >
              <span>Explore Detailed Status & Milestones</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* 3D Navigation Guide Tip */}
        <div className="absolute top-20 right-4 hidden md:flex items-center gap-2 bg-[#070b14]/70 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/10 text-[11px] text-slate-300 pointer-events-none">
          <Navigation className="w-3.5 h-3.5 text-cyan-400" />
          <span>Left-click + Drag to Rotate • Scroll to Zoom • Right-click to Pan</span>
        </div>
      </div>

      {/* Layer Filter Bar underneath canvas */}
      <div className="bg-[#030509] px-4 py-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 text-slate-400">
          <Layers className="w-4 h-4 text-cyan-400" />
          <span className="font-semibold text-slate-300">Active 3D Infrastructure Layers:</span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-1.5 bg-[#0b0f19] hover:bg-slate-800/80 px-2.5 py-1 rounded-xl cursor-pointer transition border border-white/10 text-slate-200">
            <input
              type="checkbox"
              checked={activeLayers.roads}
              onChange={(e) => setActiveLayers({ ...activeLayers, roads: e.target.checked })}
              className="accent-cyan-500 rounded"
            />
            <span>🛣️ Roads & Expressway</span>
          </label>
          <label className="flex items-center gap-1.5 bg-[#0b0f19] hover:bg-slate-800/80 px-2.5 py-1 rounded-xl cursor-pointer transition border border-white/10 text-slate-200">
            <input
              type="checkbox"
              checked={activeLayers.park}
              onChange={(e) => setActiveLayers({ ...activeLayers, park: e.target.checked })}
              className="accent-cyan-500 rounded"
            />
            <span>🌳 3-Acre Central Park</span>
          </label>
          <label className="flex items-center gap-1.5 bg-[#0b0f19] hover:bg-slate-800/80 px-2.5 py-1 rounded-xl cursor-pointer transition border border-white/10 text-slate-200">
            <input
              type="checkbox"
              checked={activeLayers.hospital}
              onChange={(e) => setActiveLayers({ ...activeLayers, hospital: e.target.checked })}
              className="accent-cyan-500 rounded"
            />
            <span>🏥 100-Bed Hospital</span>
          </label>
          <label className="flex items-center gap-1.5 bg-[#0b0f19] hover:bg-slate-800/80 px-2.5 py-1 rounded-xl cursor-pointer transition border border-white/10 text-slate-200">
            <input
              type="checkbox"
              checked={activeLayers.school}
              onChange={(e) => setActiveLayers({ ...activeLayers, school: e.target.checked })}
              className="accent-cyan-500 rounded"
            />
            <span>🏫 Smart School</span>
          </label>
          <label className="flex items-center gap-1.5 bg-[#0b0f19] hover:bg-slate-800/80 px-2.5 py-1 rounded-xl cursor-pointer transition border border-white/10 text-slate-200">
            <input
              type="checkbox"
              checked={activeLayers.housing}
              onChange={(e) => setActiveLayers({ ...activeLayers, housing: e.target.checked })}
              className="accent-cyan-500 rounded"
            />
            <span>🏡 Residential Sectors</span>
          </label>
          <label className="flex items-center gap-1.5 bg-[#0b0f19] hover:bg-slate-800/80 px-2.5 py-1 rounded-xl cursor-pointer transition border border-white/10 text-slate-200">
            <input
              type="checkbox"
              checked={activeLayers.utilities}
              onChange={(e) => setActiveLayers({ ...activeLayers, utilities: e.target.checked })}
              className="accent-cyan-500 rounded"
            />
            <span>⚡ Solar & STP Grid</span>
          </label>
        </div>
      </div>
    </div>
  );
};
