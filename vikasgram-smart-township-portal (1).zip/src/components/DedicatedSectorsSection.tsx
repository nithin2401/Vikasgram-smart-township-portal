import React, { useState } from "react";
import { 
  Trees, 
  Hospital, 
  GraduationCap, 
  Route, 
  Home, 
  Dumbbell, 
  Zap, 
  CheckCircle2, 
  Clock, 
  DollarSign, 
  ShieldCheck, 
  ArrowRight, 
  Sparkles, 
  Heart, 
  Users, 
  Compass, 
  Calendar,
  Layers,
  FileText,
  Activity,
  PhoneCall,
  Calculator,
  Award
} from "lucide-react";
import { SectorInfo } from "../types";
import { DEDICATED_SECTORS, HOUSING_OPTIONS } from "../data/townshipData";

interface DedicatedSectorsSectionProps {
  activeSectorId: string;
  onSelectSector: (sectorId: string) => void;
  onOpenBooking: (purpose?: string) => void;
}

export const DedicatedSectorsSection: React.FC<DedicatedSectorsSectionProps> = ({
  activeSectorId,
  onSelectSector,
  onOpenBooking,
}) => {
  const currentSector = DEDICATED_SECTORS.find((s) => s.id === activeSectorId) || DEDICATED_SECTORS[0];

  // Interactive Sub-states for specific sectors
  const [selectedParkZone, setSelectedParkZone] = useState<"children" | "elders" | "gym" | "canopy">("children");
  const [calcUnitType, setCalcUnitType] = useState<string>("unit-garden-2bhk");
  const [calcDownPayment, setCalcDownPayment] = useState<number>(20);
  const [calcTenureYears, setCalcTenureYears] = useState<number>(20);

  // EMI Calculator Calculation
  const selectedHousingUnit = HOUSING_OPTIONS.find((u) => u.id === calcUnitType) || HOUSING_OPTIONS[1];
  const unitPriceNumber = calcUnitType === "unit-villament" ? 0 : (calcUnitType === "unit-garden-2bhk" ? 4850000 : (calcUnitType === "unit-villa-3bhk" ? 11500000 : 17500000));
  const loanPrincipal = unitPriceNumber * (1 - calcDownPayment / 100);
  const annualInterestRate = 0.0825; // 8.25%
  const monthlyRate = annualInterestRate / 12;
  const totalMonths = calcTenureYears * 12;
  const calculatedEmi = unitPriceNumber === 0 ? 0 : Math.round((loanPrincipal * monthlyRate * Math.pow(1 + monthlyRate, totalMonths)) / (Math.pow(1 + monthlyRate, totalMonths) - 1));

  const getSectorIcon = (category: string) => {
    switch (category) {
      case "park": return <Trees className="w-5 h-5" />;
      case "hospital": return <Hospital className="w-5 h-5" />;
      case "school": return <GraduationCap className="w-5 h-5" />;
      case "roads": return <Route className="w-5 h-5" />;
      case "housing": return <Home className="w-5 h-5" />;
      case "gym": return <Dumbbell className="w-5 h-5" />;
      case "utilities": return <Zap className="w-5 h-5" />;
      default: return <Layers className="w-5 h-5" />;
    }
  };

  return (
    <div className="glass-panel border border-white/10 rounded-3xl p-6 md:p-10 shadow-2xl space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 text-cyan-300 text-xs font-bold uppercase tracking-wider mb-2 border border-cyan-500/30">
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span>Dedicated Infrastructure Status Reports</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-black text-white tracking-tight">
            Sector-by-Sector Development Breakdown
          </h2>
          <p className="text-slate-300 text-sm mt-1 max-w-3xl">
            Select any infrastructure vertical below for verified progress timelines, technical specifications, legal clearances, and live execution status.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onOpenBooking(currentSector.name)}
            className="px-4 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-cyan-500/20 flex items-center gap-2 transition border border-cyan-400/30"
          >
            <span>Book Visit for {currentSector.shortTitle}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Horizontal Sector Selector Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin">
        {DEDICATED_SECTORS.map((sector) => {
          const isActive = sector.id === currentSector.id;
          return (
            <button
              key={sector.id}
              onClick={() => onSelectSector(sector.id)}
              className={`flex items-center gap-2 px-4 py-3 rounded-2xl text-xs font-bold whitespace-nowrap transition-all duration-200 border ${
                isActive
                  ? "bg-blue-600 text-white border-blue-400/40 shadow-lg shadow-blue-600/30"
                  : "bg-[#0b0f19] text-slate-400 hover:text-white hover:bg-white/5 border-white/10"
              }`}
            >
              <span className={isActive ? "text-cyan-300" : "text-slate-400"}>
                {getSectorIcon(sector.category)}
              </span>
              <span>{sector.shortTitle}</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                isActive ? "bg-cyan-400 text-slate-950" : "bg-slate-800 text-slate-300"
              }`}>
                {sector.completionPercentage}%
              </span>
            </button>
          );
        })}
      </div>

      {/* Main Active Sector Detailed Showcase */}
      <div className="glass-card rounded-3xl p-6 md:p-8 border border-white/10 shadow-2xl space-y-8">
        {/* Sector Summary Banner */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start pb-8 border-b border-white/10">
          <div className="lg:col-span-2 space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 bg-emerald-950/80 text-emerald-300 text-xs font-bold rounded-full border border-emerald-500/30 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                {currentSector.status}
              </span>
              <span className="px-3 py-1 bg-slate-900 text-slate-300 text-xs font-semibold rounded-full border border-white/10">
                Lead: {currentSector.leadAgency}
              </span>
              <span className="px-3 py-1 bg-amber-950/70 text-amber-300 text-xs font-semibold rounded-full border border-amber-500/30">
                Target: {currentSector.targetDate}
              </span>
            </div>

            <h3 className="text-2xl md:text-3xl font-extrabold text-white">
              {currentSector.name}
            </h3>

            <p className="text-slate-300 text-sm leading-relaxed">
              {currentSector.description}
            </p>

            {/* Key Highlights bullet list */}
            <div className="space-y-2 pt-2">
              <div className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Core Masterplan Features:
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {currentSector.keyHighlights.map((highlight, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-slate-300 bg-[#090d16]/80 p-2.5 rounded-xl border border-white/10">
                    <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                    <span>{highlight}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Progress & Live Telemetry Gauge */}
          <div className="bg-[#070b14]/90 rounded-2xl p-6 text-white space-y-5 border border-white/10 shadow-2xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Progress Metrics</span>
              <span className="text-cyan-400 text-xs font-bold flex items-center gap-1">
                <Activity className="w-3.5 h-3.5 animate-pulse" /> Live Telemetry
              </span>
            </div>

            <div>
              <div className="flex items-baseline justify-between mb-2">
                <span className="text-3xl font-black text-white">{currentSector.completionPercentage}%</span>
                <span className="text-xs text-slate-400">Total Work Certified</span>
              </div>
              <div className="w-full bg-slate-900 h-3 rounded-full overflow-hidden p-0.5 border border-white/5">
                <div
                  className="bg-gradient-to-r from-blue-500 via-cyan-400 to-emerald-400 h-full rounded-full transition-all duration-1000"
                  style={{ width: `${currentSector.completionPercentage}%` }}
                ></div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-white/10">
              <div>
                <div className="text-[10px] text-slate-400 uppercase">Sanctioned Budget</div>
                <div className="font-bold text-white mt-0.5">{currentSector.budgetAllocated}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-400 uppercase">Target Handover</div>
                <div className="font-bold text-cyan-300 mt-0.5">{currentSector.targetDate}</div>
              </div>
            </div>

            {currentSector.liveMetrics && (
              <div className="space-y-2 pt-2 border-t border-white/10">
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Active Sector Sensors</div>
                {currentSector.liveMetrics.map((m, i) => (
                  <div key={i} className="flex items-center justify-between text-xs bg-slate-900/80 px-3 py-2 rounded-xl border border-white/5">
                    <span className="text-slate-300">{m.label}</span>
                    <span className="font-bold text-cyan-400">{m.value}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* SPECIALIZED SECTOR INTERACTIVE HUBS */}

        {/* 1. If Sector is 3-ACRE PARK: Interactive Zone Explorer */}
        {currentSector.id === "park-3acre" && (
          <div className="bg-[#051c14]/90 text-white rounded-3xl p-6 md:p-8 border border-emerald-500/30 shadow-2xl space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-1 border border-emerald-500/30">
                  <Trees className="w-3.5 h-3.5 text-emerald-400" />
                  <span>3-Acre Master Ecosystem Exploration</span>
                </div>
                <h4 className="text-xl md:text-2xl font-bold text-white">
                  Zone-wise Breakdown of the 3-Acre Central Eco-Park
                </h4>
                <p className="text-xs text-emerald-200/80 mt-0.5">
                  130,680 sq.ft designed for children, senior citizens, athletics, and bio-diversity preservation.
                </p>
              </div>

              {/* Zone Selector Buttons */}
              <div className="flex flex-wrap items-center gap-1.5 bg-[#03130d] p-1.5 rounded-2xl border border-emerald-500/30">
                <button
                  onClick={() => setSelectedParkZone("children")}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    selectedParkZone === "children"
                      ? "bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30"
                      : "text-emerald-200 hover:text-white"
                  }`}
                >
                  🚸 Children's Sensory Zone
                </button>
                <button
                  onClick={() => setSelectedParkZone("elders")}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    selectedParkZone === "elders"
                      ? "bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30"
                      : "text-emerald-200 hover:text-white"
                  }`}
                >
                  🧘 Elders Serene Pavilion
                </button>
                <button
                  onClick={() => setSelectedParkZone("gym")}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    selectedParkZone === "gym"
                      ? "bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30"
                      : "text-emerald-200 hover:text-white"
                  }`}
                >
                  🏃 Calisthenics & Jogging
                </button>
                <button
                  onClick={() => setSelectedParkZone("canopy")}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    selectedParkZone === "canopy"
                      ? "bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30"
                      : "text-emerald-200 hover:text-white"
                  }`}
                >
                  🌿 1,200 Trees & Bio-Lake
                </button>
              </div>
            </div>

            {/* Zone Details Container */}
            <div className="bg-[#042017]/70 rounded-2xl p-6 border border-emerald-500/30 grid grid-cols-1 lg:grid-cols-3 gap-6 items-center">
              <div className="lg:col-span-2 space-y-3">
                {selectedParkZone === "children" && (
                  <>
                    <h5 className="text-lg font-bold text-emerald-300">Zone A: Children's Adventure & Sensory Playground (32,000 sq.ft)</h5>
                    <p className="text-xs text-emerald-100 leading-relaxed">
                      Custom engineered with shock-absorbent non-toxic rubber turf, splash fountains with recycled STP water, wooden rope bridges, and outdoor science interactive models to stimulate physical and cognitive growth in children aged 2 to 14.
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-xs pt-2">
                      <div className="bg-[#02140e] p-2.5 rounded-xl border border-emerald-500/20">
                        <div className="font-bold text-white">German Safety Certified</div>
                        <div className="text-[10px] text-emerald-300">Zero sharp edges, non-slip rubber</div>
                      </div>
                      <div className="bg-[#02140e] p-2.5 rounded-xl border border-emerald-500/20">
                        <div className="font-bold text-white">Splash Water Zone</div>
                        <div className="text-[10px] text-emerald-300">UV-sterilized pressure fountains</div>
                      </div>
                    </div>
                  </>
                )}

                {selectedParkZone === "elders" && (
                  <>
                    <h5 className="text-lg font-bold text-emerald-300">Zone B: Senior Citizens Serene Pavilion & Acupressure Trail (28,500 sq.ft)</h5>
                    <p className="text-xs text-emerald-100 leading-relaxed">
                      A quiet, shaded sanctuary surrounded by medicinal and aromatic plants (Tulsi, Lavender, Neem). Features a 400-meter rounded pebble acupressure reflexology path, ergonomic stone seating with backrests, covered yoga gazebos, and 100% step-free wheelchair ramps.
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-xs pt-2">
                      <div className="bg-[#02140e] p-2.5 rounded-xl border border-emerald-500/20">
                        <div className="font-bold text-white">Reflexology Path</div>
                        <div className="text-[10px] text-emerald-300">Naturally smoothed river stones</div>
                      </div>
                      <div className="bg-[#02140e] p-2.5 rounded-xl border border-emerald-500/20">
                        <div className="font-bold text-white">Quiet Meditation Gazebo</div>
                        <div className="text-[10px] text-emerald-300">Acoustic botanical buffer zone</div>
                      </div>
                    </div>
                  </>
                )}

                {selectedParkZone === "gym" && (
                  <>
                    <h5 className="text-lg font-bold text-emerald-300">Zone C: Open-Air Calisthenics & 1.2km Jogging Loop (35,000 sq.ft)</h5>
                    <p className="text-xs text-emerald-100 leading-relaxed">
                      18 heavy-duty hydraulic resistance workout stations (pull-up bars, parallel bars, leg press, elliptical cross-trainers) along with a 1.2 km dual-lane rubberized track equipped with solar speed timers and hydration water kiosks.
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-xs pt-2">
                      <div className="bg-[#02140e] p-2.5 rounded-xl border border-emerald-500/20">
                        <div className="font-bold text-white">18 All-Weather Stations</div>
                        <div className="text-[10px] text-emerald-300">Hydraulic resistance without weights</div>
                      </div>
                      <div className="bg-[#02140e] p-2.5 rounded-xl border border-emerald-500/20">
                        <div className="font-bold text-white">1.2km Synthetic Track</div>
                        <div className="text-[10px] text-emerald-300">Knee-cushioning rubber granules</div>
                      </div>
                    </div>
                  </>
                )}

                {selectedParkZone === "canopy" && (
                  <>
                    <h5 className="text-lg font-bold text-emerald-300">Zone D: 1,200 Indigenous Shade Trees & Bio-Lake (35,180 sq.ft)</h5>
                    <p className="text-xs text-emerald-100 leading-relaxed">
                      Preserving 1,200 native species (Peepal, Banyan, Neem, Gulmohar, Amaltas) creating a micro-climate that reduces ambient summer temperature by 3.5°C. Features a 16-acre-foot percolation lake with solar aeration fountains.
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-xs pt-2">
                      <div className="bg-[#02140e] p-2.5 rounded-xl border border-emerald-500/20">
                        <div className="font-bold text-white">1,200 Native Trees</div>
                        <div className="text-[10px] text-emerald-300">100% drip irrigated with STP water</div>
                      </div>
                      <div className="bg-[#02140e] p-2.5 rounded-xl border border-emerald-500/20">
                        <div className="font-bold text-white">Natural Retention Lake</div>
                        <div className="text-[10px] text-emerald-300">Stormwater bio-filter basin</div>
                      </div>
                    </div>
                  </>
                )}
              </div>

              <div className="bg-[#02140e]/90 rounded-2xl p-4 border border-emerald-500/30 space-y-3">
                <div className="text-xs font-bold text-emerald-300 uppercase">3-Acre Quick Stats</div>
                <div className="space-y-1.5 text-xs text-emerald-100">
                  <div className="flex justify-between">
                    <span>Total Land:</span>
                    <span className="font-bold text-white">3.00 Acres</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Daily Visitors Capacity:</span>
                    <span className="font-bold text-white">1,500+</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Emergency SOS Poles:</span>
                    <span className="font-bold text-white">6 Active</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Entry Policy:</span>
                    <span className="font-bold text-emerald-400">100% Free & Open</span>
                  </div>
                </div>
                <button
                  onClick={() => onOpenBooking("3-Acre Park Tour & Guided Walk")}
                  className="w-full mt-2 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs transition"
                >
                  Schedule Guided Park Visit
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 2. If Sector is HOSPITAL: Emergency Readiness & Helipad Widget */}
        {currentSector.id === "hospital-sector" && (
          <div className="bg-[#1f0a0d]/90 text-white rounded-3xl p-6 md:p-8 border border-rose-500/30 shadow-2xl space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-950/80 text-rose-300 text-xs font-bold uppercase tracking-wider mb-1 border border-rose-500/30">
                  <Hospital className="w-3.5 h-3.5 text-rose-400" />
                  <span>100-Bed Tertiary Healthcare & Trauma Grid</span>
                </div>
                <h4 className="text-xl md:text-2xl font-bold text-white">
                  24x7 Emergency Response & Rooftop Aero-Medical Helipad
                </h4>
                <p className="text-xs text-rose-200/80 mt-0.5">
                  Connected to major super-specialty hospitals via tele-ICU and rapid air evacuation capability.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href="tel:18002008899"
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow border border-rose-400/30"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>24x7 Trauma Hotline: 1800-200-8899</span>
                </a>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-[#2a0d11]/80 rounded-2xl p-4 border border-rose-500/20 space-y-1">
                <div className="text-xs text-rose-300 uppercase font-semibold">ICU & Critical Care</div>
                <div className="text-2xl font-black text-white">20 Beds</div>
                <div className="text-[11px] text-rose-200">10 Adult ICU + 10 Neonatal NICU</div>
              </div>
              <div className="bg-[#2a0d11]/80 rounded-2xl p-4 border border-rose-500/20 space-y-1">
                <div className="text-xs text-rose-300 uppercase font-semibold">Rooftop Helipad</div>
                <div className="text-2xl font-black text-white">DGCA Approved</div>
                <div className="text-[11px] text-rose-200">Night-landing navigation beacons</div>
              </div>
              <div className="bg-[#2a0d11]/80 rounded-2xl p-4 border border-rose-500/20 space-y-1">
                <div className="text-xs text-rose-300 uppercase font-semibold">Native Villager Quota</div>
                <div className="text-2xl font-black text-white">100% Free OPD</div>
                <div className="text-[11px] text-rose-200">Free generic medicines & diagnostics</div>
              </div>
              <div className="bg-[#2a0d11]/80 rounded-2xl p-4 border border-rose-500/20 space-y-1">
                <div className="text-xs text-rose-300 uppercase font-semibold">EV Ambulance Fleet</div>
                <div className="text-2xl font-black text-white">3 ALS Units</div>
                <div className="text-[11px] text-rose-200">&lt; 5 min response inside township</div>
              </div>
            </div>
          </div>
        )}

        {/* 3. If Sector is HOUSING: Interactive Unit Customizer & EMI Calculator */}
        {currentSector.id === "housing-sector" && (
          <div className="bg-[#070b14]/90 text-white rounded-3xl p-6 md:p-8 border border-white/10 shadow-2xl space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/80 text-cyan-300 text-xs font-bold uppercase tracking-wider mb-1 border border-cyan-500/30">
                  <Calculator className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Township Housing Unit & Allotment Calculator</span>
                </div>
                <h4 className="text-xl md:text-2xl font-bold text-white">
                  Explore Residential Units & Estimate Your Monthly Investment
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  All units equipped with rooftop solar, piped gas, and access to 3-acre park.
                </p>
              </div>

              <button
                onClick={() => onOpenBooking("Residential Flat & Villa Inspection")}
                className="px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold rounded-xl text-xs transition border border-cyan-400/30 shadow-lg shadow-cyan-500/20"
              >
                Book Model Unit Walkthrough
              </button>
            </div>

            {/* Unit Picker Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {HOUSING_OPTIONS.map((unit) => (
                <div
                  key={unit.id}
                  onClick={() => setCalcUnitType(unit.id)}
                  className={`p-4 rounded-2xl border cursor-pointer transition flex flex-col justify-between ${
                    calcUnitType === unit.id
                      ? "bg-blue-950/80 border-cyan-400 shadow-xl shadow-cyan-500/10"
                      : "bg-[#0c121e]/80 border-white/10 hover:border-white/20"
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-cyan-400 font-bold">{unit.allotmentStatus}</span>
                      <span className="text-[10px] text-slate-400">{unit.carpetArea}</span>
                    </div>
                    <h5 className="font-bold text-white text-sm">{unit.title}</h5>
                    <div className="text-cyan-300 font-extrabold text-base mt-2">{unit.estimatedPrice}</div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-white/10 text-[11px] text-slate-300 space-y-1">
                    <div>⚡ Solar: {unit.solarCapacity}</div>
                    <div className="line-clamp-2 text-slate-400">{unit.floorPlanDetails}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Live EMI Matrix Bar */}
            {calcUnitType !== "unit-villament" && (
              <div className="bg-[#030509] rounded-2xl p-5 border border-white/10 grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
                <div>
                  <div className="text-xs text-slate-400 uppercase font-semibold">Down Payment (%): {calcDownPayment}%</div>
                  <input
                    type="range"
                    min="10"
                    max="50"
                    step="5"
                    value={calcDownPayment}
                    onChange={(e) => setCalcDownPayment(Number(e.target.value))}
                    className="w-full mt-2 accent-cyan-500 cursor-pointer"
                  />
                  <div className="text-xs text-slate-300 mt-1">₹{((unitPriceNumber * calcDownPayment) / 100).toLocaleString("en-IN")} Initial</div>
                </div>

                <div>
                  <div className="text-xs text-slate-400 uppercase font-semibold">Tenure: {calcTenureYears} Years</div>
                  <input
                    type="range"
                    min="5"
                    max="30"
                    step="5"
                    value={calcTenureYears}
                    onChange={(e) => setCalcTenureYears(Number(e.target.value))}
                    className="w-full mt-2 accent-cyan-500 cursor-pointer"
                  />
                  <div className="text-xs text-slate-300 mt-1">@ 8.25% p.a. partnered bank rate</div>
                </div>

                <div className="bg-[#0c121e] p-4 rounded-xl border border-cyan-500/30 text-center">
                  <div className="text-xs text-slate-400 uppercase font-semibold">Estimated Monthly EMI</div>
                  <div className="text-2xl font-black text-cyan-400 mt-1">
                    ₹{calculatedEmi.toLocaleString("en-IN")}/mo
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">Includes subsidized township maintenance</div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Detailed Milestone Gantt / Progress Timeline */}
        <div className="space-y-4 pt-4 border-t border-white/10">
          <div className="flex items-center justify-between">
            <h4 className="text-lg font-bold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              <span>Execution Timeline & Milestone Schedule</span>
            </h4>
            <span className="text-xs text-slate-400">Regularly audited by Town Planning Directorate</span>
          </div>

          <div className="space-y-3">
            {currentSector.timeline.map((item, idx) => (
              <div
                key={idx}
                className={`p-4 rounded-2xl border transition-all ${
                  item.completed
                    ? "bg-[#06141a]/60 border-cyan-500/30"
                    : "bg-[#090d16]/60 border-white/10"
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                      item.completed ? "bg-cyan-500 text-slate-950 font-black" : "bg-slate-800 text-slate-400"
                    }`}>
                      {item.completed ? "✓" : idx + 1}
                    </div>
                    <div>
                      <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                        {item.phase} • <span className="text-slate-300 font-semibold">{item.date}</span>
                      </div>
                      <h5 className="text-sm font-bold text-white">{item.milestone}</h5>
                    </div>
                  </div>

                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold shrink-0 self-start sm:self-auto ${
                    item.completed ? "bg-cyan-950/90 text-cyan-300 border border-cyan-500/30" : "bg-amber-950/80 text-amber-300 border border-amber-500/30"
                  }`}>
                    {item.completed ? "Milestone Achieved" : "Work in Progress"}
                  </span>
                </div>

                <p className="text-xs text-slate-400 mt-2 pl-11">
                  {item.notes}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Technical Specifications Table */}
        <div className="space-y-4 pt-4 border-t border-white/10">
          <h4 className="text-lg font-bold text-white flex items-center gap-2">
            <FileText className="w-4 h-4 text-cyan-400" />
            <span>Technical Specifications & Statutory Standards</span>
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
            {currentSector.specs.map((spec, i) => (
              <div key={i} className="bg-[#0a0e17] p-3.5 rounded-2xl border border-white/10">
                <div className="text-[11px] text-slate-400 uppercase font-semibold">{spec.label}</div>
                <div className="text-sm font-bold text-white mt-1">{spec.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
