import React, { useState } from "react";
import { 
  FileText, 
  Download, 
  Search, 
  ShieldCheck, 
  CheckCircle2, 
  Eye, 
  ExternalLink, 
  Building2, 
  Calendar, 
  FileCheck, 
  Award,
  Sparkles,
  Lock,
  Printer
} from "lucide-react";
import { DocumentItem } from "../types";
import { OFFICIAL_DOCUMENTS } from "../data/townshipData";

export const DocumentsBlueprintHub: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [activeDocModal, setActiveDocModal] = useState<DocumentItem | null>(null);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const categories = ["All", "Masterplan", "Clearances", "Land & Revenue", "Panchayat Resolutions", "Tenders"];

  const filteredDocs = OFFICIAL_DOCUMENTS.filter((doc) => {
    const matchesCategory = selectedCategory === "All" || doc.category === selectedCategory;
    const matchesSearch =
      doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.referenceNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.authorizingBody.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.summary.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleDownload = (doc: DocumentItem) => {
    setDownloadSuccess(`Downloaded certified copy: ${doc.referenceNo}`);
    setTimeout(() => setDownloadSuccess(null), 4000);
  };

  return (
    <div className="glass-panel rounded-3xl p-6 md:p-10 border border-white/10 shadow-2xl space-y-8">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 text-cyan-300 text-xs font-bold uppercase tracking-wider mb-2 border border-cyan-500/30">
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
            <span>Public Transparency & Legal Vault</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-black text-white tracking-tight">
            Official Masterplan Blueprints & Statutory Gazettes
          </h2>
          <p className="text-slate-300 text-sm mt-1 max-w-3xl">
            Access, inspect, and verify all government gazetted notifications, environmental clearances (MoEF&CC), Gram Panchayat unanimous resolutions, and land title records.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-medium text-slate-300 bg-[#0b0f19] px-3.5 py-2 rounded-xl self-start md:self-auto border border-white/10">
          <Lock className="w-3.5 h-3.5 text-cyan-400" />
          <span>Blockchain-anchored public records</span>
        </div>
      </div>

      {downloadSuccess && (
        <div className="p-4 bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 rounded-2xl text-xs font-bold flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{downloadSuccess}</span>
          </div>
          <span className="text-[10px] text-emerald-400">Digital Seal Verified</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition border ${
                selectedCategory === cat
                  ? "bg-blue-600 text-white border-blue-400/40 shadow-lg shadow-blue-600/30"
                  : "bg-[#0b0f19] text-slate-400 hover:text-white hover:bg-white/5 border-white/10"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search gazette no., clearance..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-[#0b0f19] border border-white/10 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-cyan-500 text-white placeholder:text-slate-500"
          />
        </div>
      </div>

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredDocs.map((doc) => (
          <div
            key={doc.id}
            className="bg-[#090d16]/90 hover:bg-[#0c121e] rounded-2xl p-5 border border-white/10 hover:border-cyan-500/50 hover:shadow-2xl hover:shadow-cyan-500/10 transition-all duration-300 flex flex-col justify-between group"
          >
            <div>
              {/* Category & Status */}
              <div className="flex items-center justify-between text-xs mb-3">
                <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 font-bold text-[10px] uppercase border border-white/5">
                  {doc.category}
                </span>
                <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-300 bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  {doc.status}
                </span>
              </div>

              {/* Title & Ref */}
              <h3 className="text-base font-bold text-white leading-snug group-hover:text-cyan-300 transition-colors">
                {doc.title}
              </h3>
              <div className="text-[11px] font-mono text-slate-400 mt-1">
                Ref: <span className="text-cyan-400 font-bold">{doc.referenceNo}</span>
              </div>

              {/* Summary */}
              <p className="text-xs text-slate-300 mt-3 leading-relaxed line-clamp-3">
                {doc.summary}
              </p>

              {/* Issuing Authority & Date */}
              <div className="mt-4 pt-3 border-t border-white/10 text-[11px] text-slate-400 space-y-1">
                <div className="flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{doc.authorizingBody}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>Sanctioned: {doc.issueDate}</span>
                </div>
              </div>
            </div>

            {/* Actions Bar */}
            <div className="mt-5 pt-3 border-t border-white/10 flex items-center justify-between gap-2">
              <button
                onClick={() => setActiveDocModal(doc)}
                className="flex-1 py-2 px-3 bg-[#0c121e] hover:bg-slate-800 text-white border border-white/10 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition shadow-sm"
              >
                <Eye className="w-3.5 h-3.5 text-cyan-400" />
                <span>Inspect Record</span>
              </button>

              <button
                onClick={() => handleDownload(doc)}
                title="Download Official Certified PDF"
                className="p-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-xl transition shadow-lg shadow-cyan-500/20 border border-cyan-400/30"
              >
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Document Inspection Full Modal */}
      {activeDocModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#070b14] rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto border border-white/10 shadow-2xl p-6 md:p-8 space-y-6 text-white">
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-cyan-950/80 text-cyan-400 flex items-center justify-center font-bold border border-cyan-500/30">
                  <FileCheck className="w-6 h-6" />
                </div>
                <div>
                  <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 text-[10px] font-extrabold uppercase border border-cyan-500/30">
                    {activeDocModal.category} • {activeDocModal.status}
                  </span>
                  <h3 className="text-xl font-extrabold text-white mt-1">{activeDocModal.title}</h3>
                  <div className="text-xs font-mono text-slate-400">Ref: {activeDocModal.referenceNo}</div>
                </div>
              </div>

              <button
                onClick={() => setActiveDocModal(null)}
                className="text-slate-400 hover:text-white text-sm p-1.5 rounded-lg bg-slate-800 border border-white/10"
              >
                ✕
              </button>
            </div>

            {/* Official Seal Simulation Banner */}
            <div className="bg-amber-950/40 rounded-2xl p-4 border border-amber-500/30 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <Award className="w-6 h-6 text-amber-400 shrink-0" />
                <div>
                  <div className="text-xs font-bold text-amber-300 uppercase tracking-wide">
                    Government & Panchayat Certified Document
                  </div>
                  <div className="text-xs text-amber-200">
                    Digitally signed by District Town Planning Officer & Vikasgram Sarpanch.
                  </div>
                </div>
              </div>
              <span className="text-[10px] font-mono text-amber-300 bg-amber-950/80 px-2.5 py-1 rounded-lg shrink-0 border border-amber-500/30">
                SHA-256: 9e4f...2a01
              </span>
            </div>

            {/* Summary & Clauses */}
            <div className="space-y-4 text-xs text-slate-300">
              <div>
                <h4 className="font-bold text-white text-sm mb-1 uppercase tracking-wider">
                  Executive Summary & Scope:
                </h4>
                <p className="leading-relaxed bg-[#0b0f19] p-4 rounded-xl border border-white/10">
                  {activeDocModal.summary}
                </p>
              </div>

              <div>
                <h4 className="font-bold text-white text-sm mb-2 uppercase tracking-wider">
                  Statutory Highlights & Binding Clauses:
                </h4>
                <div className="space-y-2">
                  {activeDocModal.highlights.map((h, idx) => (
                    <div key={idx} className="flex items-start gap-2 bg-[#06141a]/80 p-3 rounded-xl border border-cyan-500/20 text-slate-200">
                      <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                      <span>{h}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
                <div className="bg-[#0b0f19] p-3 rounded-xl border border-white/10">
                  <div className="text-[10px] text-slate-400 uppercase">Authorizing Body</div>
                  <div className="font-bold text-white mt-0.5 truncate">{activeDocModal.authorizingBody}</div>
                </div>
                <div className="bg-[#0b0f19] p-3 rounded-xl border border-white/10">
                  <div className="text-[10px] text-slate-400 uppercase">Date of Gazetted Sanction</div>
                  <div className="font-bold text-white mt-0.5">{activeDocModal.issueDate}</div>
                </div>
                <div className="bg-[#0b0f19] p-3 rounded-xl border border-white/10">
                  <div className="text-[10px] text-slate-400 uppercase">Document File Package</div>
                  <div className="font-bold text-white mt-0.5">{activeDocModal.fileSize}</div>
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-end gap-3 pt-4 border-t border-white/10">
              <button
                onClick={() => {
                  handleDownload(activeDocModal);
                  setActiveDocModal(null);
                }}
                className="w-full sm:w-auto px-5 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 border border-cyan-400/30 shadow-lg shadow-cyan-500/20"
              >
                <Download className="w-4 h-4" />
                <span>Download Certified High-Res Blueprint</span>
              </button>

              <button
                onClick={() => window.print()}
                className="w-full sm:w-auto px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-1.5 border border-white/10"
              >
                <Printer className="w-4 h-4" />
                <span>Print Official Summary</span>
              </button>

              <button
                onClick={() => setActiveDocModal(null)}
                className="w-full sm:w-auto px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold transition border border-white/10"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
