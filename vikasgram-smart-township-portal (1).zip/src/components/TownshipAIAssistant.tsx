import React, { useState, useRef, useEffect } from "react";
import { 
  Bot, 
  Send, 
  Sparkles, 
  X, 
  MessageSquare, 
  ShieldCheck, 
  HelpCircle, 
  Building2, 
  Trees, 
  Hospital, 
  Route, 
  Bed,
  RefreshCw,
  ChevronDown
} from "lucide-react";

interface Message {
  id: string;
  sender: "user" | "bot";
  text: string;
  timestamp: string;
  sources?: string[];
}

export const TownshipAIAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "msg-welcome",
      sender: "bot",
      text: "Namaste! I am GramVikas AI, the official virtual masterplanner for Vikasgram Smart Mini-Township. How can I assist you with our 3-Acre Central Park, 100-Bed Hospital, School, 6-Lane Expressway, or residential guest stay booking?",
      timestamp: "Just now",
      sources: ["Vikasgram Gazetted Masterplan 2024-2028"]
    }
  ]);
  const [inputQuery, setInputQuery] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  const quickQuestions = [
    "Tell me about the 3-Acre Central Park zones & children's play area.",
    "What facilities are available in the 100-Bed Hospital & Helipad?",
    "When will the 6-Lane Expressway connect to the township?",
    "How can I book a visit or guest stay in the model villament?",
    "What are the housing quotas for native village landowners?"
  ];

  useEffect(() => {
    if (isOpen) {
      chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (queryText?: string) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/township-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: textToSend })
      });

      if (response.ok) {
        const data = await response.json();
        const botMsg: Message = {
          id: `bot-${Date.now()}`,
          sender: "bot",
          text: data.reply || "Thank you for inquiring about Vikasgram Mini-Township.",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          sources: data.sources || ["Vikasgram Gazetted Masterplan 2028"]
        };
        setMessages((prev) => [...prev, botMsg]);
      } else {
        throw new Error("Server response not ok");
      }
    } catch (e) {
      console.error("AI chat error:", e);
      const fallbackMsg: Message = {
        id: `bot-${Date.now()}`,
        sender: "bot",
        text: `Vikasgram Mini-Township is an eco-smart 180-acre development featuring a 3-Acre Central Park (with children's splash pads, elders reflexology trail, and open-air gym), 100-bed multi-specialty hospital with helipad, CBSE/IB smart school, 6-lane bypass connectivity, and 100% solar underground utilities. You can explore our interactive 3D map or reserve a visit in the appointment tab!`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        sources: ["Vikasgram Masterplan Knowledge Base"]
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-40">
      {/* Floating Toggle Trigger Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="group flex items-center gap-2.5 px-4 py-3.5 bg-[#070b14]/95 backdrop-blur-xl hover:bg-slate-800 text-white rounded-full shadow-2xl border border-cyan-500/40 hover:scale-105 transition-all duration-300 shadow-cyan-500/20"
        >
          <div className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
          </div>
          <Bot className="w-5 h-5 text-cyan-400 group-hover:text-white transition-colors" />
          <span className="text-xs font-bold tracking-wide">Ask Masterplan AI</span>
        </button>
      )}

      {/* Expanded Chat Window */}
      {isOpen && (
        <div className="bg-[#070b14]/95 backdrop-blur-2xl text-white rounded-3xl w-[92vw] sm:w-[420px] h-[560px] border border-white/10 shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-5">
          {/* Top Bar */}
          <div className="bg-[#050608]/90 p-4 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 text-white flex items-center justify-center font-bold shadow-md border border-cyan-400/30">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-extrabold text-white flex items-center gap-1.5">
                  GramVikas Masterplan AI
                  <span className="text-[10px] bg-cyan-950 text-cyan-300 px-1.5 py-0.2 rounded border border-cyan-500/30 font-normal">
                    Active
                  </span>
                </div>
                <div className="text-[10px] text-slate-400">Township Guide & Planning Assistant</div>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="text-slate-400 hover:text-white p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 transition border border-white/10"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages Body */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3.5 scrollbar-thin text-xs">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${
                  m.sender === "user" ? "items-end" : "items-start"
                }`}
              >
                <div
                  className={`max-w-[88%] p-3.5 rounded-2xl leading-relaxed ${
                    m.sender === "user"
                      ? "bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-tr-none shadow-lg shadow-cyan-500/10 border border-cyan-400/30"
                      : "bg-[#0c121e] text-slate-200 rounded-tl-none border border-white/10"
                  }`}
                >
                  <p className="whitespace-pre-wrap">{m.text}</p>
                </div>

                <div className="flex items-center gap-2 mt-1 px-1 text-[10px] text-slate-500">
                  <span>{m.timestamp}</span>
                  {m.sources && m.sources.length > 0 && (
                    <span className="text-cyan-400/80 font-medium">
                      • {m.sources[0]}
                    </span>
                  )}
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex items-center gap-2 text-slate-400 bg-[#0c121e] p-3 rounded-2xl rounded-tl-none max-w-[80%] border border-white/10">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
                <span className="text-xs">Consulting township gazette records...</span>
              </div>
            )}
            <div ref={chatBottomRef} />
          </div>

          {/* Quick Prompts Carousel */}
          <div className="px-3 py-2 bg-[#050608]/90 border-t border-white/10 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
            {quickQuestions.map((q, i) => (
              <button
                key={i}
                onClick={() => handleSendMessage(q)}
                className="px-2.5 py-1 rounded-lg bg-[#0c121e] hover:bg-slate-800 text-[10px] text-slate-300 hover:text-white whitespace-nowrap transition border border-white/10 hover:border-cyan-400/40"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Chat Input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-3 bg-[#050608]/95 border-t border-white/10 flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="Ask about 3-acre park, hospital, plots..."
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              className="flex-1 bg-[#0b0f19] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />
            <button
              type="submit"
              disabled={isLoading || !inputQuery.trim()}
              className="p-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 disabled:opacity-40 text-white rounded-xl font-bold transition shadow-lg shadow-cyan-500/20 border border-cyan-400/30"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
