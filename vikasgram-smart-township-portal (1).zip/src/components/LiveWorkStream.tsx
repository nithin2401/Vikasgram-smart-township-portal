import React, { useState, useEffect } from "react";
import { 
  Activity, 
  Video, 
  Users, 
  ShieldCheck, 
  Zap, 
  Wind, 
  Clock, 
  CheckCircle2, 
  Plus, 
  RefreshCw, 
  Camera, 
  HardHat, 
  Radio,
  Send,
  AlertCircle
} from "lucide-react";
import { LiveWorkLog } from "../types";

export const LiveWorkStream: React.FC = () => {
  const [logs, setLogs] = useState<LiveWorkLog[]>([
    {
      id: "LOG-1094",
      sector: "3-Acre Central Eco-Park",
      title: "Children's Sensory Playset & Soft-Turf Installation",
      description: "Installed German-certified safety rubber turfing and sustainable oak-wood play structures in Zone B. Splash fountain testing passed with recycled STP water.",
      author: "Eng. Vikram Verma (Landscape Chief)",
      timestamp: "12 minutes ago",
      status: "Active Work",
      completionPercentage: 88,
      badgeColor: "emerald"
    },
    {
      id: "LOG-1093",
      sector: "Multi-Speciality Hospital",
      title: "Trauma Ward Medical Gas Pipeline Grid Testing",
      description: "Pressure testing for 100-bed centralized oxygen and nitrous pipeline system completed with 100% safety clearance.",
      author: "Dr. Sandeep Kulkarni (Biomedical Lead)",
      timestamp: "45 minutes ago",
      status: "Quality Certified",
      completionPercentage: 72,
      badgeColor: "blue"
    },
    {
      id: "LOG-1092",
      sector: "Road & EV Mobility Grid",
      title: "6-Lane Bypass Bituminous Layer 3 Asphalt Pouring",
      description: "Completed 4.2 km stretch connecting Sector 4 to State Highway with smart induction loops for dynamic traffic monitoring.",
      author: "Praveen Rao (Infrastructure Supervisor)",
      timestamp: "2 hours ago",
      status: "Milestone Completed",
      completionPercentage: 94,
      badgeColor: "amber"
    },
    {
      id: "LOG-1091",
      sector: "Integrated Smart Academy",
      title: "STEM Robotics Lab & Digital Smartboard Delivery",
      description: "Received 40 high-spec learning terminals and robotics kits for the secondary school science pavilion.",
      author: "Meenakshi Sundaram (Education Director)",
      timestamp: "4 hours ago",
      status: "In Progress",
      completionPercentage: 91,
      badgeColor: "purple"
    }
  ]);

  const [activeCamera, setActiveCamera] = useState<number>(0);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [showLogModal, setShowLogModal] = useState<boolean>(false);

  // New log form state
  const [newSector, setNewSector] = useState("3-Acre Central Eco-Park");
  const [newTitle, setNewTitle] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newAuthor, setNewAuthor] = useState("");

  const liveCameras = [
    {
      id: "CAM-01",
      name: "Cam 1: 3-Acre Central Park (Children's Zone)",
      location: "Sector 2 - Eco-Park North Gazebo",
      fps: "30 FPS Live HD",
      imageUrl: "https://images.unsplash.com/photo-1596464716127-f2a829822301?auto=format&fit=crop&w=1200&q=80",
      status: "Operational"
    },
    {
      id: "CAM-02",
      name: "Cam 2: 100-Bed Hospital Facade & Helipad",
      location: "Sector 4 - Medical District Bay",
      fps: "60 FPS 4K PTZ",
      imageUrl: "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?auto=format&fit=crop&w=1200&q=80",
      status: "Operational"
    },
    {
      id: "CAM-03",
      name: "Cam 3: 6-Lane Bypass Expressway Connector",
      location: "Bypass Flyover Overpass Post #12",
      fps: "30 FPS Live HD",
      imageUrl: "https://images.unsplash.com/photo-1545459720-aac8509eb02c?auto=format&fit=crop&w=1200&q=80",
      status: "Operational"
    },
    {
      id: "CAM-04",
      name: "Cam 4: Phase 1 Smart Villaments & Solar Rooftops",
      location: "Native Rehabilitation Cluster A",
      fps: "30 FPS Live HD",
      imageUrl: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80",
      status: "Operational"
    }
  ];

  // Fetch updates from backend
  const fetchLiveUpdates = async () => {
    setIsRefreshing(true);
    try {
      const res = await fetch("/api/live-updates");
      if (res.ok) {
        const data = await res.json();
        if (data.updates && data.updates.length > 0) {
          setLogs(data.updates);
        }
      }
    } catch (e) {
      console.error("Error fetching live logs:", e);
    } finally {
      setTimeout(() => setIsRefreshing(false), 500);
    }
  };

  useEffect(() => {
    fetchLiveUpdates();
  }, []);

  const handleCreateLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newDesc) return;

    try {
      const res = await fetch("/api/live-updates", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sector: newSector,
          title: newTitle,
          description: newDesc,
          author: newAuthor || "Site Quality Engineer"
        })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.log) {
          setLogs([data.log, ...logs]);
        }
      }
    } catch (e) {
      console.error("Error submitting work log:", e);
    }

    setNewTitle("");
    setNewDesc("");
    setNewAuthor("");
    setShowLogModal(false);
  };

  return (
    <div className="glass-panel rounded-3xl p-6 md:p-10 border border-white/10 text-white shadow-2xl space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 text-cyan-300 text-xs font-bold uppercase tracking-wider mb-2 border border-cyan-500/30">
            <Radio className="w-3.5 h-3.5 animate-pulse text-cyan-400" />
            <span>Live On-Site Telemetry & Work Feed</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-black text-white tracking-tight">
            Township Ground Execution Stream
          </h2>
          <p className="text-slate-300 text-sm mt-1 max-w-2xl">
            Real-time feed directly from site engineers, continuous drone surveillance, and daily verified milestone sign-offs.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchLiveUpdates}
            disabled={isRefreshing}
            className="px-3.5 py-2 rounded-xl bg-[#0b0f19] hover:bg-slate-800 text-slate-300 text-xs font-bold flex items-center gap-2 border border-white/10 transition"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin text-cyan-400" : ""}`} />
            <span>Refresh Feed</span>
          </button>

          <button
            onClick={() => setShowLogModal(true)}
            className="px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition shadow-lg shadow-cyan-500/20 border border-cyan-400/30"
          >
            <Plus className="w-4 h-4" />
            <span>Log Supervisor Update</span>
          </button>
        </div>
      </div>

      {/* Telemetry Stats Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-[#090d16]/90 p-4 rounded-2xl border border-white/10 space-y-1">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <HardHat className="w-4 h-4 text-amber-400" />
            <span>Active Workforce</span>
          </div>
          <div className="text-2xl font-black text-white">428 Engineers</div>
          <div className="text-[10px] text-cyan-400 font-semibold">Across all 7 sectors</div>
        </div>

        <div className="bg-[#090d16]/90 p-4 rounded-2xl border border-white/10 space-y-1">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Accident-Free Streak</span>
          </div>
          <div className="text-2xl font-black text-white">342 Days</div>
          <div className="text-[10px] text-emerald-400 font-semibold">Zero lost-time injuries</div>
        </div>

        <div className="bg-[#090d16]/90 p-4 rounded-2xl border border-white/10 space-y-1">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <Zap className="w-4 h-4 text-yellow-400" />
            <span>Solar Generation</span>
          </div>
          <div className="text-2xl font-black text-white">14,820 kWh</div>
          <div className="text-[10px] text-cyan-400 font-semibold">Today's clean energy output</div>
        </div>

        <div className="bg-[#090d16]/90 p-4 rounded-2xl border border-white/10 space-y-1">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <Wind className="w-4 h-4 text-cyan-400" />
            <span>Township Air Quality</span>
          </div>
          <div className="text-2xl font-black text-white">AQI 34 (Good)</div>
          <div className="text-[10px] text-emerald-400 font-semibold">Due to 3-acre bio-park buffer</div>
        </div>
      </div>

      {/* Main Grid: Live CCTV Simulator (Left) + Stream Logs (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left 7 Cols: Live CCTV & Drone Feed */}
        <div className="lg:col-span-7 bg-[#070b14]/95 rounded-2xl overflow-hidden border border-white/10 shadow-xl space-y-4 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
              </span>
              <span className="text-xs font-extrabold uppercase tracking-wider text-rose-400">LIVE FEED</span>
              <span className="text-xs text-slate-400 font-medium">| {liveCameras[activeCamera].name}</span>
            </div>
            <span className="text-[10px] font-mono text-cyan-300 bg-cyan-950/80 border border-cyan-500/30 px-2 py-0.5 rounded">
              {liveCameras[activeCamera].fps}
            </span>
          </div>

          {/* Camera Video Simulator Box */}
          <div className="relative w-full h-[280px] sm:h-[340px] rounded-xl overflow-hidden bg-slate-900 border border-white/10 group">
            <img
              src={liveCameras[activeCamera].imageUrl}
              alt="Site Camera"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-transparent"></div>

            {/* Time & Camera Stamp Overlay */}
            <div className="absolute top-3 left-3 bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded font-mono text-[11px] text-cyan-400 border border-white/10">
              ● REC {new Date().toLocaleTimeString()} • {liveCameras[activeCamera].id}
            </div>
            <div className="absolute bottom-3 left-3 text-white text-xs">
              <div className="font-bold">{liveCameras[activeCamera].location}</div>
              <div className="text-[10px] text-slate-300">Continuous AI Safety Inspection Active</div>
            </div>
          </div>

          {/* Camera switcher thumbnails */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {liveCameras.map((cam, idx) => (
              <button
                key={cam.id}
                onClick={() => setActiveCamera(idx)}
                className={`p-2.5 rounded-xl text-left transition border ${
                  activeCamera === idx
                    ? "bg-blue-950/60 border-cyan-400 text-white shadow-md shadow-cyan-500/20"
                    : "bg-[#090d16]/80 border-white/10 text-slate-400 hover:text-white hover:bg-white/5"
                }`}
              >
                <div className="text-[10px] font-bold uppercase truncate">{cam.name}</div>
                <div className="text-[9px] text-cyan-400 mt-0.5">● Active Feed</div>
              </button>
            ))}
          </div>
        </div>

        {/* Right 5 Cols: Live Chronological Work Logs */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              <span>Timestamped Site Logs</span>
            </h3>
            <span className="text-xs text-slate-400">{logs.length} Updates Today</span>
          </div>

          <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1 scrollbar-thin">
            {logs.map((log) => (
              <div
                key={log.id}
                className="bg-[#090d16]/90 hover:bg-[#0c121e] rounded-2xl p-4 border border-white/10 transition space-y-2"
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="px-2.5 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 font-bold text-[10px] border border-cyan-500/30">
                    {log.sector}
                  </span>
                  <span className="text-[11px] text-slate-400">{log.timestamp}</span>
                </div>

                <h4 className="text-sm font-bold text-white leading-snug">{log.title}</h4>
                <p className="text-xs text-slate-300 leading-relaxed">{log.description}</p>

                <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="font-medium text-slate-300 truncate">{log.author}</span>
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> {log.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Modal for adding supervisor log */}
      {showLogModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#070b14] rounded-3xl max-w-lg w-full border border-white/10 p-6 md:p-8 space-y-5 text-white shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-lg font-bold">Log New On-Site Work Milestone</h3>
              <button
                onClick={() => setShowLogModal(false)}
                className="text-slate-400 hover:text-white text-sm p-1.5 rounded-lg bg-slate-800 border border-white/10"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateLog} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Target Sector</label>
                <select
                  value={newSector}
                  onChange={(e) => setNewSector(e.target.value)}
                  className="w-full bg-[#0b0f19] border border-white/10 rounded-xl p-2.5 text-white focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                >
                  <option value="3-Acre Central Eco-Park">3-Acre Central Eco-Park</option>
                  <option value="Multi-Speciality Hospital">Multi-Speciality Hospital</option>
                  <option value="Integrated Smart Academy">Integrated Smart Academy</option>
                  <option value="Road & EV Mobility Grid">Road & EV Mobility Grid</option>
                  <option value="Residential Housing Sectors">Residential Housing Sectors</option>
                  <option value="Solar Microgrid & STP">Solar Microgrid & STP</option>
                  <option value="Sports Complex & Gym">Sports Complex & Gym</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Milestone / Work Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Completed Children's Splash Fountain Installation"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-[#0b0f19] border border-white/10 rounded-xl p-2.5 text-white focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Work Details & Verification Notes</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Details of materials used, quality test outcome, and next target..."
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full bg-[#0b0f19] border border-white/10 rounded-xl p-2.5 text-white focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Supervisor Name & Designation</label>
                <input
                  type="text"
                  placeholder="e.g. Eng. Vikram Verma (Chief Resident Engineer)"
                  value={newAuthor}
                  onChange={(e) => setNewAuthor(e.target.value)}
                  className="w-full bg-[#0b0f19] border border-white/10 rounded-xl p-2.5 text-white focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setShowLogModal(false)}
                  className="px-4 py-2.5 bg-slate-800 text-slate-300 rounded-xl hover:bg-slate-700 border border-white/10"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold rounded-xl transition flex items-center gap-1.5 border border-cyan-400/30 shadow-lg shadow-cyan-500/20"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Publish Update</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
