import React, { useState } from "react";
import { 
  X, 
  Mail, 
  Lock, 
  User, 
  Phone, 
  Sparkles, 
  ShieldCheck, 
  ArrowRight, 
  CheckCircle2,
  Building2,
  KeyRound,
  AlertCircle,
  Eye,
  EyeOff,
  UserCheck
} from "lucide-react";
import { useAuth } from "../context/AuthContext";

export const AuthModal: React.FC = () => {
  const { 
    isAuthModalOpen, 
    closeAuthModal, 
    authModalTab, 
    loginWithGoogle, 
    loginWithEmail, 
    registerWithEmail,
    loginAsGuest
  } = useAuth();

  const [tab, setTab] = useState<"signin" | "signup">(authModalTab || "signin");
  const [email, setEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [displayName, setDisplayName] = useState<string>("");
  const [phoneNumber, setPhoneNumber] = useState<string>("");
  const [role, setRole] = useState<string>("Prospective Resident / Relocating Family");
  
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isCredentialError, setIsCredentialError] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Sync tab when opened
  React.useEffect(() => {
    if (authModalTab) setTab(authModalTab);
    setErrorMsg(null);
    setIsCredentialError(false);
  }, [authModalTab, isAuthModalOpen]);

  if (!isAuthModalOpen) return null;

  const handleGoogleAuth = async () => {
    setErrorMsg(null);
    setIsCredentialError(false);
    setIsLoading(true);
    try {
      await loginWithGoogle();
    } catch (err: any) {
      setErrorMsg(err.message || "Google authentication was cancelled or failed.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickDemoAuth = async (demoRole: string = "Prospective Resident / Relocating Family") => {
    setErrorMsg(null);
    setIsCredentialError(false);
    setIsLoading(true);
    try {
      await loginAsGuest("Dr. Rajeshwar Sharma (Demo Citizen)", demoRole);
    } catch (err: any) {
      setErrorMsg("Demo access failed: " + (err.message || "Unknown error"));
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setIsCredentialError(false);
    setIsLoading(true);

    try {
      if (tab === "signin") {
        if (!email || !password) {
          setErrorMsg("Please provide both email and password.");
          setIsLoading(false);
          return;
        }
        await loginWithEmail(email, password);
      } else {
        if (!displayName || !email || !password) {
          setErrorMsg("Please fill in your name, email, and a secure password.");
          setIsLoading(false);
          return;
        }
        if (password.length < 6) {
          setErrorMsg("Password must be at least 6 characters.");
          setIsLoading(false);
          return;
        }
        await registerWithEmail(email, password, displayName, phoneNumber, role);
      }
    } catch (err: any) {
      const errCode = err.code || "";
      let message = err.message || "Authentication error occurred.";
      
      if (
        errCode === "auth/invalid-credential" || 
        errCode === "auth/user-not-found" || 
        errCode === "auth/wrong-password" ||
        errCode === "auth/invalid-login-credentials"
      ) {
        setIsCredentialError(true);
        message = "Incorrect password or no account registered with this email yet. If you are new to Vikasgram, please create an account below.";
      } else if (errCode === "auth/email-already-in-use") {
        message = "An account already exists with this email address. Please switch to Sign In.";
      } else if (errCode === "auth/weak-password") {
        message = "Password should be at least 6 characters.";
      } else if (errCode === "auth/invalid-email") {
        message = "Please enter a valid email format.";
      }
      
      setErrorMsg(message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#070b14] border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl text-white overflow-hidden space-y-5 max-h-[92vh] overflow-y-auto">
        
        {/* Glow ambient accent */}
        <div className="absolute -top-24 -right-24 w-52 h-52 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -bottom-24 -left-24 w-52 h-52 bg-blue-600/15 rounded-full blur-3xl pointer-events-none"></div>

        {/* Close Button */}
        <button
          onClick={closeAuthModal}
          className="absolute top-5 right-5 p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition border border-white/5"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header Title */}
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white flex items-center justify-center font-black shadow-lg shadow-cyan-500/20 border border-cyan-400/30">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <div className="text-[10px] font-extrabold uppercase tracking-widest text-cyan-300">
              Vikasgram Citizen & Visitor Portal
            </div>
            <h3 className="text-xl font-bold text-white tracking-tight">
              {tab === "signin" ? "Sign In to Vikasgram" : "Create Citizen / Visitor Account"}
            </h3>
          </div>
        </div>

        {/* Purpose Note */}
        <div className="p-3 bg-cyan-950/40 rounded-2xl border border-cyan-500/20 flex items-start gap-2.5 text-xs text-cyan-200/90">
          <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <span>
            Sign in is required to book official township tours, reserve model villament stays, and access your verified digital gate passes.
          </span>
        </div>

        {/* Tabs: Sign In vs Sign Up */}
        <div className="grid grid-cols-2 p-1 bg-[#0b0f19] rounded-2xl border border-white/10 text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setTab("signin");
              setErrorMsg(null);
              setIsCredentialError(false);
            }}
            className={`py-2.5 rounded-xl transition ${
              tab === "signin"
                ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400/30"
                : "text-slate-400 hover:text-white"
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setTab("signup");
              setErrorMsg(null);
              setIsCredentialError(false);
            }}
            className={`py-2.5 rounded-xl transition ${
              tab === "signup"
                ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400/30"
                : "text-slate-400 hover:text-white"
            }`}
          >
            Create New Account
          </button>
        </div>

        {/* 1-Click Fast Auth Options */}
        <div className="space-y-2">
          <button
            type="button"
            onClick={handleGoogleAuth}
            disabled={isLoading}
            className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-3 transition border border-white/10 hover:border-cyan-500/40 shadow-md group disabled:opacity-50"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path
                fill="#EA4335"
                d="M12 5c1.7 0 3 .6 4 1.5l3-3C17.2 1.8 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.3l3.7 2.9C6.5 7.4 9 5 12 5z"
              />
              <path
                fill="#4285F4"
                d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.6h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.9z"
              />
              <path
                fill="#FBBC05"
                d="M5.6 14.8c-.3-.8-.4-1.8-.4-2.8 0-1 .1-2 .4-2.8L1.9 6.3C.7 8.7 0 10.3 0 12s.7 3.3 1.9 5.7l3.7-2.9z"
              />
              <path
                fill="#34A853"
                d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2.4-6.4-5.2L1.9 16C3.7 19.7 7.5 23 12 23z"
              />
            </svg>
            <span>Continue with Google</span>
          </button>

          {/* Quick Demo Citizen Login (Instant 1-Click Access) */}
          <button
            type="button"
            onClick={() => handleQuickDemoAuth(role)}
            disabled={isLoading}
            className="w-full py-2.5 px-4 bg-gradient-to-r from-emerald-950/80 to-cyan-950/80 hover:from-emerald-900/90 hover:to-cyan-900/90 text-emerald-300 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition border border-emerald-500/30 hover:border-emerald-400 shadow-md group disabled:opacity-50"
          >
            <UserCheck className="w-4 h-4 text-emerald-400" />
            <span>Instant Demo Sign-In (Guest Resident Pass)</span>
          </button>
        </div>

        <div className="flex items-center gap-3">
          <div className="h-px flex-1 bg-white/10"></div>
          <span className="text-[10px] uppercase font-bold text-slate-500">Or use email & password</span>
          <div className="h-px flex-1 bg-white/10"></div>
        </div>

        {/* Error notification with Smart One-Click Recovery */}
        {errorMsg && (
          <div className="p-3.5 bg-rose-950/70 border border-rose-500/40 rounded-2xl text-xs text-rose-200 space-y-2">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
              <span>{errorMsg}</span>
            </div>

            {/* If credential error on Sign-In, offer 1-click switch to Sign Up */}
            {isCredentialError && tab === "signin" && (
              <div className="pt-1 flex items-center gap-2 border-t border-rose-500/20">
                <button
                  type="button"
                  onClick={() => {
                    setTab("signup");
                    setErrorMsg(null);
                    setIsCredentialError(false);
                  }}
                  className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 transition shadow"
                >
                  <span>Create New Account with this Email</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* Form Inputs */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {tab === "signup" && (
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Full Name *
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Chandra Sharma"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full bg-[#0b0f19] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Email Address *
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
              <input
                type="email"
                required
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#0b0f19] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-semibold text-slate-300">
                Password *
              </label>
              {tab === "signup" && (
                <span className="text-[10px] text-slate-400">Min. 6 characters</span>
              )}
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
              <input
                type={showPassword ? "text" : "password"}
                required
                placeholder={tab === "signin" ? "Enter your password" : "Create password (min 6 chars)"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#0b0f19] border border-white/10 rounded-xl pl-10 pr-10 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-slate-500 hover:text-slate-300"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {tab === "signup" && (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Contact Mobile Number (Optional)
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                  <input
                    type="tel"
                    placeholder="+91 98765 43210"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="w-full bg-[#0b0f19] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Category / Interest
                </label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full bg-[#0b0f19] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                >
                  <option value="Prospective Resident / Relocating Family">Prospective Resident / Relocating Family</option>
                  <option value="Original Native Village Landowner">Original Native Village Landowner (Rehabilitation Quota)</option>
                  <option value="Investor & Commercial Developer">Investor & Commercial Developer</option>
                  <option value="Govt. & Urban Planning Inspector">Govt. & Urban Planning Inspector</option>
                  <option value="Township Citizen / Resident">Township Citizen / Resident</option>
                </select>
              </div>
            </>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-gradient-to-r from-blue-600 via-cyan-600 to-emerald-600 hover:from-blue-500 hover:to-emerald-500 text-white rounded-xl font-bold text-xs transition shadow-lg shadow-cyan-500/20 border border-cyan-400/30 flex items-center justify-center gap-2 disabled:opacity-50 mt-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>
              {isLoading 
                ? "Authenticating..." 
                : tab === "signin" 
                  ? "Sign In & Proceed" 
                  : "Create Account & Continue"}
            </span>
          </button>
        </form>

        {/* Footer info */}
        <div className="text-center pt-1">
          <button
            type="button"
            onClick={() => {
              setTab(tab === "signin" ? "signup" : "signin");
              setErrorMsg(null);
              setIsCredentialError(false);
            }}
            className="text-xs text-slate-400 hover:text-cyan-300 transition underline underline-offset-2"
          >
            {tab === "signin" 
              ? "Don't have an account yet? Click here to register." 
              : "Already have a Vikasgram account? Click here to sign in."}
          </button>
        </div>

      </div>
    </div>
  );
};
