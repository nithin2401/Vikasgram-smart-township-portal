import { SectorInfo, DocumentItem, HousingUnitOption } from "../types";

export const TOWNSHIP_METRICS = {
  name: "Vikasgram Eco-Smart Mini Township",
  tagline: "From Traditional Village to Self-Sustaining Future Township",
  totalAreaAcres: 180,
  projectDuration: "2024 - 2028",
  overallCompletion: 74,
  estimatedPopulation: "12,500 Residents",
  residentialUnits: 1480,
  nativeVillagerRehabilitation: "100% Guaranteed & Subsidized",
  greenCoverPercentage: "42% Dedicated Greenery",
  solarMicrogridCapacity: "3.5 MW Peak",
  investmentSanctioned: "$42.5M (₹355 Crore)",
  totalDirectJobsCreated: 1840,
  activeWorkforceOnsite: 428,
  safetyAccidentFreeDays: 342,
  currentAQI: 34,
};

export const DEDICATED_SECTORS: SectorInfo[] = [
  {
    id: "park-3acre",
    name: "3-Acre Central Eco-Park & Wellness Hub",
    shortTitle: "3-Acre Central Park",
    category: "park",
    iconName: "Trees",
    completionPercentage: 88,
    status: "Near Completion",
    targetDate: "October 2026",
    budgetAllocated: "₹18.4 Crore ($2.2M)",
    leadAgency: "National Landscape & Horticulture Consortium",
    description:
      "A sprawling 3-acre bio-diverse sanctuary designed with specialized zones for children, senior citizens, fitness enthusiasts, and native ecological preservation. 100% irrigated using treated water from the township STP.",
    keyHighlights: [
      "Dedicated Children's Adventure Zone with soft rubberized turf, sensory splash pads & wooden climbing towers",
      "Elders Serene Pavilion featuring acupressure reflexology walking paths, shaded pergolas & yoga gazebo",
      "Open-Air Calisthenics & Fitness Gym with 18 multi-station all-weather hydraulic workout units",
      "1.2 km Rubberized Synthetic Jogging & Cycling Track with night-glow solar markers",
      "1,200+ Indigenous Fruit & Medicinal Trees including Neem, Peepal, Gulmohar & Amla",
      "Rainwater bio-retention pond with solar-powered aeration fountains"
    ],
    specs: [
      { label: "Total Park Land Area", value: "3.00 Acres (130,680 sq.ft)" },
      { label: "Children's Playground Area", value: "32,000 sq.ft (Zone A)" },
      { label: "Elders Serenity Garden Area", value: "28,500 sq.ft (Zone B)" },
      { label: "Open Gym & Track Area", value: "35,000 sq.ft (Zone C)" },
      { label: "Botanical Canopy & Water Body", value: "35,180 sq.ft (Zone D)" },
      { label: "Daily Seating Capacity", value: "650+ Persons" },
      { label: "Irrigation Mechanism", value: "Automated Micro-Drip via STP" },
      { label: "Safety Infrastructure", value: "24/7 CCTV & 6 Emergency SOS Help Poles" }
    ],
    timeline: [
      {
        phase: "Phase 1",
        milestone: "Site Grading, Soil Enrichment & Boundary Bio-Fencing",
        date: "Jan 2025 - Apr 2025",
        completed: true,
        notes: "Excavated artificial retention lake and installed subterranean storm drainage."
      },
      {
        phase: "Phase 2",
        milestone: "Plantation of 1,200 Shade Trees & 1.2km Synthetic Jogging Track",
        date: "May 2025 - Nov 2025",
        completed: true,
        notes: "Rubberized cushioning layers laid with 10-year UV degradation warranty."
      },
      {
        phase: "Phase 3",
        milestone: "Children's Sensory Equipment, Splash Pad & Elders Reflexology Trail",
        date: "Dec 2025 - Jun 2026",
        completed: true,
        notes: "Imported German-standard safety certified non-toxic play gear."
      },
      {
        phase: "Phase 4",
        milestone: "Open Air Gym Installation, Solar Lighting & Public Opening",
        date: "Jul 2026 - Oct 2026",
        completed: false,
        notes: "Final calibration of fountains, calisthenics rigs, and CCTV integration."
      }
    ],
    gallery: [
      {
        title: "Children's Adventure & Splash Zone",
        caption: "Non-slip eco-turf playground with obstacle towers and sensory water fountains.",
        tag: "Children's Area",
        imageUrl: "https://images.unsplash.com/photo-1596464716127-f2a829822301?auto=format&fit=crop&w=1200&q=80"
      },
      {
        title: "Elders Pavilion & Acupressure Trail",
        caption: "Shaded gazebo, reflexology cobblestone path, and peaceful herbal fragrance garden.",
        tag: "Senior Citizens",
        imageUrl: "https://images.unsplash.com/photo-1519331379826-f10be5486c6f?auto=format&fit=crop&w=1200&q=80"
      },
      {
        title: "Open Air Calisthenics & Fitness Station",
        caption: "Heavy-duty outdoor fitness gear overlooking the central bio-lake.",
        tag: "Outdoor Gym",
        imageUrl: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1200&q=80"
      },
      {
        title: "Bio-Lake & Illuminated Jogging Loop",
        caption: "1.2km synthetic track with solar pole illumination and water fountains.",
        tag: "Track & Lake",
        imageUrl: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1200&q=80"
      }
    ],
    liveMetrics: [
      { label: "Active Plant Species", value: "64 Varieties", trend: "+12 this month" },
      { label: "Daily Recycled Water Use", value: "45,000 Litres/day", trend: "100% STP" },
      { label: "Safety Rating", value: "5/5 Star Certified", trend: "Zero Incidents" }
    ]
  },
  {
    id: "hospital-sector",
    name: "100-Bed Multi-Speciality Hospital & Trauma Center",
    shortTitle: "Multi-Speciality Hospital",
    category: "hospital",
    iconName: "Hospital",
    completionPercentage: 72,
    status: "In Progress",
    targetDate: "December 2026",
    budgetAllocated: "₹48.2 Crore ($5.8M)",
    leadAgency: "State Health Infrastructure Development Corp",
    description:
      "Modern 100-bed green hospital providing tertiary healthcare, 24/7 trauma emergency care, pediatric ICU, telemedicine connectivity with top medical institutes, and a rooftop emergency helicopter landing pad.",
    keyHighlights: [
      "100 Bed Capacity including 20 Critical Care ICU & 10 Neonatal NICU beds",
      "24x7 Trauma Center & Emergency Response with 3 dedicated EV Advanced Life Support Ambulances",
      "Rooftop Emergency Helipad for rapid aero-medical evacuations",
      "Telemedicine Consultation Hub connecting village elders with AIIMS & Apollo doctors",
      "In-house Diagnostics: 128-Slice CT Scanner, Digital X-Ray, 1.5T MRI & Automated Pathology Lab",
      "100% Free OPD & Subsidized in-patient care for native Vikasgram village families"
    ],
    specs: [
      { label: "Total Built-up Area", value: "85,000 sq.ft (G+4 Floors)" },
      { label: "Bed Capacity", value: "100 Beds (20 ICU, 10 NICU, 70 General/Private)" },
      { label: "Operation Theaters", value: "4 Modular Laminar Flow OTs" },
      { label: "Helipad Load Capacity", value: "Single Turbine Helicopter (up to 4.5 tonnes)" },
      { label: "Doctor Roster", value: "18 Full-time Specialists + 35 Visiting Consultants" },
      { label: "Emergency Response Time", value: "< 5 Minutes inside township" },
      { label: "Solar Backup", value: "150 kW Dedicated Rooftop Solar + 250kVA UPS" }
    ],
    timeline: [
      {
        phase: "Phase 1",
        milestone: "Architectural Approval, Piling & Basement RCC Structure",
        date: "Feb 2025 - Jul 2025",
        completed: true,
        notes: "Completed deep pile foundations resistant to Zone IV seismic conditions."
      },
      {
        phase: "Phase 2",
        milestone: "G+4 Superstructure & Rooftop Helipad Concrete Casting",
        date: "Aug 2025 - Jan 2026",
        completed: true,
        notes: "Helipad landing structural integrity certified by Civil Aviation Directorate."
      },
      {
        phase: "Phase 3",
        milestone: "Medical Gas Pipeline, Modular OTs & Diagnostic Equipment Installation",
        date: "Feb 2026 - Aug 2026",
        completed: true,
        notes: "CT scanner, oxygen generator plant, and vacuum suction lines installed."
      },
      {
        phase: "Phase 4",
        milestone: "Staff Onboarding, Final Trial Runs & Commissioning",
        date: "Sep 2026 - Dec 2026",
        completed: false,
        notes: "Licensing clearance from Health Ministry and live emergency mock drills."
      }
    ],
    gallery: [
      {
        title: "Hospital Exterior & Emergency Bay",
        caption: "G+4 modern glass & terracotta facade with dual EV ambulance docking ramps.",
        tag: "Hospital Facade",
        imageUrl: "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?auto=format&fit=crop&w=1200&q=80"
      },
      {
        title: "Modular Operation Theater & ICU",
        caption: "State-of-the-art sterile laminar flow surgical suite.",
        tag: "Surgical Tech",
        imageUrl: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=1200&q=80"
      },
      {
        title: "Telemedicine & Wellness Diagnostic Wing",
        caption: "High-definition tele-consultation kiosks for remote super-specialist consultations.",
        tag: "Tele-Health",
        imageUrl: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&w=1200&q=80"
      }
    ],
    liveMetrics: [
      { label: "Emergency Ambulance Readiness", value: "3 Units Active", trend: "100% Ready" },
      { label: "Oxygen Plant Capacity", value: "500 LPM (Cylinder Free)", trend: "Self-Sustaining" },
      { label: "Villager Health Card Enrolled", value: "1,240 Families", trend: "98% Covered" }
    ]
  },
  {
    id: "school-sector",
    name: "Integrated Smart Academy & High School",
    shortTitle: "Smart School Campus",
    category: "school",
    iconName: "GraduationCap",
    completionPercentage: 91,
    status: "Near Completion",
    targetDate: "November 2026",
    budgetAllocated: "₹26.5 Crore ($3.2M)",
    leadAgency: "State Education Infrastructure Mission",
    description:
      "A futuristic educational institution from Kindergarten to Grade 12 affiliated with CBSE & IB curriculum. Features STEM robotics laboratories, digital interactive smartboards, Olympic-standard sports arena, and vocational skill centers for youth.",
    keyHighlights: [
      "Pre-K to Grade 12 Co-educational Campus with 1,200 student capacity",
      "Robotics, AI & 3D Printing Innovation Tinkering Labs funded under Atal Innovation Mission",
      "Full-sized Football Turf, Olympic-length Swimming Pool & 400m Athletic Track",
      "Digital Interactive Touchscreens & AI personalized learning tablets for every student",
      "Vocational Training Wing: Agritech, Solar Tech, Electric Vehicle maintenance & Coding",
      "100% Free Full-Tuition Scholarship for children of original native village landowners"
    ],
    specs: [
      { label: "Campus Land Area", value: "4.5 Acres" },
      { label: "Total Classroom Count", value: "48 Digital Smart Classrooms" },
      { label: "Student-Teacher Ratio", value: "18 : 1" },
      { label: "Library Capacity", value: "25,000+ Physical & Digital Books" },
      { label: "Auditorium Seating", value: "600-Seater Acoustic Hall" },
      { label: "Cafeteria Standard", value: "Organic Farm-to-Table Nutrition Kitchen" }
    ],
    timeline: [
      {
        phase: "Phase 1",
        milestone: "Academic Blocks A & B Civil Construction & Roofing",
        date: "Jan 2025 - Jun 2025",
        completed: true,
        notes: "Earthquake resistant shear-wall design with passive natural ventilation."
      },
      {
        phase: "Phase 2",
        milestone: "Sports Ground, Athletic Track & Swimming Pool Excavation",
        date: "Jul 2025 - Dec 2025",
        completed: true,
        notes: "Laid FIFA-certified artificial astroturf and 8-lane racing pool."
      },
      {
        phase: "Phase 3",
        milestone: "Digital Interactive Boards, STEM Robotics Lab & Science Labs",
        date: "Jan 2026 - Jun 2026",
        completed: true,
        notes: "Installed 48 interactive 85-inch digital whiteboards and solar lab kits."
      },
      {
        phase: "Phase 4",
        milestone: "Faculty Recruitment, Affiliation Clearances & Admissions Rollout",
        date: "Jul 2026 - Nov 2026",
        completed: false,
        notes: "Admissions portal kickoff scheduled for first academic batch intake."
      }
    ],
    gallery: [
      {
        title: "Academic Main Quadrangle & Solar Canopy",
        caption: "Contemporary educational campus with open corridors and greenery.",
        tag: "Campus View",
        imageUrl: "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=1200&q=80"
      },
      {
        title: "STEM Robotics & Innovation Lab",
        caption: "Hands-on maker space equipped with robotics kits, 3D printers and coding workstations.",
        tag: "STEM Innovation",
        imageUrl: "https://images.unsplash.com/photo-1581092921461-eab62e97a780?auto=format&fit=crop&w=1200&q=80"
      },
      {
        title: "Olympic Standard Sports Arena & Track",
        caption: "Multipurpose sports complex with floodlights and spectator seating.",
        tag: "Sports Facilities",
        imageUrl: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=1200&q=80"
      }
    ],
    liveMetrics: [
      { label: "Faculty Applications", value: "340+ Candidates", trend: "Top Tier Selection" },
      { label: "Lab Stations Ready", value: "60 Active Units", trend: "100% Tested" }
    ]
  },
  {
    id: "roads-sector",
    name: "Road Network, 6-Lane Bypass & EV Mobility Grid",
    shortTitle: "Roads & Mobility",
    category: "roads",
    iconName: "Route",
    completionPercentage: 84,
    status: "Near Completion",
    targetDate: "November 2026",
    budgetAllocated: "₹52.0 Crore ($6.2M)",
    leadAgency: "State Highways & Township Infrastructure Authority",
    description:
      "Complete overhaul of village dirt pathways into high-grade arterial roads, a 6-lane bypass corridor connecting to the State Expressway, dedicated non-motorized cycling lanes, and zero overhead wires (100% underground utility corridors).",
    keyHighlights: [
      "6-Lane 4.5 km Outer Bypass connecting Vikasgram directly to Regional Expressway",
      "4-Lane Internal Arterial Boulevard with median greenery and EV fast charging bays",
      "12 km of Dedicated Non-Motorized Bicycle Tracks & Pedestrian Walkways",
      "Smart Solar LED Street Lighting with automatic dimming & emergency help buttons",
      "Zero Overhead Wiring: 100% Power, Telecom & Gas routed via underground concrete ducts",
      "Automated Traffic Flow & Speed Monitoring with Solar CCTV network"
    ],
    specs: [
      { label: "Bypass Expressway Length", value: "4.50 km (6 Lanes, 45m ROW)" },
      { label: "Internal Arterial Roads", value: "18.2 km (4 & 2 Lanes)" },
      { label: "Cycling & Walking Greenway", value: "12.4 km Segregated Track" },
      { label: "Smart Street Poles Installed", value: "460 Units (Solar + CCTV + WiFi)" },
      { label: "EV Public Fast Charging Stations", value: "14 Hubs (50 kW Dual-Gun)" },
      { label: "Stormwater Underground Grids", value: "100% Road Coverage with Oil-Separators" }
    ],
    timeline: [
      {
        phase: "Phase 1",
        milestone: "Right of Way Clearance, Utility Trenching & Base Subgrade",
        date: "Nov 2024 - Apr 2025",
        completed: true,
        notes: "Laid heavy-duty precast concrete utility conduits for fiber, power, and water."
      },
      {
        phase: "Phase 2",
        milestone: "6-Lane Bypass Bituminous Road Surfacing & Overbridge Connect",
        date: "May 2025 - Jan 2026",
        completed: true,
        notes: "High-grade SMA (Stone Matrix Asphalt) applied for 20-year durability."
      },
      {
        phase: "Phase 3",
        milestone: "Internal Sector Roads, Cycle Tracks & Smart Solar Street Pole Erection",
        date: "Feb 2026 - Jul 2026",
        completed: true,
        notes: "460 smart poles installed with ambient air sensors and SOS emergency boxes."
      },
      {
        phase: "Phase 4",
        milestone: "Signage, Road Markings, EV Fast Chargers & Traffic Control Center",
        date: "Aug 2026 - Nov 2026",
        completed: false,
        notes: "Commissioning the computerized smart traffic management central room."
      }
    ],
    gallery: [
      {
        title: "6-Lane Bypass Expressway Connector",
        caption: "Smooth asphalt 6-lane highway connecting Vikasgram township to the capital expressway.",
        tag: "Expressway",
        imageUrl: "https://images.unsplash.com/photo-1545459720-aac8509eb02c?auto=format&fit=crop&w=1200&q=80"
      },
      {
        title: "Internal Tree-Lined EV Arterial Boulevard",
        caption: "Underground utility corridor with segregated cycling track and smart street lighting.",
        tag: "Township Boulevard",
        imageUrl: "https://images.unsplash.com/photo-1573868388390-273a8692749c?auto=format&fit=crop&w=1200&q=80"
      }
    ],
    liveMetrics: [
      { label: "Bypass Asphalt Quality", value: "IRC Grade Certified", trend: "0 Pothole Guarantee" },
      { label: "Active EV Chargers", value: "8 Hubs Live", trend: "6 More in testing" }
    ]
  },
  {
    id: "housing-sector",
    name: "Smart Residential Sectors, Eco-Villas & Native Villaments",
    shortTitle: "Housing & Residential",
    category: "housing",
    iconName: "Home",
    completionPercentage: 76,
    status: "In Progress",
    targetDate: "Early 2027",
    budgetAllocated: "₹115.0 Crore ($13.8M)",
    leadAgency: "Vikasgram Township Development Authority & Private Partners",
    description:
      "A harmonious blend of modernized 'Villament' residences allotted free/subsidized to existing native village families alongside premium Eco-Villas, 2BHK/3BHK Garden Apartments, and townhouses for new incoming residents seeking a green lifestyle.",
    keyHighlights: [
      "100% Rehabilitation: 320 custom Modern Villaments for native village families with titles",
      "1,160 New Eco-Villas & Smart Apartments with solar rooftop & smart home automation",
      "Piped Natural Gas (PNG), 24x7 pressurized drinking water & high-speed FTTH Fiber",
      "Green Building Certification (IGBC Platinum Standard) with double-glazed heat insulated windows",
      "Private gardens, central community plazas & electric buggy parking in every cluster",
      "Affordable EMI financing partnerships with SBI, HDFC & HUDCO"
    ],
    specs: [
      { label: "Total Residential Units", value: "1,480 Units (Phase 1: 640 | Phase 2: 840)" },
      { label: "Native Villager Quota", value: "320 Units (Allotted 100% Free with Solar)" },
      { label: "Carpet Area Range", value: "780 sq.ft (1BHK) to 3,200 sq.ft (4BHK Villa)" },
      { label: "Structure Standard", value: "Mivan Monolithic Concrete (Seismic Zone IV)" },
      { label: "Solar Generation per Villa", value: "3.5 kW Grid-Tied Rooftop System" },
      { label: "Expected Phase 1 Move-in", value: "January 2027" }
    ],
    timeline: [
      {
        phase: "Phase 1A",
        milestone: "Native Villager Rehabilitation Housing Complex (320 Units)",
        date: "Oct 2024 - Dec 2025",
        completed: true,
        notes: "All 320 native family homes finished with solar rooftops, biogas and modular kitchens."
      },
      {
        phase: "Phase 1B",
        milestone: "Phase 1 Smart Apartments & Eco-Villas (320 Units)",
        date: "Jan 2025 - Oct 2026",
        completed: true,
        notes: "Structure completed, interior tiling and plumbing fixtures currently underway."
      },
      {
        phase: "Phase 2",
        milestone: "Phase 2 Premium Eco-Villas & Townhouses (840 Units)",
        date: "Jun 2025 - Mar 2027",
        completed: false,
        notes: "Basement and framing 62% complete across Sector 3 and Sector 5."
      }
    ],
    gallery: [
      {
        title: "Phase 1 Modern Villaments (Native Landowners)",
        caption: "High quality 3-story villaments with personal terraces and solar arrays.",
        tag: "Villaments",
        imageUrl: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80"
      },
      {
        title: "Smart Eco-Villas for New Residents",
        caption: "Contemporary sustainable 3BHK villas with private lawns and electric car ports.",
        tag: "Eco-Villas",
        imageUrl: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80"
      },
      {
        title: "Garden View Low-Rise Smart Apartments",
        caption: "4-story elevator-equipped apartments overlooking the 3-acre park.",
        tag: "Apartments",
        imageUrl: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80"
      }
    ],
    liveMetrics: [
      { label: "Phase 1 Booking Status", value: "82% Booked", trend: "Fast Allotment" },
      { label: "Native Possession Handover", value: "320 Homes Ready", trend: "100% Satisfied" }
    ]
  },
  {
    id: "gym-sports",
    name: "Community Sports Complex & Multi-Tier Indoor Gym",
    shortTitle: "Sports & Gym Complex",
    category: "gym",
    iconName: "Dumbbell",
    completionPercentage: 86,
    status: "Near Completion",
    targetDate: "October 2026",
    budgetAllocated: "₹14.2 Crore ($1.7M)",
    leadAgency: "Sports Authority of India & Township Trust",
    description:
      "A comprehensive multi-tier indoor gym and athletic complex offering strength training, yoga & pilates studios, indoor badminton & squash courts, steam sauna wellness, and youth athletic coaching academies.",
    keyHighlights: [
      "12,000 sq.ft Air-conditioned Multi-tier Gymnasium with international cardio & strength stations",
      "4 BWF-standard Indoor Wooden Badminton Courts & 2 Squash Courts",
      "Dedicated Yoga & Meditation Deck with panoramic views of the green belt",
      "Semi-Olympic Heated Swimming Pool with certified lifeguards and swimming coaches",
      "Nutritional Protein Cafe, Steam, Sauna & Physiotherapy rehabilitation clinic",
      "100% Free Access for native village residents & nominal monthly membership for new residents"
    ],
    specs: [
      { label: "Complex Built-up Area", value: "24,000 sq.ft (G+2 Floors)" },
      { label: "Gym Equipment Tier", value: "LifeFitness & Technogym Commercial Grade" },
      { label: "Indoor Courts", value: "4 Badminton, 2 Squash, 6 Table Tennis" },
      { label: "Swimming Pool Dimensions", value: "25m x 12m (Temperature Controlled)" },
      { label: "Certified Trainers", value: "8 National Level Coaches & Physios" }
    ],
    timeline: [
      {
        phase: "Phase 1",
        milestone: "RCC Structure, High-Ceiling Sports Arena & Pool Basin",
        date: "Mar 2025 - Sep 2025",
        completed: true,
        notes: "Completed deep waterproofing and column-free truss roof for badminton arena."
      },
      {
        phase: "Phase 2",
        milestone: "Imported Maple Wood Flooring & Gym Equipment Installation",
        date: "Oct 2025 - May 2026",
        completed: true,
        notes: "Installed 45 fitness machines, free weights zone, and acoustic sound insulation."
      },
      {
        phase: "Phase 3",
        milestone: "Steam, Sauna, Nutritional Bar & Grand Community Inauguration",
        date: "Jun 2026 - Oct 2026",
        completed: false,
        notes: "Final safety inspection and membership registration kickoff."
      }
    ],
    gallery: [
      {
        title: "Modern Multi-Tier Gym Floor",
        caption: "State of the art cardio, calisthenics, and resistance training zone.",
        tag: "Gym Area",
        imageUrl: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1200&q=80"
      },
      {
        title: "Indoor Badminton & Squash Arena",
        caption: "Maple wood shock-absorbent courts with tournament lighting.",
        tag: "Indoor Courts",
        imageUrl: "https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?auto=format&fit=crop&w=1200&q=80"
      }
    ],
    liveMetrics: [
      { label: "Resident Pre-Registrations", value: "980 Members", trend: "+120 this week" },
      { label: "Equipment Status", value: "100% Installed", trend: "Calibration Done" }
    ]
  },
  {
    id: "utilities-sector",
    name: "Public Utilities, 3.5 MW Solar Microgrid & Zero-Waste STP",
    shortTitle: "Public Utilities & Eco-Grid",
    category: "utilities",
    iconName: "Zap",
    completionPercentage: 82,
    status: "Near Completion",
    targetDate: "December 2026",
    budgetAllocated: "₹38.8 Crore ($4.7M)",
    leadAgency: "Clean Energy & Urban Water Mission",
    description:
      "The backbone of the smart township: a 2 MLD Sewage Treatment Plant (producing tertiary-treated water for parks and construction), a 3.5 MW Solar Farm generating clean power, automated pneumatic solid waste segregation, and zero-flood smart storm drainage.",
    keyHighlights: [
      "2 MLD Membrane Bioreactor (MBR) Sewage Treatment Plant with zero liquid discharge (ZLD)",
      "3.5 MW Ground-Mounted & Rooftop Solar Microgrid with 2 MWh Battery Energy Storage (BESS)",
      "24x7 Pressurized Drinking Water Supply with automated IoT chlorine & TDS monitoring",
      "Automated Solid Waste Management: In-vessel organic composting & dry recyclables sorting",
      "Underground Rainwater Harvesting network recharging 4 local village aquifers & bio-lakes",
      "Smart Town Command & Control Center (ICCC) monitoring water, power & waste in real-time"
    ],
    specs: [
      { label: "STP Capacity", value: "2.0 Million Litres per Day (MBR Technology)" },
      { label: "Solar Energy Generation", value: "3.5 MW Peak (5.2 Million Units/year)" },
      { label: "Township Clean Energy Offset", value: "78% of Total Township Demand" },
      { label: "Battery Energy Storage", value: "2.0 MWh Lithium Iron Phosphate (LFP)" },
      { label: "Compost Generation", value: "4.5 Tonnes Organic Fertilizer / week for farmers" },
      { label: "Water Quality Standard", value: "WHO & BIS 10500 Compliant (Drinkable from Tap)" }
    ],
    timeline: [
      {
        phase: "Phase 1",
        milestone: "2 MLD STP Tank Construction & Micro-filtration Setup",
        date: "Dec 2024 - Jul 2025",
        completed: true,
        notes: "Civil bioreactor tanks completed with membrane filtration testing."
      },
      {
        phase: "Phase 2",
        milestone: "3.5 MW Solar Microgrid Panel Erection & Inverter Sync",
        date: "Aug 2025 - Mar 2026",
        completed: true,
        notes: "Synchronized with state power grid with bi-directional net metering."
      },
      {
        phase: "Phase 3",
        milestone: "Automated Waste Sorting Plant & Water Pipe Pressure Calibration",
        date: "Apr 2026 - Sep 2026",
        completed: true,
        notes: "IoT ultrasonic flow meters active across all sector water nodes."
      },
      {
        phase: "Phase 4",
        milestone: "Township Integrated Command & Control Center (ICCC) Launch",
        date: "Oct 2026 - Dec 2026",
        completed: false,
        notes: "AI anomaly detection for pipe leakage and power fluctuation monitoring."
      }
    ],
    gallery: [
      {
        title: "3.5 MW Solar Farm & Battery Storage",
        caption: "Bifacial solar arrays supplying 78% of the township's electrical demand.",
        tag: "Solar Microgrid",
        imageUrl: "https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=1200&q=80"
      },
      {
        title: "2 MLD Advanced MBR Sewage Treatment Plant",
        caption: "Odorless automated biological treatment recycling 100% of wastewater.",
        tag: "Water STP",
        imageUrl: "https://images.unsplash.com/photo-1574482620826-40685ca5ebd2?auto=format&fit=crop&w=1200&q=80"
      }
    ],
    liveMetrics: [
      { label: "Solar Energy Generated Today", value: "14,820 kWh", trend: "+8% vs target" },
      { label: "Recycled Water Purity", value: "TDS 180 (Safe for lakes)", trend: "Optimal" },
      { label: "CO2 Emissions Saved", value: "2,410 Tonnes", trend: "Green Certified" }
    ]
  }
];

export const HOUSING_OPTIONS: HousingUnitOption[] = [
  {
    id: "unit-villament",
    title: "Vikas Heritage Villament (3-Storey)",
    type: "1BHK Native Villament",
    carpetArea: "1,150 sq.ft",
    superArea: "1,420 sq.ft",
    allotmentStatus: "Native Villager Quota",
    estimatedPrice: "Subsidized / Free for Landowners",
    features: [
      "Dedicated solar rooftop (2 kW)",
      "Traditional courtyards with modern insulated walls",
      "Piped gas & 24x7 water connection",
      "Biogas slurry connection for home kitchen",
      "Private scooter & tractor parking space"
    ],
    floorPlanDetails: "Ground Floor: Living room + Modular Kitchen + Verandah. 1st Floor: 2 Bedrooms with en-suite. Terrace: Solar deck + utility area.",
    solarCapacity: "2.0 kW"
  },
  {
    id: "unit-garden-2bhk",
    title: "GreenView 2BHK Garden Apartment",
    type: "2BHK Garden Flat",
    carpetArea: "920 sq.ft",
    superArea: "1,210 sq.ft",
    allotmentStatus: "Open for Booking",
    estimatedPrice: "₹48.5 Lakh ($58,000)",
    features: [
      "Overlooking the 3-Acre Central Eco-Park",
      "Double balcony with hydroponic planters",
      "EV parking slot with smart sub-meter",
      "Smart biometric door lock & video doorbell",
      "Access to community sports complex & pool"
    ],
    floorPlanDetails: "Spacious Living & Dining hall with attached East-facing balcony, Master Bedroom with wooden flooring, Guest Bedroom, 2 Bathrooms, Utility kitchen.",
    solarCapacity: "Central Rooftop Net-Metered"
  },
  {
    id: "unit-villa-3bhk",
    title: "Serenity 3BHK Smart Eco-Villa",
    type: "3BHK Eco-Villa",
    carpetArea: "2,150 sq.ft",
    superArea: "2,680 sq.ft",
    allotmentStatus: "Fast Filling",
    estimatedPrice: "₹1.15 Crore ($138,000)",
    features: [
      "Independent private garden & plunge pool option",
      "3.5 kW dedicated solar array with battery backup",
      "Rainwater harvesting sump (8,000 Litres)",
      "Automated climate control & voice-enabled lighting",
      "Dual covered parking with 22kW EV fast charger"
    ],
    floorPlanDetails: "Ground Floor: Double-height lounge, Italian kitchen, Guest suite, Garden deck. 1st Floor: Master Suite with walk-in closet, Kids bedroom, Home office. Rooftop: Stargazing lounge.",
    solarCapacity: "3.5 kW Grid-Tied"
  },
  {
    id: "unit-townhouse-4bhk",
    title: "Grand Horizon 4BHK Townhouse",
    type: "4BHK Smart Townhouse",
    carpetArea: "3,200 sq.ft",
    superArea: "3,950 sq.ft",
    allotmentStatus: "Open for Booking",
    estimatedPrice: "₹1.75 Crore ($210,000)",
    features: [
      "Corner plot adjacent to Hospital & Central Boulevard",
      "Private elevator (G+2 floors)",
      "Solar rooftop 5.0 kW with zero net electricity bill",
      "Home theater lounge & servant quarter",
      "Triple automated garage"
    ],
    floorPlanDetails: "Grand foyer entrance, 4 luxury en-suite bedrooms, private terrace garden with barbecue deck, personal fitness room, modern show kitchen & wet pantry.",
    solarCapacity: "5.0 kW Solar Microgrid"
  }
];

export const OFFICIAL_DOCUMENTS: DocumentItem[] = [
  {
    id: "DOC-2024-001",
    title: "Town & Country Planning Directorate Masterplan Notification 2024-2028",
    category: "Masterplan",
    referenceNo: "TCP/S-DEV/VKG-MP-2024-098",
    issueDate: "14 January 2024",
    authorizingBody: "Directorate of Town & Country Planning & Urban Development Authority",
    fileSize: "18.4 MB (High-Res Blueprint PDF)",
    summary:
      "Statutory sanction granting conversion of Vikasgram revenue boundaries into an Integrated Eco-Smart Mini-Township covering 180.45 Acres with designated land-use zoning for residential, 3-acre park, 100-bed hospital, school, roads, and utilities.",
    status: "Verified & Gazetted",
    highlights: [
      "Official gazette notification number #G-2488/2024 published in State Gazette Part IV",
      "42% mandatory green space covenant locked under Section 12-B",
      "Full exemption of stamp duty for native villager property registrations",
      "Mandatory 6-lane connectivity sanction with State Highway Authority"
    ]
  },
  {
    id: "DOC-2024-002",
    title: "Ministry of Environment, Forest & Climate Change (MoEF&CC) Environmental Clearance",
    category: "Clearances",
    referenceNo: "ENV/EC/SEIAA/2024/774",
    issueDate: "28 March 2024",
    authorizingBody: "State Environmental Impact Assessment Authority (SEIAA)",
    fileSize: "8.2 MB (Certificate & Compliance Report)",
    summary:
      "Category B1 Environmental Clearance for the 180-Acre township certifying Zero Liquid Discharge (ZLD), mandatory 1,200 native tree plantation in the 3-Acre Central Park, and rooftop solar microgrid deployment.",
    status: "Approved",
    highlights: [
      "Zero ground water over-extraction compliance with 100% recharge ponds",
      "Air quality monitoring station integration with Central Pollution Control Board",
      "Eco-sensitive buffer zone preservation along the natural village stream"
    ]
  },
  {
    id: "DOC-2024-003",
    title: "Village Gram Panchayat Unanimous Resolution & NOC Agreement",
    category: "Panchayat Resolutions",
    referenceNo: "VGP/RES/2024-11",
    issueDate: "05 February 2024",
    authorizingBody: "Vikasgram Gram Panchayat & Village Assembly (Gram Sabha)",
    fileSize: "4.7 MB (Bilingual Hindi/English with Signatures)",
    summary:
      "Unanimously passed resolution by all 320 resident families approving the township masterplan, ensuring 100% free rehabilitated villaments, job quotas in township maintenance, free hospital OPD, and school scholarships.",
    status: "Verified & Gazetted",
    highlights: [
      "Signed by Sarpanch, 12 Ward Members, and 318 registered voting village elders",
      "Binding covenant that no native resident shall be displaced outside the township perimeter",
      "Guaranteed lifetime free supply of 150 Litres/capita/day of treated potable water"
    ]
  },
  {
    id: "DOC-2024-004",
    title: "100-Bed Multi-Specialty Hospital Sanction & Medical Council Clearance",
    category: "Clearances",
    referenceNo: "MOHFW/HOSP-SANC/2024/491",
    issueDate: "12 June 2024",
    authorizingBody: "Ministry of Health & Family Welfare & Medical Council",
    fileSize: "6.1 MB (Licensing & Architecture Blueprint)",
    summary:
      "Formal healthcare infrastructure clearance establishing 100-bed hospital, 24/7 trauma emergency center, rooftop aero-medical helipad clearance, and blood bank licensing.",
    status: "Approved",
    highlights: [
      "Helipad landing clearance from Directorate General of Civil Aviation (DGCA)",
      "Radiation safety clearance from Atomic Energy Regulatory Board for CT Scan & X-Ray",
      "Telemedicine connectivity sanctioned with 4 national medical institutes"
    ]
  },
  {
    id: "DOC-2024-005",
    title: "Transparent Land Compensation & Allotment Ledger Registry",
    category: "Land & Revenue",
    referenceNo: "REV/LR-COMP/2024/339",
    issueDate: "20 August 2024",
    authorizingBody: "District Revenue Collector & Land Acquisition Tribunal",
    fileSize: "12.3 MB (Certified Land Titles Ledger)",
    summary:
      "Public audit record detailing plot numbers, family title deeds, compensation disbursement (₹142 Crore total), and guaranteed allotment registry for Phase 1 Villament clusters.",
    status: "Verified & Gazetted",
    highlights: [
      "100% direct bank transfer (DBT) digital audit verification",
      "Zero pending land litigations or disputes certified by District Magistrate",
      "QR-coded blockchain-verified land title registry for all 1,480 total township plots"
    ]
  },
  {
    id: "DOC-2024-006",
    title: "Public Works Tender #08: 6-Lane Expressway Connector & Internal EV Roads",
    category: "Tenders",
    referenceNo: "PWD/TWN-ROADS/2024/T-08",
    issueDate: "10 September 2024",
    authorizingBody: "State Highway Public Works Department",
    fileSize: "5.5 MB (Contract Specifications)",
    summary:
      "Engineering procurement & construction (EPC) contract awarded to Larsen & Toubro (L&T Infrastructure) for the 4.5km 6-lane bypass and 18.2km smart arterial grid with 10-year defect liability.",
    status: "Approved",
    highlights: [
      "Strict performance timeline with financial penalty clauses for delays",
      "Stone Matrix Asphalt (SMA) grade 80/100 polymer modified bitumen specifications",
      "Underground utility precast concrete ducting design specifications"
    ]
  }
];

export const TOUR_TYPES = [
  {
    id: "tour-buggy",
    title: "Guided Electric Buggy Site Tour",
    duration: "45 Minutes",
    description: "Hop on our silent eco-buggy driven by a township planning engineer. Explore the 6-lane road, 3-acre park, model villament, school campus, and hospital.",
    badge: "Most Popular",
    icon: "Car"
  },
  {
    id: "tour-vr",
    title: "3D VR Experience Center Walkthrough",
    duration: "30 Minutes",
    description: "Step into our on-site high-definition VR immersion studio to experience the fully finished 2028 township with virtual walkthroughs inside villas and hospital.",
    badge: "High Tech",
    icon: "Glasses"
  },
  {
    id: "tour-officer",
    title: "One-on-One Officer & Allotment Consultation",
    duration: "60 Minutes",
    description: "Meet directly with the Township Allotment Officer and Banking Partner to evaluate floor plans, plot locations, pricing, and bank loans.",
    badge: "For Buyers",
    icon: "UserCheck"
  },
  {
    id: "tour-stay",
    title: "Township Experience Stay (1 to 3 Nights)",
    duration: "1 - 3 Days",
    description: "Experience living in our completed Model Smart Villament with 24x7 solar power, high-speed fiber, organic garden access, and community sports membership.",
    badge: "Full Experience",
    icon: "Bed"
  }
];
