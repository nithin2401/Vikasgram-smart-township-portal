import React, { createContext, useContext, useEffect, useState } from "react";
import { 
  User as FirebaseUser,
  onAuthStateChanged,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInAnonymously,
  signOut,
  updateProfile
} from "firebase/auth";
import { 
  doc, 
  setDoc, 
  getDoc, 
  onSnapshot 
} from "firebase/firestore";
import { auth, db, googleProvider, handleFirestoreError, OperationType } from "../firebase";
import { UserProfile } from "../types";

interface AuthContextType {
  user: FirebaseUser | null;
  userProfile: UserProfile | null;
  loading: boolean;
  isAuthModalOpen: boolean;
  authModalTab: "signin" | "signup";
  openAuthModal: (tab?: "signin" | "signup", onLoginSuccess?: () => void) => void;
  closeAuthModal: () => void;
  loginWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (email: string, pass: string, name: string, phone?: string, role?: string) => Promise<void>;
  loginAsGuest: (name?: string, role?: string) => Promise<void>;
  logoutUser: () => Promise<void>;
  loginSuccessCallback: (() => void) | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalTab, setAuthModalTab] = useState<"signin" | "signup">("signin");
  const [loginSuccessCallback, setLoginSuccessCallback] = useState<(() => void) | null>(null);

  // Synchronize Firebase Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // Fetch or create profile in Firestore
        const userDocRef = doc(db, "users", currentUser.uid);
        try {
          const docSnap = await getDoc(userDocRef);
          if (docSnap.exists()) {
            setUserProfile(docSnap.data() as UserProfile);
          } else {
            // Check local storage for pending guest/demo metadata if anonymous
            const savedRole = localStorage.getItem(`vkg_role_${currentUser.uid}`) || "Prospective Resident / Relocating Family";
            const savedName = localStorage.getItem(`vkg_name_${currentUser.uid}`) || currentUser.displayName || (currentUser.isAnonymous ? "Guest Citizen" : "Township Visitor");

            // Initialize basic profile for Google/new users
            const newProfile: UserProfile = {
              uid: currentUser.uid,
              email: currentUser.email || `${currentUser.uid.slice(0, 8)}@guest.vikasgram.gov`,
              displayName: savedName,
              phoneNumber: currentUser.phoneNumber || "+91 98000 00000",
              role: savedRole,
              photoURL: currentUser.photoURL || "",
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            };
            try {
              await setDoc(userDocRef, newProfile);
            } catch (e) {
              console.warn("Could not save initial user doc:", e);
            }
            setUserProfile(newProfile);
          }
        } catch (err) {
          console.warn("Could not sync user profile from Firestore:", err);
          // Fallback minimal profile
          setUserProfile({
            uid: currentUser.uid,
            email: currentUser.email || "visitor@vikasgram.gov",
            displayName: currentUser.displayName || "Township Visitor",
            photoURL: currentUser.photoURL || "",
            role: "Prospective Resident / Relocating Family",
            createdAt: new Date().toISOString()
          });
        }
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const openAuthModal = (tab: "signin" | "signup" = "signin", onLoginSuccess?: () => void) => {
    setAuthModalTab(tab);
    if (onLoginSuccess) {
      setLoginSuccessCallback(() => onLoginSuccess);
    } else {
      setLoginSuccessCallback(null);
    }
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
    setLoginSuccessCallback(null);
  };

  const loginWithGoogle = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const u = result.user;
      if (u) {
        const userDocRef = doc(db, "users", u.uid);
        const profileSnap = await getDoc(userDocRef);
        if (!profileSnap.exists()) {
          const newProf: UserProfile = {
            uid: u.uid,
            email: u.email || "",
            displayName: u.displayName || "Township Visitor",
            phoneNumber: u.phoneNumber || "",
            role: "Prospective Resident / Relocating Family",
            photoURL: u.photoURL || "",
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };
          await setDoc(userDocRef, newProf);
          setUserProfile(newProf);
        }
      }
      setIsAuthModalOpen(false);
      if (loginSuccessCallback) {
        loginSuccessCallback();
        setLoginSuccessCallback(null);
      }
    } catch (err) {
      console.error("Google login error:", err);
      throw err;
    }
  };

  const loginWithEmail = async (email: string, pass: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, pass);
      setIsAuthModalOpen(false);
      if (loginSuccessCallback) {
        loginSuccessCallback();
        setLoginSuccessCallback(null);
      }
    } catch (err) {
      console.error("Email login error:", err);
      throw err;
    }
  };

  const registerWithEmail = async (
    email: string, 
    pass: string, 
    name: string, 
    phone?: string, 
    role: string = "Prospective Resident / Relocating Family"
  ) => {
    try {
      const res = await createUserWithEmailAndPassword(auth, email, pass);
      const u = res.user;
      await updateProfile(u, { displayName: name });
      
      const newProf: UserProfile = {
        uid: u.uid,
        email: email,
        displayName: name,
        phoneNumber: phone || "",
        role: role,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      try {
        await setDoc(doc(db, "users", u.uid), newProf);
      } catch (e) {
        console.warn("Error storing user document:", e);
      }

      setUserProfile(newProf);
      setIsAuthModalOpen(false);
      if (loginSuccessCallback) {
        loginSuccessCallback();
        setLoginSuccessCallback(null);
      }
    } catch (err) {
      console.error("Email registration error:", err);
      throw err;
    }
  };

  const loginAsGuest = async (
    name: string = "Dr. Rajeshwar Sharma (Demo Resident)",
    role: string = "Prospective Resident / Relocating Family"
  ) => {
    try {
      let u: FirebaseUser | null = null;
      try {
        const res = await signInAnonymously(auth);
        u = res.user;
        await updateProfile(u, { displayName: name });
      } catch (anonErr) {
        console.warn("Anonymous auth disabled, creating instant demo credential profile:", anonErr);
      }

      const uid = u ? u.uid : `demo_${Date.now()}`;
      localStorage.setItem(`vkg_name_${uid}`, name);
      localStorage.setItem(`vkg_role_${uid}`, role);

      const guestProf: UserProfile = {
        uid: uid,
        email: "demo.resident@vikasgram.gov",
        displayName: name,
        phoneNumber: "+91 98765 43210",
        role: role,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      try {
        await setDoc(doc(db, "users", uid), guestProf);
      } catch (e) {
        console.warn("Error setting demo user doc:", e);
      }

      setUserProfile(guestProf);
      setIsAuthModalOpen(false);
      if (loginSuccessCallback) {
        loginSuccessCallback();
        setLoginSuccessCallback(null);
      }
    } catch (err) {
      console.error("Guest login error:", err);
      throw err;
    }
  };

  const logoutUser = async () => {
    await signOut(auth);
    setUser(null);
    setUserProfile(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        userProfile,
        loading,
        isAuthModalOpen,
        authModalTab,
        openAuthModal,
        closeAuthModal,
        loginWithGoogle,
        loginWithEmail,
        registerWithEmail,
        loginAsGuest,
        logoutUser,
        loginSuccessCallback
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
