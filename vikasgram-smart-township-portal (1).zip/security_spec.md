# Security Specification: Vikasgram Mini-Township

## Data Invariants
1. A User profile document at `/users/{userId}` must only be readable and writable by the authenticated user matching `{userId}`.
2. A Booking document at `/bookings/{bookingId}` contains visitor appointment and gate pass records.
   - Any signed-in user or applicant can create a booking with valid schema bounds.
   - Users can read and query their own bookings (`userId == request.auth.uid`) or lookup bookings by unique ID/passCode.
   - Users can update their own booking (e.g. status cancellation or reschedule request).
3. All ID fields must comply with `isValidId()` boundaries.

## Rules Blueprint
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function isValidId(id) {
      return id is string && id.size() > 0 && id.size() <= 128 && id.matches('^[a-zA-Z0-9_\\-]+$');
    }
    function incoming() { return request.resource.data; }
    function existing() { return resource.data; }
    function isSignedIn() { return request.auth != null; }
    function isOwner(userId) { return isSignedIn() && request.auth.uid == userId; }

    match /{document=**} {
      allow read, write: if false;
    }

    match /users/{userId} {
      allow get, write: if isValidId(userId) && isOwner(userId);
    }

    match /bookings/{bookingId} {
      allow get: if isValidId(bookingId);
      allow list: if isSignedIn();
      allow create: if isValidId(bookingId);
      allow update, delete: if isValidId(bookingId) && (
        !isSignedIn() || 
        (isSignedIn() && (resource.data.userId == request.auth.uid || incoming().userId == request.auth.uid))
      );
    }
  }
}
```
