# 🌆 Vikasgram Mini-Township — Smart Urban Transformation Portal

[![React](https://img.shields.io/badge/React-18-blue.svg?logo=react)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0-3178C6.svg?logo=typescript)](https://www.typescriptlang.org/)
[![Three.js](https://img.shields.io/badge/Three.js-3D_Visualizer-black.svg?logo=three.js)](https://threejs.org/)
[![Firebase](https://img.shields.io/badge/Firebase-Auth%20%26%20Firestore-FFCA28.svg?logo=firebase)](https://firebase.google.com/)
[![TailwindCSS](https://img.shields.io/badge/Tailwind_CSS-3.4-38B2AC.svg?logo=tailwind-css)](https://tailwindcss.com/)
[![Gemini AI](https://img.shields.io/badge/Google_Gemini-2.5_Flash-8E75FF.svg?logo=google)](https://ai.google.dev/)

An interactive 3D Smart City portal and digital administration hub designed to visualize the **180-Acre Village-to-Township Transformation Project**. Featuring a real-time 3D masterplan scene, sector deep-dives (3-Acre Eco-Park, 100-Bed Trauma Hospital, Smart School, 3.5 MW Solar Farm, 6-Lane Expressway Bypass), official statutory gazette repositories, live CCTV construction feeds, an AI architectural assistant powered by Google Gemini, and a full visitor booking roster with digital QR entry passes.

---

## 🌟 Key Features

### 🌐 1. Interactive 3D Masterplan Explorer (Three.js)
- **180-Acre Orthographic & Perspective Visualizer**: Full 360° orbit rotation, multi-tier zoom, and preset viewpoints (Overall Masterplan, Eco-Park, Healthcare Hub, Bypass Highway, Education Quadrant, Solar Utilities).
- **Dynamic Infrastructure Layers**: Toggle roads & traffic, green cover & trees, healthcare & social facilities, and utility grids on/off.
- **Lighting Cycles**: Switch between Day Lighting, Golden Hour Sunset, and Night Glow with illuminated streetlights and building beacons.
- **EV Traffic Simulation**: Animated electric buggies and vehicles navigating the 6-lane bypass and internal arterial network.

### 🏗️ 2. Dedicated Sector Deep-Dives
- **3-Acre Central Eco-Park**: 1.8 km reflexology trail, open-air calisthenics gymnasium, children's adventure playground, and native flora sanctuary.
- **100-Bed Super-Specialty Hospital**: 24/7 Level-1 trauma care, ICU wings, diagnostic laboratory, residential quarters for medical staff, and a certified rooftop emergency helipad.
- **Smart School & STEM Quadrangle**: Robotic labs, digital smartboards, Olympic-standard athletics track, and day-boarding facilities.
- **6-Lane Expressway Connector Bypass**: Direct regional connectivity bypass avoiding bottleneck congestion.
- **Clean Energy & Water Utilities**: 3.5 MW rooftop and ground-mounted solar grid, 4.2 MLD wastewater recycling STP/ETP, and rainwater harvesting cisterns.

### 👥 3. Township Bookings & Visitor Registry
- **Live Visitor Roster Table**: Filter, search, and sort bookings across citizen categories (Prospective Residents, Native Landowners, Doctors/Investors, Govt Officials).
- **Model Villament Stay Reservations**: Book 1–3 night immersive stays in solar-powered model villas.
- **Digital QR Gate Passes**: Generates scannable, verifiable passcodes (`VKG-PASS-XXXX`) with instant print, calendar export, and CSV roster download.
- **Real-Time Synchronization**: Backed by **Firebase Firestore** with optimistic client state fallbacks.

### 📑 4. Statutory Blueprints & Governance Hub
- Searchable blueprints, environmental impact assessments (EIA), MoEF&CC environmental clearances, Gram Sabha unanimous approvals, and land records.
- Live file size metrics, statutory verification badges, and download triggers.

### 🔴 5. Live Telemetry & Onsite Streams
- Multi-camera CCTV simulation covering Gate 1, Hospital Tower construction, Eco-Park landscaping, and the Solar Substation.
- Real-time sensor metrics: Air Quality Index (AQI), solar power generation (kW), and active workforce telemetry.

### 🤖 6. Gemini AI Township Assistant
- Server-side integration with **Google Gemini 2.5 Flash** for instant architectural, statutory, residential, and environmental queries.

---

## 🛠️ Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS, Lucide Icons, Canvas Confetti
- **3D Graphics**: Three.js (`three`, `@types/three`)
- **Backend**: Express.js (Node.js TypeScript API server)
- **Database & Auth**: Firebase Authentication & Cloud Firestore
- **AI Engine**: `@google/genai` (Gemini 2.5 Flash)
- **Bundler & Tooling**: Vite, esbuild, TypeScript compiler

---

## 🚀 Getting Started

### Prerequisites
- Node.js (v18.0.0 or higher)
- npm (v9.0.0 or higher)

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/vikasgram-mini-township.git
cd vikasgram-mini-township
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Configure Environment Variables
Copy the example environment configuration:
```bash
cp .env.example .env
```
Fill in your API credentials in `.env`:
```env
# Google Gemini API Key (Server-side)
GEMINI_API_KEY=your_gemini_api_key_here

# Firebase Configuration (Optional if using client SDK config)
VITE_FIREBASE_API_KEY=your_firebase_api_key
VITE_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
VITE_FIREBASE_APP_ID=your_app_id
```

### 4. Run Development Server
```bash
npm run dev
```
Open your browser and navigate to `http://localhost:3000`.

### 5. Build for Production
```bash
npm run build
npm start
```

---

## 📁 Project Structure

```
├── public/                  # Static assets & icons
├── src/
│   ├── components/          # Modular UI & Feature Components
│   │   ├── AppointmentBookingSystem.tsx  # Bookings column, stay reservations & QR passes
│   │   ├── AuthModal.tsx                 # Firebase Email / Google / Guest Resident modal
│   │   ├── DedicatedSectorsSection.tsx   # Detailed sector tabs (Park, Hospital, School, etc.)
│   │   ├── DocumentsBlueprintHub.tsx     # Masterplan blueprints & legal gazettes
│   │   ├── GeminiTownshipAdvisor.tsx     # AI Township assistant
│   │   ├── LiveWorkStream.tsx            # CCTV stream & sensor telemetry
│   │   ├── RenderingsAndComparison.tsx   # 3D render gallery & before/after evolution
│   │   └── Township3DExplorer.tsx        # Three.js 180-acre interactive 3D scene
│   ├── context/
│   │   └── AuthContext.tsx  # Firebase auth provider & state management
│   ├── data/
│   │   └── townshipData.ts  # Masterplan sectors, blueprints, and timeline data
│   ├── firebase.ts          # Firebase SDK initialization & Firestore references
│   ├── types.ts             # Shared TypeScript models and interfaces
│   ├── App.tsx              # Main layout & section orchestration
│   ├── main.tsx             # React DOM root entry
│   └── index.css            # Tailwind CSS styling & animations
├── server.ts                # Express backend proxy with Gemini API & appointments store
├── vite.config.ts           # Vite configuration
├── package.json             # NPM dependencies and scripts
└── README.md                # Project documentation
```

---

## 🔒 Security & Privacy

- **Server-Side API Security**: Gemini API keys and sensitive tokens are strictly executed within server routes (`/api/*`) and are never exposed to the client.
- **Firebase Security Rules**: User appointments and records are governed by Firestore rules ensuring visitors only modify their designated passes while preserving the public registry roster.

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
